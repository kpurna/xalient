CREATE TABLE "otel_logs" (
	"time" timestamp with time zone NOT NULL,
	"tag" text,
	"data" jsonb NOT NULL
);
