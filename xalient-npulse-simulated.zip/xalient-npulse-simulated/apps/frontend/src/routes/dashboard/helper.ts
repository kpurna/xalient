export function getUnixRange(period: string) {
  const now = Date.now();

  // Parse period (supports "d" for days)
  const match = /^(\d+)\s*d(?:ays)?$/i.exec(period.trim());
  if (!match) {
    throw new Error('Invalid period format. Use "7d", "30d", etc.');
  }

  const days = parseInt(match[1], 10);

  // Start time = now - days
  const startMs = now - days * 24 * 60 * 60 * 1000;

  const startUnix = Math.floor(startMs);
  const endUnix = Math.floor(now);

  return { start: startUnix, end: endUnix };
}
