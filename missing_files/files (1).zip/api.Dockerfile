# 1) Build stage
FROM node:20-alpine AS build
WORKDIR /repo

RUN corepack enable && corepack prepare pnpm@9.0.0 --activate

COPY pnpm-workspace.yaml pnpm-lock.yaml package.json turbo.json ./
COPY packages ./packages
COPY apps/api ./apps/api

RUN pnpm install --frozen-lockfile

# Build API (compiles TS → dist/)
RUN printf '{\n  "extends": "./tsconfig.json",\n  "compilerOptions": {\n    "noEmit": false,\n    "allowImportingTsExtensions": false,\n    "outDir": "./dist"\n  }\n}\n' > apps/api/tsconfig.build.json \
  && pnpm -C apps/api exec tsc -p tsconfig.build.json

# Copy SQL migration files into dist so migrate.js can resolve them at runtime
RUN cp -r apps/api/src/db/migrations apps/api/dist/src/db/migrations


# 2) Migration stage — runs against the shared postgres on xalient-net
FROM build AS migrate
WORKDIR /repo

COPY apps/api/scripts/run-migrations.sh apps/api/scripts/run-migrations.sh
RUN chmod +x apps/api/scripts/run-migrations.sh

ENTRYPOINT ["apps/api/scripts/run-migrations.sh"]


# 3) Production bundle (lean node_modules for runtime)
FROM node:20-alpine AS prod-bundle
WORKDIR /repo

RUN corepack enable && corepack prepare pnpm@9.0.0 --activate

COPY pnpm-workspace.yaml pnpm-lock.yaml package.json ./
COPY packages ./packages
COPY apps/api ./apps/api

RUN pnpm deploy /out --filter api --prod --ignore-scripts

# Copy compiled JS from build stage
COPY --from=build /repo/apps/api/dist /out/dist


# 4) Runtime image
FROM node:20-alpine AS runner
ENV NODE_ENV=production
ENV LOG_LEVEL=info

WORKDIR /app

COPY --from=prod-bundle /out/ ./

EXPOSE 3000

CMD ["node", "dist/src/index.js"]
