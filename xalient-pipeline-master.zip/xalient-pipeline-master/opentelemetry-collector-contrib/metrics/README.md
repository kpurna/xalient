https://opentelemetry.io/docs/specs/semconv/registry/attributes/network/  
https://opentelemetry.io/docs/specs/semconv/system/system-metrics/
