import { drizzle } from "drizzle-orm/node-postgres";
import { reset } from "drizzle-seed";
import env from "../env.js";
import { alerts } from "./schema/alerts.js";
import { changes } from "./schema/changes.js";
import { interfaces } from "./schema/interfaces.js";
import { inventory } from "./schema/inventory.js";
import { smarts_discovery_status_rgt } from "./schema/smarts_discovery_status_rgt.js";

async function truncate() {
  // if (env.NODE_ENV === "production") {
  //   console.log("Skipping table reset: running in production environment.");
  //   return;
  // }

  const db = drizzle(env.DATABASE_URL);
  await reset(db, { alerts, changes, smarts_discovery_status_rgt, interfaces, inventory });
  console.log("All tables truncated");
}

truncate();
