import { ThemeProviderContext } from "@/context/theme-context";
import "ag-charts-enterprise";
import type { AgChartThemeName } from "ag-charts-enterprise";
import { AgCharts } from "ag-charts-react";
import { useContext, type FC, type ReactElement } from "react";
import type { ChartTypes } from "./types";
// import { LicenseManager } from "ag-charts-enterprise";
// LicenseManager.setLicenseKey("your License Key"); # todo

const Chart: FC<ChartTypes> = ({ series, data, axes }): ReactElement => {
  const context = useContext(ThemeProviderContext);

  return (
    <AgCharts
      options={{
        theme: (context?.theme === "dark" ? "ag-default-dark" : "ag-default") as AgChartThemeName,
        title: {
          enabled: false
        },
        data,
        series,
        legend: {
          enabled: true
        },
        zoom: {
          enabled: true
        },
        contextMenu: {
          items: ["defaults"]
        },
        axes: axes,
        height: 350,
        background: {
          fill: "transparent"
        }
      }}
    />
  );
};

export default Chart;
