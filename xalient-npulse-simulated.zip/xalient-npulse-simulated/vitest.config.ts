import { defineConfig } from "vitest/config.js";

export default defineConfig({
  test: {
    projects: ["apps/*"]
  }
});
