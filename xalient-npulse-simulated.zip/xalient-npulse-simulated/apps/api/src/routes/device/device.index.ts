import { createRouter } from "../../lib/create-app.js";
import * as handlers from "./device.js";
import * as routes from "./device.routes.js";

const router = createRouter()
  .openapi(routes.deviceData, handlers.deviceData)
  .openapi(routes.stats, handlers.stats)
  .openapi(routes.deviceAlerts, handlers.deviceAlerts)
  .openapi(routes.deviceChanges, handlers.deviceChanges)
  .openapi(routes.alerts, handlers.allAlerts)
  .openapi(routes.deviceInterfaces, handlers.deviceInterfaces)
  .openapi(routes.deviceDetails, handlers.deviceDetails);

export default router;
