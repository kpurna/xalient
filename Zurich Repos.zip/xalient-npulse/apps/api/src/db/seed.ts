import { faker } from "@faker-js/faker";
import type { InferInsertModel } from "drizzle-orm";
import { drizzle, NodePgDatabase } from "drizzle-orm/node-postgres";
import type { PgTable } from "drizzle-orm/pg-core";
import env from "../env.js";
import { alarms } from "./schema/alarms.js";
import { changes } from "./schema/changes.js";
import { interfaces } from "./schema/interfaces.js";
import { inventory } from "./schema/inventory.js";
import { settings } from "./schema/settings.js";
import { smarts_discovery_status_rgt } from "./schema/smarts_discovery_status_rgt.js";

function parseArgs() {
  const args = process.argv.slice(2);
  return args.reduce(
    (acc, arg) => {
      const [key, value] = arg.replace(/^--/, "").split("=");
      acc[key] = parseInt(value, 10) || 0;
      return acc;
    },
    {} as Record<string, number>
  );
}

function chunkArray<T>(arr: T[], size: number): T[][] {
  // Will turn an array of [2,3,4,5] into chunks of size {n} e.g. 2 [[2,3], [4,5]]
  const chunks: T[][] = [];
  for (let i = 0; i < arr.length; i += size) {
    chunks.push(arr.slice(i, i + size));
  }
  return chunks;
}

async function insertInChunks<TTable extends PgTable>(
  db: NodePgDatabase,
  table: TTable,
  records: InferInsertModel<TTable>[],
  chunkSize = 50
): Promise<void> {
  for (const chunk of chunkArray(records, chunkSize)) {
    await db.insert(table).values(chunk);
  }
}
async function main() {
  const db = drizzle(env.DATABASE_URL);
  const args = parseArgs();

  for (const [tableName, count] of Object.entries(args)) {
    if ((count as number) > 0) {
      switch (tableName) {
        // case "alerts": {
        //   const records = Array.from({ length: Number(count) }).map(() => {
        //     const now = Date.now();
        //     const offset = faker.number.int({ min: 0, max: 30 * 24 * 60 * 60 * 1000 });
        //     const first = now - offset;
        //     const last = faker.number.int({ min: first, max: now });
        //     const clear = faker.datatype.boolean() ? faker.number.int({ min: last, max: now }) : 0;

        //     return {
        //       device_name: faker.helpers.arrayElement(Array.from({ length: 32 }, (_, i) => `device-${i + 1}`)),
        //       first,
        //       last,
        //       clear,
        //       assigned_to: faker.person.fullName(),
        //       severity: faker.helpers.arrayElement(["LOW", "HIGH", "MEDIUM"]),
        //       message: faker.lorem.sentence(),
        //       comments: faker.lorem.sentence(),
        //       occurrences: faker.number.int({ min: 1, max: 100 })
        //     };
        //   });

        //   await insertInChunks(db, alerts, records);
        //   break;
        // }
        case "alarms": {
          const records = Array.from({ length: Number(count) }).map(() => {
            const now = faker.date.recent();
            const alarmRaisedTime = faker.date.past({ years: 1, refDate: now });
            const alarmChangedTime = faker.date.between({ from: alarmRaisedTime, to: now });
            const alarmClearedTime = faker.datatype.boolean() ? faker.date.between({ from: alarmChangedTime, to: now }) : null;
            const alarmReportingTime = faker.date.between({ from: alarmRaisedTime, to: now });

            return {
              id: faker.string.uuid(),
              alarmRaisedTime,
              alarmClearedTime,
              alarmedObjectType: faker.helpers.arrayElement(["Router", "Switch", "Firewall", "Server"]),
              correlatedAlarm: { correlationId: faker.string.uuid(), rootAlarm: faker.datatype.boolean() },
              btCustomer: faker.company.name(),
              alarmReportingTime,
              alarmedObject: { objectId: faker.string.uuid(), objectName: faker.commerce.productName() },
              alarmChangedTime,
              perceivedSeverity: faker.helpers.arrayElement(["Critical", "Major", "Minor", "Warning"]),
              probableCause: faker.hacker.verb(),
              btElementClass: faker.commerce.department(),
              affectedService: { serviceId: faker.string.uuid(), serviceName: faker.commerce.productName() },
              ackSystemId: faker.string.alphanumeric(8),
              state: faker.helpers.arrayElement(["Active", "Cleared", "Acknowledged"]),
              externalAlarmId: faker.string.alphanumeric(12).toUpperCase(),
              parentAlarm: { parentId: faker.string.uuid() },
              isRootCause: faker.datatype.boolean(),
              btSourceSystem: faker.helpers.arrayElement(["SolarWinds", "PRTG", "Nagios", "Custom"]),
              ackUserId: faker.string.alphanumeric(8),
              btInstanceName: faker.commerce.productName(),
              btCount: faker.number.int({ min: 1, max: 10 }).toString(),
              btUserDefined: faker.lorem.word(),
              sourceSystemId: faker.string.alphanumeric(12).toUpperCase(),
              btNtnId: faker.string.alphanumeric(8).toUpperCase(),
              btPewMso: faker.string.alphanumeric(8).toUpperCase(),
              btAffectedCircuit: faker.string.alphanumeric(8).toUpperCase(),
              ackState: faker.helpers.arrayElement(["Acknowledged", "Unacknowledged"]),
              alarmType: faker.helpers.arrayElement(["CommunicationsAlarm", "ProcessingErrorAlarm"]),
              specificProblem: faker.lorem.sentence(),
              plannedOutageIndicator: faker.helpers.arrayElement(["Yes", "No"]),
              btServerName: faker.internet.domainWord(),
              alarmDetails: faker.lorem.paragraph(),
              category: faker.helpers.arrayElement(["Network", "Hardware", "Software"]),
              incidentId: faker.string.alphanumeric(10).toUpperCase(),
              btSite: faker.location.city()
            };
          });

          await insertInChunks(db, alarms, records);
          break;
        }
        case "changes": {
          const records = Array.from({ length: Number(count) }).map(() => {
            const now = Date.now();
            const plannedStart = now - faker.number.int({ min: 0, max: 30 * 24 * 60 * 60 * 1000 });
            const plannedEnd =
              plannedStart + faker.number.int({ min: 1 * 60 * 60 * 1000, max: 7 * 24 * 60 * 60 * 1000 });

            return {
              change_number: `CHG${faker.number.int({ min: 100000, max: 999999 })}`,
              assignment_group: faker.helpers.arrayElement([
                "Network Team",
                "Server Ops",
                "Database Admins",
                "Security",
                "Service Desk"
              ]),
              category: faker.helpers.arrayElement(["Hardware", "Software", "Network", "Security", "Maintenance"]),
              short_description: faker.lorem.sentence(),
              assigned_to: faker.person.fullName(),
              planned_start_date: plannedStart,
              planned_end_date: plannedEnd,
              state: faker.helpers.arrayElement(["Scheduled", "In Progress", "Completed", "Cancelled"]),
              close_code: faker.helpers.arrayElement(["Successful", "Unsuccessful", "Cancelled", "No Impact"])
            };
          });

          await insertInChunks(db, changes, records);
          break;
        }

        case "interfaces": {
          const records = Array.from({ length: Number(count) }).map(() => {
            return {
              region: faker.location.state(),
              country: faker.location.country(),
              site_name: faker.company.name(),
              device_name: faker.helpers.arrayElement(Array.from({ length: 32 }, (_, i) => `device-${i + 1}`)),
              name: faker.lorem.word(),
              description: faker.lorem.words(10),
              speed: faker.helpers.arrayElement(["100Mbps", "1Gbps", "10Gbps"]),
              inbound_util: faker.number.int({ min: 0, max: 100 }) + "%",
              outbound_util: faker.number.int({ min: 0, max: 100 }) + "%",
              will_be_exception: faker.datatype.boolean(),
              overall_exception: faker.helpers.arrayElement(["None", "Minor", "Major", "Critical"]),
              status: faker.helpers.arrayElement(["IN-SERVICE", "CEASED"])
            };
          });

          await insertInChunks(db, interfaces, records);
          break;
        }

        case "settings": {
          const records = [
            {
              device_name: "R1",
              ip: "",
              snmp: false,
              netflow: false,
              sys_logs: false,
              is_monitored: false
            },
            {
              device_name: "R2",
              ip: "",
              snmp: false,
              netflow: false,
              sys_logs: false,
              is_monitored: false
            },
            {
              device_name: "R3",
              ip: "",
              snmp: false,
              netflow: false,
              sys_logs: false,
              is_monitored: false
            }
          ];

          await insertInChunks(db, settings, records);
          break;
        }

        case "inventory": {
          const hostnames = Array.from({ length: Number(count) }, (_, i) => `device-${i + 1}`);
          const records = hostnames.map((hostname) => {
            return {
              bfg_hostname: hostname,
              site_cus_type: faker.helpers.arrayElement(["Enterprise", "Edge"]),
              site_name: faker.company.name(),
              site_cus_region: faker.helpers.arrayElement(["NA", "EMEA", "APAC", "LATAM"]),
              adr_country: faker.location.country(),
              msa: faker.location.city(),
              lsa: faker.location.state(),
              bfg_ip_address: faker.internet.ip(),
              vendor: faker.helpers.arrayElement(["Cisco"]),
              model: faker.helpers.arrayElement(["ASR-9001", "MX480", "7050X3", "Nexus9K"]),
              serial_number: faker.string.alphanumeric(12).toUpperCase(),
              final_hw_eovss: faker.date.future().toISOString().split("T")[0],
              hw_eovss_year: faker.date.future().getFullYear().toString(),
              final_hw_eol: faker.date.future().toISOString().split("T")[0],
              hw_eol_year: faker.date.future().getFullYear().toString(),
              current_ios_version: faker.system.semver(),
              sw_eol_date: faker.date.future().toISOString().split("T")[0],
              sw_eol_year: faker.date.future().getFullYear().toString(),
              ssv_label: faker.helpers.arrayElement(["SSV-A", "SSV-B", "SSV-C"]),
              site_type: faker.helpers.arrayElement(["Hub", "Spoke", "HQ"]),
              tower: faker.helpers.arrayElement(["Tower1", "Tower2", "Tower3"]),
              bfg_ntn_type: faker.helpers.arrayElement(["MPLS", "Internet", "5G"]),
              sw_status: faker.helpers.arrayElement(["Active", "Expired", "Pending"]),
              hw_customer_dependency: faker.datatype.boolean(),
              sw_customer_dep_dependency: faker.datatype.boolean(),
              riverbed: faker.datatype.boolean(),
              hw_exceptions: faker.lorem.word(),
              major_minor_sw_version_upgrade: faker.datatype.boolean(),
              recommended_ios: faker.datatype.boolean(),
              refesh_status: faker.helpers.arrayElement(["Planned", "In Progress", "Completed"]),
              rfq: faker.string.alphanumeric(8).toUpperCase(),
              risk_reference: faker.string.alphanumeric(6).toUpperCase(),
              action: faker.helpers.arrayElement(["Monitor", "Upgrade", "Replace"])
            };
          });

          await insertInChunks(db, inventory, records);
          break;
        }

        case "smarts_discovery_status_rgt": {
          const records = Array.from({ length: Number(count) }).map(() => {
            return {
              man_hostname: faker.internet.domainName(),
              ip_address: faker.internet.ipv4(),
              previous_successful_discovery: faker.datatype.boolean(),
              current_discovery_error_message: faker.helpers.arrayElement([
                "Successfully Discovered",
                "No response from SNMP agent"
              ]),
              model: faker.helpers.arrayElement([
                "Cisco 2900",
                "Juniper MX960",
                "HP ProCurve",
                "Dell S-Series",
                "Arista 7500R"
              ]),
              type: faker.helpers.arrayElement(["Router", "Switch", "Firewall", "Server", "Load Balancer"]),
              certification: faker.helpers.arrayElement(["ISO 27001", "CCIE", "CompTIA Security+", "CEH", "None"]),
              apm_name: faker.commerce.productName(),
              first_discovered: faker.date.past().toISOString(),
              last_discovered: faker.date.recent().toISOString(),
              access_mode: faker.helpers.arrayElement(["SSH", "Telnet", "SNMP", "HTTPS"])
            };
          });

          await insertInChunks(db, smarts_discovery_status_rgt, records);
          break;
        }

        default:
          console.warn(`No seeder defined for table: ${tableName}`);
      }
    }
  }
}

main();
