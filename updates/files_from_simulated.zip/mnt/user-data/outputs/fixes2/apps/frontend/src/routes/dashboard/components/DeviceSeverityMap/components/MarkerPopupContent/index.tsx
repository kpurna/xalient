import type { MouseEvent } from "react";
import { useMap } from "react-leaflet";
import { deriveSeverityLevel } from "../../helpers";
import type { MarkerPopupContentProps } from "../../types";

export const MarkerPopupContent = ({ marker, onNavigate }: MarkerPopupContentProps) => {
  const map = useMap();

  return (
    <div className="min-w-[220px] space-y-2 text-xs">
      <div className="space-y-1">
        <div className="text-sm font-semibold">Site name: {marker.label}</div>
        <div className="text-neutral-500">
          Dominant severity: <span className="font-medium">{marker.severity}</span>
        </div>
        <div className="text-neutral-500">
          Total alerts: <span className="font-medium">{marker.alertCount ?? 0}</span>
        </div>
      </div>

      <div className="space-y-1">
        <div className="font-medium">Severity counts</div>
        <div className="grid grid-cols-2 gap-1 text-neutral-600">
          {Object.entries(marker.severityCounts).map(([key, count]) => (
            <span key={key}>
              {key}: <span className="font-medium">{count}</span>
            </span>
          ))}
        </div>
      </div>

      <div className="space-y-1">
        <div className="font-medium">Devices</div>
        <ul className="space-y-1">
          {marker.devices.map((device) => {
            const severityLevel = deriveSeverityLevel(device);
            const hostname = device.bfg_hostname ?? "";
            return (
              <li key={hostname}>
                <button
                  type="button"
                  onClick={(event: MouseEvent<HTMLButtonElement>) => {
                    event.preventDefault();
                    map.closePopup();
                    onNavigate(hostname);
                  }}
                  className="flex w-full items-start justify-between gap-2 rounded-md px-2 py-1 text-left transition hover:bg-neutral-100 dark:hover:bg-neutral-800"
                >
                  <span className="font-medium text-neutral-900 dark:text-neutral-100">{hostname}</span>
                  <span className="text-neutral-500">
                    {severityLevel} · {device.number_of_alerts ?? 0} alerts
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
      </div>
    </div>
  );
};
