export type AddDeviceFormValues = {
  device_name: string;
  ip: string;
  netflow: boolean;
  snmp: boolean;
  sys_logs: boolean;
};

export type AddDeviceDialogProps = {
  open: boolean;
  isSubmitting: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (values: AddDeviceFormValues) => Promise<void>;
};
