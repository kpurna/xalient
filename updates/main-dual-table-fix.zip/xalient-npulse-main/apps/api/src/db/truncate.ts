import { drizzle } from "drizzle-orm/node-postgres";
import { reset } from "drizzle-seed";
import env from "../env.js";
import { alarms, alerts } from "./schema/alerts.js";
import { changes } from "./schema/changes.js";
import { interfaces } from "./schema/interfaces.js";
import { inventory } from "./schema/inventory.js";
import { smarts_discovery_status_rgt } from "./schema/smarts_discovery_status_rgt.js";

async function truncate() {
  const db = drizzle(env.DATABASE_URL);
  // Truncates both the real alarms table and the simulated alerts table
  await reset(db, { alarms, alerts, changes, smarts_discovery_status_rgt, interfaces, inventory });
  console.log("All tables truncated");
}

truncate();
