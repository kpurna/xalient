import { toast as sonnerToast } from "sonner";
import { Toast } from ".";
import type { ToastProps } from "./types";
const createToast = (props: Omit<ToastProps, "id">) => {
  return sonnerToast.custom((id) => <Toast {...props} id={id} />);
};

export { createToast };
