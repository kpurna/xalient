import { Button } from "@/components/ui/button";
import { Spinner } from "@/components/ui/spinner";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useBreadcrumbs } from "@/hooks/use-breadcrumbs";
import { api } from "@/lib/api";
import { useQuery } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import type { InferResponseType } from "hono/client";
import { useMemo, useState } from "react";
import z from "zod";
import { LogJsonDialog } from "./components/LogJsonDialog";
import { MOCK_LOGS } from "./mockData";
import type { LogEntry } from "./types";

type LogsResponse = InferResponseType<typeof api.logs.$get>;

export const Route = createFileRoute("/logs/")({
  validateSearch: z.object({ device: z.string() }),
  component: LogsPage
});

function LogsPage() {
  const { device = "" } = Route.useSearch();

  useBreadcrumbs({
    type: "set",
    breadcrumbs: [
      {
        title: "Settings",
        href: "/settings"
      }
    ]
  });

  const query = useQuery({
    queryKey: ["logs", device],
    enabled: Boolean(device),
    queryFn: async () => {
      const response = await api.logs.$get({
        query: {
          device,
          limit: 100
        }
      });

      if (!response.ok) {
        throw new Error("Failed to load logs.");
      }

      const result: LogsResponse = await response.json();
      return result;
    }
  });

  const isMockMode = true;
  const [selectedLog, setSelectedLog] = useState<LogEntry | null>(null);
  const logs = useMemo<LogEntry[]>(
    () => (isMockMode ? MOCK_LOGS : (query.data?.data.logs ?? [])),
    [isMockMode, query.data]
  );
  const total = isMockMode ? MOCK_LOGS.length : (query.data?.data.total ?? 0);

  const selectedJson = useMemo(() => {
    if (!selectedLog?.message) {
      return null;
    }
    try {
      return JSON.parse(selectedLog.message);
    } catch {
      return null;
    }
  }, [selectedLog]);

  return (
    <>
      <div className="space-y-6 p-4">
        {query.isLoading ? (
          <div className="flex min-h-[200px] items-center justify-center rounded-2xl border bg-white p-6 dark:border-neutral-800 dark:bg-neutral-900">
            <Spinner />
          </div>
        ) : null}

        {query.isError ? (
          <div className="border-destructive/50 bg-destructive/10 text-destructive rounded-2xl border p-6">
            {query.error instanceof Error ? query.error.message : "Unable to load logs at the moment."}
          </div>
        ) : null}

        {!device && (
          <div className="text-muted-foreground rounded-2xl border bg-white p-6 dark:border-neutral-800 dark:bg-neutral-900">
            Showing mock log data. Enter a device name above to view live logs and totals.
          </div>
        )}

        {isMockMode || query.isSuccess ? (
          <div className="flex flex-col gap-4 rounded-2xl border bg-white p-6 dark:border-neutral-800 dark:bg-neutral-900">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h2 className="text-lg font-semibold">{device}</h2>
                  <p className="text-muted-foreground text-sm">Total logs: {total.toLocaleString()}</p>
                  <p className="text-muted-foreground text-sm">Collector: collector-a • Sensor: sensor-a</p>
                </div>
              </div>
            </div>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[200px]">Timestamp</TableHead>
                    <TableHead className="w-[140px]">Tag</TableHead>
                    <TableHead>Message</TableHead>
                    <TableHead className="w-[120px] text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {logs.length ? (
                    logs.map((log, index) => (
                      <TableRow key={`${log.time}-${index}`}>
                        <TableCell className="align-middle font-mono text-xs">{log.time}</TableCell>
                        <TableCell className="align-middle text-sm">{log.tag ?? "-"}</TableCell>
                        <TableCell className="align-middle text-sm">
                          <span className="font-mono text-xs break-words whitespace-pre-wrap">
                            {log.message ?? "-"}
                          </span>
                        </TableCell>
                        <TableCell className="text-right align-middle">
                          <Button variant="ghost" size="sm" disabled={!log.message} onClick={() => setSelectedLog(log)}>
                            View JSON
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={4} className="text-muted-foreground h-24 text-center">
                        No logs found for this device.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </div>
        ) : null}
      </div>
      <LogJsonDialog log={selectedLog} parsed={selectedJson} onClose={() => setSelectedLog(null)} />
    </>
  );
}
