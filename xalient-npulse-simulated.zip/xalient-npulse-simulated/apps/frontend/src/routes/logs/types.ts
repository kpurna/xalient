export type LogEntry = {
  time: string;
  tag: string | null;
  message: string | null;
};
