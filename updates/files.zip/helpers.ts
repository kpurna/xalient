import type { DeviceData } from "@/components/table/types";
import type { DivIcon, LatLngTuple } from "leaflet";
import L from "leaflet";
import { useEffect } from "react";
import { useMap } from "react-leaflet";
import type { DeviceMarker, DeviceMarkerWithIcon, SeverityLevel } from "./types";

export const SEVERITY_RANK: Record<SeverityLevel, number> = {
  Critical: 4,
  Major: 3,
  Minor: 2,
  Warning: 1
};

export const SEVERITY_META: Record<SeverityLevel, { color: string; description: string }> = {
  Critical: { color: "#ef4444", description: "Critical alerts present" },
  Major: { color: "#f97316", description: "Major degradation detected" },
  Minor: { color: "#facc15", description: "Minor issues observed" },
  Warning: { color: "#3b82f6", description: "Baseline operating conditions" }
};

export const buildMarkerIcon = (severity: SeverityLevel, label: string): DivIcon =>
  L.divIcon({
    html: `
      <div style="
        display:flex;
        align-items:center;
        justify-content:center;
        width:32px;
        height:32px;
        border-radius:9999px;
        background:${SEVERITY_META[severity].color};
        color:#ffffff;
        font-size:11px;
        font-weight:700;
        border:2px solid #f8fafc;
        box-shadow:0 6px 14px rgba(15, 23, 42, 0.18);
      ">
        ${label}
      </div>
    `,
    className: "",
    iconSize: [32, 32],
    iconAnchor: [16, 16],
    popupAnchor: [0, -18]
  });

export const generateFallbackPosition = (seed: string): LatLngTuple => {
  let latHash = 0;
  let lngHash = 0;

  for (let i = 0; i < seed.length; i++) {
    const code = seed.charCodeAt(i);
    latHash = (latHash + ((code * (i + 1)) % 180)) % 180;
    lngHash = (lngHash + ((code * (i + 7)) % 360)) % 360;
  }

  const lat = Math.max(Math.min(latHash - 90, 85), -85);
  const lng = Math.max(Math.min(lngHash - 180, 175), -175);

  return [lat, lng];
};

export const deriveSeverityLevel = (entry: DeviceData): SeverityLevel => {
  if (entry.severity >= 3) return "Critical";
  if (entry.number_of_alerts >= 10) return "Major";
  if (entry.number_of_alerts >= 5 || entry.severity === 1) return "Minor";
  return "Warning";
};

export const buildMarkerData = (
  devices?: DeviceData[]
): {
  markers: DeviceMarker[];
  severityTotals: Record<SeverityLevel, number>;
} => {
  if (!devices) {
    return {
      markers: [],
      severityTotals: {
        Critical: 0,
        Major: 0,
        Minor: 0,
        Warning: 0
      }
    };
  }

  const grouped = new Map<
    string,
    {
      devices: DeviceData[];
      position: LatLngTuple;
      label: string;
    }
  >();

  for (const device of devices) {
    const key = `${device.site_name}-${device.country ?? ""}`.toLowerCase();
    const group = grouped.get(key);

    if (!group) {
      grouped.set(key, {
        devices: [device],
        position: generateFallbackPosition(`${device.site_name}-${device.country ?? ""}`),
        label: device.site_name ?? ""
      });
    } else {
      group.devices.push(device);
    }
  }

  const totals: Record<SeverityLevel, number> = {
    Critical: 0,
    Major: 0,
    Minor: 0,
    Warning: 0
  };

  const markerList = Array.from(grouped.entries()).map(([key, group]) => {
    const severityCounts: Record<SeverityLevel, number> = {
      Critical: 0,
      Major: 0,
      Minor: 0,
      Warning: 0
    };

    let dominantSeverity: SeverityLevel = "Warning";
    let combinedAlerts = 0;

    for (const device of group.devices) {
      const level = deriveSeverityLevel(device);
      severityCounts[level] += 1;
      const parsedAlerts = Number(device.number_of_alerts ?? 0);
      combinedAlerts += Number.isNaN(parsedAlerts) ? 0 : parsedAlerts;
      if (SEVERITY_RANK[level] > SEVERITY_RANK[dominantSeverity]) {
        dominantSeverity = level;
      }
    }

    (Object.entries(severityCounts) as [SeverityLevel, number][]).forEach(([level, count]) => {
      totals[level] += count;
    });

    return {
      id: key,
      position: group.position,
      label: group.label,
      severity: dominantSeverity,
      alertCount: combinedAlerts,
      devices: group.devices,
      severityCounts
    };
  });

  return {
    markers: markerList,
    severityTotals: totals
  };
};

export const DEFAULT_CENTER: LatLngTuple = [20, 0];

export const DeviceMapBoundsUpdater = ({ markers }: { markers: DeviceMarkerWithIcon[] }) => {
  const map = useMap();

  useEffect(() => {
    if (!map) return;

    if (markers.length === 0) {
      map.setView(DEFAULT_CENTER, 1);
      return;
    }

    if (markers.length === 1) {
      map.setView(markers[0].position, 3);
      return;
    }

    const bounds = L.latLngBounds(markers.map((marker) => marker.position));
    map.fitBounds(bounds, { padding: [48, 48], maxZoom: 5 });
  }, [map, markers]);

  return null;
};
