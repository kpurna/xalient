import { fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import { DataTable } from ".";
import type { DeviceAlert } from "./types";

describe("DataTable", () => {
  const data = [
    {
      id: 1,
      device_name: "dev 1",
      first: 1759765646000,
      last: 1759765646000,
      clear: 1759765646000,
      assigned_to: "abcd",
      severity: "LOW",
      message: "",
      comments: "",
      occurrences: 190,
      updated_at: "1759765646000",
      created_at: "1759765646000",
      deleted_at: "0"
    },
    {
      id: 2,
      device_name: "dev 1",
      first: 1759765646000,
      last: 1759765646000,
      clear: 1759765646000,
      assigned_to: "abcd",
      severity: "LOW",
      message: "",
      comments: "",
      occurrences: 190,
      updated_at: "1759765646000",
      created_at: "1759765646000",
      deleted_at: "0"
    },
    {
      id: 3,
      device_name: "dev 1",
      first: 1759765646000,
      last: 1759765646000,
      clear: 1759765646000,
      assigned_to: "abcd",
      severity: "LOW",
      message: "",
      comments: "",
      occurrences: 190,
      updated_at: "1759765646000",
      created_at: "1759765646000",
      deleted_at: "0"
    }
  ] as DeviceAlert[];

  const defaultProps = {
    searchBy: "",
    sorting: [],
    paginationFilters: { pageIndex: 0, pageSize: 10 },
    total: 1,
    setPaginationFilters: vi.fn(),
    setSearchBy: vi.fn(),
    setSorting: vi.fn(),
    isLoading: false
  };

  it("renders the table and data", () => {
    render(<DataTable data={data} tableName={"deviceAlerts"} {...defaultProps} />);
  });

  it('renders "No results" when there is no data', () => {
    render(<DataTable {...defaultProps} tableName={"deviceAlerts"} data={[]} total={0} />);
    expect(screen.getByText("No results.")).toBeInTheDocument();
  });

  it("calls setSearchBy when user types in filter input", () => {
    render(<DataTable data={data} tableName={"deviceAlerts"} {...defaultProps} />);
    const input = screen.getByPlaceholderText("Filter...");
    fireEvent.change(input, { target: { value: "abc" } });
    expect(defaultProps.setSearchBy).toHaveBeenCalledWith("abc");
  });

  it("matches snapshot", () => {
    const { asFragment } = render(<DataTable data={data} tableName={"deviceAlerts"} {...defaultProps} />);
    expect(asFragment()).toMatchSnapshot();
  });
});
