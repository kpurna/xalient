import type { SettingRow } from "../../types";

export type DiscoveredDevicesTabProps = {
  devices: SettingRow[];
  canAddHost: boolean;
  hasActiveEdit: boolean;
  isMutationPending: boolean;
  onAddHost: () => void;
  onShowLogsSummary: (device: SettingRow) => void;
  onPromote: (device: SettingRow) => Promise<void>;
};
