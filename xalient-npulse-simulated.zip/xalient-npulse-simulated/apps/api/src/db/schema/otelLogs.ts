import { jsonb, pgTable, text, timestamp } from "drizzle-orm/pg-core";

export const otelLogs = pgTable("otel_logs", {
  time: timestamp({ withTimezone: true }).notNull(),
  tag: text(),
  data: jsonb().notNull()
});
