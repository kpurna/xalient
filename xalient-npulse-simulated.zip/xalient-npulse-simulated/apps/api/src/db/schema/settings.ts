import { boolean, pgTable, serial, varchar } from "drizzle-orm/pg-core";
import { createSelectSchema } from "drizzle-zod";

export const settings = pgTable("settings", {
  id: serial().primaryKey().unique(),
  device_name: varchar({ length: 255 }).notNull(),
  ip: varchar({ length: 255 }).notNull(),
  snmp: boolean().default(false).notNull(),
  netflow: boolean().default(false).notNull(),
  sys_logs: boolean().default(false).notNull(),
  is_monitored: boolean().default(false).notNull()
});

export const selectSettingsSchema = createSelectSchema(settings);
