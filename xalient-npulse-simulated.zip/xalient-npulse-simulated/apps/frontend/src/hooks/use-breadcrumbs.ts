import { useAppStore, type TBreadcrumb } from "@/store";
import { useEffect } from "react";

interface BreadcrumbProps {
  type: "add" | "set";
  breadcrumbs?: TBreadcrumb[] | TBreadcrumb;
}

export const useBreadcrumbs = ({ type, breadcrumbs }: BreadcrumbProps) => {
  const { addBreadcrumbs, setBreadcrumbs } = useAppStore();

  useEffect(() => {
    if (!breadcrumbs) return;

    if (type === "add" && breadcrumbs) {
      addBreadcrumbs(Array.isArray(breadcrumbs) ? breadcrumbs : [breadcrumbs]);
    }
    if (type === "set" && breadcrumbs) {
      setBreadcrumbs(Array.isArray(breadcrumbs) ? breadcrumbs : [breadcrumbs]);
      //  Set breadcrumbs complete history
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
};
