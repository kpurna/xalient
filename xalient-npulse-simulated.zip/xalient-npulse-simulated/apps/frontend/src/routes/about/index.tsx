import { useBreadcrumbs } from "@/hooks/use-breadcrumbs";
import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/about/")({
  component: About
});

function About() {
  useBreadcrumbs({
    type: "set",
    breadcrumbs: [
      {
        title: "Dashboard",
        href: "/dashboard"
      },
      {
        title: "About",
        href: "/about"
      }
    ]
  });
  return <div className="p-4"></div>;
}
