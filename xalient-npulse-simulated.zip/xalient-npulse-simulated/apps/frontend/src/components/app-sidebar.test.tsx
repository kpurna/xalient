import { customRender } from "@/__tests__/setup";
import { AppSidebar } from "@/components/app-sidebar";
import { act } from "react";
// Mock the sidebarRoutes in globalConfig
const mockSidebarRoutes = [
  { title: "Dashboard", path: "/dashboard", icon: <span data-testid="icon-dashboard" /> },
  { title: "Settings", path: "/settings", icon: <span data-testid="icon-settings" /> }
];

describe("AppSidebar", () => {
  beforeEach(async () => {
    await act(async () => {
      customRender(<AppSidebar routes={mockSidebarRoutes} />);
    });
  });

  it("renders sidebar items with correct titles and icons", () => {
    mockSidebarRoutes.forEach((route) => {
      const linkElement = document.querySelector(`[data-testid="link-${route.title}"]`);
      expect(linkElement).toBeInTheDocument();
      expect(linkElement).toHaveTextContent(route.title);
    });
  });
});
