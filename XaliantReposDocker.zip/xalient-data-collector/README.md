# OpenTelemetry S3 → SQS → OTel Collector → PostgreSQL Pipeline

WIP: This project provides a full pipeline for processing data from
Amazon S3 bucket and pushing it into PostgreSQL tables using the OpenTelemetry
Collector.

---

### Running

To start the containers:

```
docker compose up -d
```

To stop the containers:

```
docker compose down
```
