SELECT
  (data->'__internal__'->'log_metadata'->'otlp'->'attributes'->>'router')          AS local_router,
  (data->'__internal__'->'log_metadata'->'otlp'->'attributes'->>'local_if')        AS local_if,
  (data->'__internal__'->'log_metadata'->'otlp'->'attributes'->>'remote_sys')      AS remote_router,
  (data->'__internal__'->'log_metadata'->'otlp'->'attributes'->>'remote_port_desc')AS remote_if,
  "time"                                                                            AS ts
FROM public.otel_logs
WHERE "time" > now() - interval '5 minutes'
  AND data->'__internal__'->'log_metadata'->'otlp'->'attributes'->>'log_type' = 'lldp';