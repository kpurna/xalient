# Backend Template

Hono with NodeJs Setup

## Features

✅ Hono + NodeJs

✅ Vitest

✅ Sentry Error Tracking

✅ Environment variable management (dotenv)

✅ Zod library for schemas

✅ Swagger UI Documentation using Zod OpenAPI Hono

✅ Drizzle ORM

## Guidelines

This section explains key decisions and the intended way of working in this codebase.

### Entrypoints

- `index.ts` should generally be left untouched.
- The real entrypoint for development is in [/src/routes](/src/routes). (see [routing basics](/src/routes/readme.md)).

### Testing

- **Unit & Integration Tests**: keep close to the code they test (e.g. `route.test.ts` alongside the route).

### Environment Variables

- All required environment variables should be documented in `.env.example`.

### Local PostgreSQL Setup for Drizzle ORM

1. **Install Docker**  
   Ensure Docker is installed on your system.

2. **Pull the PostgreSQL Image**
   ```bash
   docker pull postgres
   ```
3. **Start a PostgreSQL Container**
   ```bash
   docker run --name drizzle-postgres -e POSTGRES_PASSWORD=<PASSWORD> -d -p 5432:5432 postgres
   ```
4. **Configure the Database URL**
   ```
   DATABASE_URL=postgresql://postgres:<PASSWORD>@localhost:5432/postgres
   ```
