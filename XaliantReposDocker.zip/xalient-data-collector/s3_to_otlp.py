import json, os, time, logging
from dateutil import parser as dateparser
import boto3, requests
from botocore.config import Config
from dotenv import load_dotenv

FRESHNESS_WINDOW_SECONDS = 1200259200  # 3 days

load_dotenv()
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

aws_access_key_id = os.environ["AWS_ACCESS_KEY_ID"]
aws_secret_access_key = os.environ["AWS_SECRET_ACCESS_KEY"]

session = boto3.Session(
    region_name=os.environ["AWS_REGION"],
    aws_access_key_id=aws_access_key_id,
    aws_secret_access_key=aws_secret_access_key,
)
sqs = session.client("sqs", config=Config(retries={"max_attempts": 5}))
s3 = session.client(
    "s3",
    aws_access_key_id=aws_access_key_id,
    aws_secret_access_key=aws_secret_access_key,
    region_name="eu-west-1",
    verify=False,
)
queue_url = os.environ["SQS_URL"]
otlp = os.environ.get("OTLP_ENDPOINT", "http://otelcol:4318/v1/logs")


def _parse_record_timestamp(rec):
    ts_str = rec.get("alarmRaisedTime")  # or rec.get("timestamp")
    if not ts_str:
        return None
    try:
        return dateparser.parse(ts_str)
    except (ValueError, TypeError) as exc:
        logging.warning("Failed to parse timestamp '%s': %s", ts_str, exc)
        return None


def _is_recent(rec):
    return True
    parsed_ts = _parse_record_timestamp(rec)
    if not parsed_ts:
        return False
    age_seconds = time.time() - parsed_ts.timestamp()
    if age_seconds > FRESHNESS_WINDOW_SECONDS:
        logging.info(
            "Dropping stale record older than %ss (age=%ss)",
            FRESHNESS_WINDOW_SECONDS,
            age_seconds,
        )
        return False
    else:
        logging.info(
            "New records older than %ss (age=%ss)",
            FRESHNESS_WINDOW_SECONDS,
            age_seconds,
        )
    return True


def to_log_record(rec):
    parsed_ts = _parse_record_timestamp(rec)
    ts_seconds = parsed_ts.timestamp() if parsed_ts else time.time()
    return {
        "timeUnixNano": str(int(ts_seconds * 1e9)),
        "severityText": rec.get("level", "INFO"),
        "body": {"stringValue": rec.get("message", json.dumps(rec))},
        "attributes": [
            {"key": k, "value": {"stringValue": str(v)}} for k, v in rec.items()
        ],
    }


def send_otlp(records):
    payload = {
        "resourceLogs": [
            {
                "resource": {
                    "attributes": [
                        {
                            "key": "service.name",
                            "value": {"stringValue": "s3-json-ingest"},
                        }
                    ]
                },
                "scopeLogs": [
                    {
                        "scope": {"name": "s3_to_otlp"},
                        "logRecords": records,
                    }
                ],
            }
        ],
    }
    resp = requests.post(otlp, json=payload, timeout=10, verify=False)
    resp.raise_for_status()


def process_object(bucket, key):
    obj = s3.get_object(Bucket=bucket, Key=key)
    payload = obj["Body"].read().decode("utf-8").strip()
    if not payload:
        return

    records = []
    try:
        parsed = json.loads(payload)
        if isinstance(parsed, list):
            for item in parsed:
                if _is_recent(item):
                    records.append(to_log_record(item))
        elif isinstance(parsed, dict):
            if _is_recent(parsed):
                records.append(to_log_record(parsed))
        else:
            logging.warning("Unsupported JSON payload: %s", type(parsed))
    except json.JSONDecodeError:
        for line in payload.splitlines():
            line = line.strip()
            if not line:
                continue
            record = json.loads(line)
            if _is_recent(record):
                records.append(to_log_record(record))

    if records:
        send_otlp(records)


while True:
    resp = sqs.receive_message(
        QueueUrl=queue_url,
        MaxNumberOfMessages=1,
        WaitTimeSeconds=20,
    )
    for msg in resp.get("Messages", []):
        try:
            body = json.loads(msg["Body"])
            notif = json.loads(body["Message"]) if "Message" in body else body
            for record in notif.get("Records", []):
                bucket = record["s3"]["bucket"]["name"]
                key = record["s3"]["object"]["key"]
                logging.info("Processing %s/%s", bucket, key)
                process_object(bucket, key)
        except Exception as e:
            print(e)
            logging.exception("Failed to process message")
    time.sleep(1)
