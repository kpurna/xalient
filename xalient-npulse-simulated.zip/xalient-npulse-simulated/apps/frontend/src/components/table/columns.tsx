import { formatDate } from "@/lib/utils";
import { Link } from "@tanstack/react-router";
import type { ColumnDef, SortingState } from "@tanstack/react-table";
import { ArrowUpDown, LinkIcon, MoreHorizontal } from "lucide-react";
import type { Dispatch, SetStateAction } from "react";
import { Button } from "../ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "../ui/dropdown-menu";
import { SEVERITY, SEVERITY_COLORS } from "./helper";
import type { Change, DeviceAlert, DeviceData } from "./types";

export const deviceAlertColumns = ({
  setSorting
}: {
  setSorting: Dispatch<SetStateAction<SortingState>>;
}): ColumnDef<DeviceAlert>[] => {
  return [
    {
      accessorKey: "id",
      header: ({ column }) => {
        return (
          <Button variant="ghost" onClick={() => setSorting([{ id: "id", desc: column.getIsSorted() === "asc" }])}>
            Alert id
            <ArrowUpDown />
          </Button>
        );
      },
      cell: ({ row }) => <div className="capitalize">{row.getValue("id")}</div>
    },

    {
      accessorKey: "first",
      header: ({ column }) => {
        return (
          <Button variant="ghost" onClick={() => setSorting([{ id: "first", desc: column.getIsSorted() === "asc" }])}>
            First
            <ArrowUpDown />
          </Button>
        );
      },
      cell: ({ row }) => <div className="capitalize">{formatDate(row.getValue("first"))}</div>
    },
    {
      accessorKey: "clear",
      header: ({ column }) => {
        return (
          <Button variant="ghost" onClick={() => setSorting([{ id: "clear", desc: column.getIsSorted() === "asc" }])}>
            Clear
            <ArrowUpDown />
          </Button>
        );
      },
      cell: ({ row }) => (
        <div className="capitalize">{row.getValue("clear") === 0 ? "-" : formatDate(row.getValue("clear"))}</div>
      )
    },
    {
      accessorKey: "severity",
      header: ({ column }) => {
        return (
          <Button
            variant="ghost"
            onClick={() => setSorting([{ id: "severity", desc: column.getIsSorted() === "asc" }])}
          >
            Severity
            <ArrowUpDown className="ml-2 h-4 w-4" />
          </Button>
        );
      },
      cell: ({ row }) => {
        const severity = (row.getValue("severity") as string).toLowerCase();
        return (
          <span className={`rounded-full px-2 py-1 text-xs font-medium capitalize ${SEVERITY_COLORS[severity]} `}>
            {severity}
          </span>
        );
      }
    },
    {
      accessorKey: "assigned_to",
      header: ({ column }) => {
        return (
          <Button
            variant="ghost"
            onClick={() => setSorting([{ id: "assigned_to", desc: column.getIsSorted() === "asc" }])}
          >
            Assigned to
            <ArrowUpDown />
          </Button>
        );
      },
      cell: ({ row }) => {
        return <div className="font-medium">{row.getValue("assigned_to")}</div>;
      }
    }
  ];
};

export const changeColumns = ({
  setSorting
}: {
  setSorting: Dispatch<SetStateAction<SortingState>>;
}): ColumnDef<Change>[] => {
  return [
    {
      accessorKey: "change_number",
      header: ({ column }) => {
        return (
          <Button
            variant="ghost"
            onClick={() => setSorting([{ id: "change_number", desc: column.getIsSorted() === "asc" }])}
          >
            Number
            <ArrowUpDown />
          </Button>
        );
      },
      cell: ({ row }) => <div className="capitalize">{row.getValue("change_number")}</div>
    },
    {
      accessorKey: "assignment_group",
      header: ({ column }) => {
        return (
          <Button
            variant="ghost"
            onClick={() => setSorting([{ id: "assignment_group", desc: column.getIsSorted() === "asc" }])}
          >
            Assignment group
            <ArrowUpDown />
          </Button>
        );
      },
      cell: ({ row }) => <div className="capitalize">{row.getValue("assignment_group")}</div>
    },
    {
      accessorKey: "category",
      header: ({ column }) => {
        return (
          <Button
            variant="ghost"
            onClick={() => setSorting([{ id: "category", desc: column.getIsSorted() === "asc" }])}
          >
            Category
            <ArrowUpDown />
          </Button>
        );
      },
      cell: ({ row }) => <div className="capitalize">{row.getValue("category")}</div>
    },
    {
      accessorKey: "short_description",
      header: ({ column }) => {
        return (
          <Button
            variant="ghost"
            onClick={() => setSorting([{ id: "short_description", desc: column.getIsSorted() === "asc" }])}
          >
            Short description
            <ArrowUpDown />
          </Button>
        );
      },
      cell: ({ row }) => <div className="capitalize">{row.getValue("short_description")}</div>
    },
    {
      accessorKey: "planned_start_date",
      header: ({ column }) => {
        return (
          <Button
            variant="ghost"
            onClick={() => setSorting([{ id: "planned_start_date", desc: column.getIsSorted() === "asc" }])}
          >
            Planned start date
            <ArrowUpDown />
          </Button>
        );
      },
      cell: ({ row }) => <div className="lowercase">{formatDate(row.getValue("planned_start_date"))}</div>
    },
    {
      accessorKey: "planned_end_date",
      header: ({ column }) => {
        return (
          <Button
            variant="ghost"
            onClick={() => setSorting([{ id: "planned_end_date", desc: column.getIsSorted() === "asc" }])}
          >
            Planned end date
            <ArrowUpDown />
          </Button>
        );
      },
      cell: ({ row }) => {
        return <div className="text-right font-medium">{formatDate(row.getValue("planned_end_date"))}</div>;
      }
    },
    {
      accessorKey: "state",
      header: ({ column }) => {
        return (
          <Button variant="ghost" onClick={() => setSorting([{ id: "state", desc: column.getIsSorted() === "asc" }])}>
            State
            <ArrowUpDown />
          </Button>
        );
      },
      cell: ({ row }) => {
        return <div className="text-right font-medium">{row.getValue("state")}</div>;
      }
    },
    {
      accessorKey: "close_code",
      header: ({ column }) => {
        return (
          <Button
            variant="ghost"
            onClick={() => setSorting([{ id: "close_code", desc: column.getIsSorted() === "asc" }])}
          >
            Close code
            <ArrowUpDown />
          </Button>
        );
      },
      cell: ({ row }) => {
        return <div className="text-right font-medium">{row.getValue("close_code")}</div>;
      }
    }
  ];
};

export const dashboardColumns = ({
  setSorting
}: {
  setSorting: Dispatch<SetStateAction<SortingState>>;
}): ColumnDef<DeviceData>[] => {
  return [
    {
      accessorKey: "bfg_hostname",
      header: ({ column }) => {
        return (
          <Button
            variant="ghost"
            onClick={() => setSorting([{ id: "bfg_hostname", desc: column.getIsSorted() === "asc" }])}
          >
            Device name
            <ArrowUpDown />
          </Button>
        );
      },
      cell: ({ row }) => {
        const deviceName = row.getValue("bfg_hostname") as string;
        const url = `/device/device/${deviceName}`;

        return (
          <Link to={url} className="flex items-center gap-1 capitalize">
            <LinkIcon className="h-2 w-2" />
            {deviceName}
          </Link>
        );
      }
    },

    {
      accessorKey: "site_name",
      header: ({ column }) => {
        return (
          <Button
            variant="ghost"
            onClick={() => setSorting([{ id: "site_name", desc: column.getIsSorted() === "asc" }])}
          >
            Site name
            <ArrowUpDown />
          </Button>
        );
      },
      cell: ({ row }) => <div className="capitalize">{row.getValue("site_name")}</div>
    },
    {
      accessorKey: "country",
      header: ({ column }) => {
        return (
          <Button variant="ghost" onClick={() => setSorting([{ id: "country", desc: column.getIsSorted() === "asc" }])}>
            Country
            <ArrowUpDown />
          </Button>
        );
      },
      cell: ({ row }) => <div className="capitalize">{row.getValue("country")}</div>
    },
    {
      accessorKey: "severity",
      header: ({ column }) => {
        return (
          <Button
            variant="ghost"
            onClick={() => setSorting([{ id: "severity", desc: column.getIsSorted() === "asc" }])}
          >
            Severity
            <ArrowUpDown className="ml-2 h-4 w-4" />
          </Button>
        );
      },
      cell: ({ row }) => {
        const severity = row.getValue("severity") as keyof typeof SEVERITY;
        return (
          <span className={`rounded-full px-2 py-1 text-xs font-medium ${SEVERITY_COLORS[severity]} `}>
            {SEVERITY[severity]}
          </span>
        );
      }
    },

    {
      accessorKey: "number_of_alerts",
      header: ({ column }) => {
        return (
          <Button
            variant="ghost"
            onClick={() => setSorting([{ id: "number_of_alerts", desc: column.getIsSorted() === "asc" }])}
          >
            Numbers of Alerts
            <ArrowUpDown />
          </Button>
        );
      },
      cell: ({ row }) => <div className="lowercase">{row.getValue("number_of_alerts")}</div>
    },
    // {
    //   accessorKey: "assigned_to",
    //   header: ({ column }) => {
    //     return (
    //       <Button
    //         variant="ghost"
    //         onClick={() => setSorting([{ id: "assigned_to", desc: column.getIsSorted() === "asc" }])}
    //       >
    //         Assigned to
    //         <ArrowUpDown />
    //       </Button>
    //     );
    // //   },
    //   cell: ({ row }) => {
    //     return (
    //       <div className="max-w-[150px] truncate font-medium">
    //         <Tooltip>
    //           <TooltipTrigger asChild>
    //             <div className="max-w-[150px] truncate font-medium">{row.getValue("assigned_to")}</div>
    //           </TooltipTrigger>
    //           <TooltipContent>{row.getValue("assigned_to")}</TooltipContent>
    //         </Tooltip>
    //       </div>
    //     );
    //   }
    // },

    {
      id: "actions",
      enableHiding: false,
      cell: () => {
        return (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="h-8 w-8 p-0">
                <span className="sr-only">Open menu</span>
                <MoreHorizontal />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem asChild>
                <Link to="/changes" className="block w-full">
                  View changes
                </Link>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        );
      }
    }
  ];
};
