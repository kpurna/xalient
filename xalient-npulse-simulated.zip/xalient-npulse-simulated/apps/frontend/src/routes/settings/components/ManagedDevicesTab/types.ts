import type { SettingRow } from "../../types";

export type ManagedDevicesTabProps = {
  rows: SettingRow[];
  isMutationPending: boolean;
  onSaveRow: (row: SettingRow) => Promise<void>;
  onEditingChange: (isEditing: boolean) => void;
  onShowLogsSummary: (row: SettingRow) => void;
};
