import { StatusCodes } from "http-status-codes";
import type { AppRouteHandler } from "../../lib/types.ts";

import { and, eq, gte, lte, sql } from "drizzle-orm";
import db from "../../db/index.js";
import { otelLogs } from "../../db/schema/otelLogs.js";
import type { GetLogs } from "./logs.routes.js";

export const getLogs: AppRouteHandler<GetLogs> = async (c) => {
  const { device, startTime, endTime, tag, limit } = c.req.valid("query");

  const conditions = [
    device ? eq(sql`${otelLogs.data}->>'device'`, device) : undefined,
    startTime ? gte(otelLogs.time, new Date(startTime)) : undefined,
    endTime ? lte(otelLogs.time, new Date(endTime)) : undefined,
    tag ? eq(otelLogs.tag, tag) : undefined
  ].filter(Boolean) as Parameters<typeof and>;

  const rows = await db
    .select()
    .from(otelLogs)
    .where(and(...conditions))
    .limit(limit ?? 100)
    .orderBy(otelLogs.time);

  const logs = rows.map((row) => ({
    time: row.time.toISOString(),
    tag: row.tag ?? null,
    message:
      typeof row.data === "object" && row.data !== null
        ? JSON.stringify(row.data)
        : String(row.data)
  }));

  return c.json({ data: { logs, total: logs.length } }, StatusCodes.OK);
};
