import { api } from "@/lib/api";
import { isMac } from "@/lib/utils";
import { useQuery } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { SearchIcon } from "lucide-react";
import { useEffect } from "react";
import { Button } from "./ui/button";
import { CommandDialog, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "./ui/command";
import { Kbd, KbdKey } from "./ui/shadcn-io/kbd";

interface GlobalSearchProps {
  openCommand: boolean;
  setOpenCommand: React.Dispatch<React.SetStateAction<boolean>>;
}

export const GlobalSearch = ({ openCommand, setOpenCommand }: GlobalSearchProps) => {
  const { data } = useQuery({
    queryKey: ["dashboard"],
    select: (data) => data?.data ?? [],
    queryFn: async () =>
      (
        await api.device.$get({
          query: {
            sortField: "bfg_hostname",
            sortDirection: "desc",
            searchBy: ""
          }
        })
      ).json()
  });

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "k" && (event.metaKey || event.ctrlKey)) {
        event.preventDefault();
        setOpenCommand((o) => !o);
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [setOpenCommand]);

  return (
    <>
      <Button
        onClick={() => setOpenCommand(true)}
        variant="ghost"
        className="flex w-full justify-between rounded-md border"
      >
        <span className="flex items-center gap-2">
          <SearchIcon />
          <span className="text-gray-500">Search device...</span>
        </span>
        <Kbd>
          <KbdKey>{isMac() ? "⌘" : "Ctrl"}</KbdKey>
          <KbdKey>K</KbdKey>
        </Kbd>
      </Button>
      <CommandDialog open={openCommand} onOpenChange={setOpenCommand}>
        <CommandInput placeholder="Type a command or search..." />
        <CommandList>
          <CommandGroup heading="Devices">
            <CommandEmpty>No results found.</CommandEmpty>

            {data?.map((device) => (
              <CommandItem
                data-testid={`device-${device.bfg_hostname ?? ""}`}
                key={device.bfg_hostname ?? ""}
                onSelect={() => {
                  const link = document.getElementById(`link-${device.bfg_hostname ?? ""}`);
                  link?.click();
                }}
                asChild
              >
                <Link
                  id={`link-${device.bfg_hostname ?? ""}`}
                  key={`link-${device.bfg_hostname ?? ""}`}
                  reloadDocument
                  onClick={() => setOpenCommand(false)}
                  to={`/device/device/$deviceId`}
                  params={{
                    deviceId: device.bfg_hostname ?? ""
                  }}
                >
                  View {device.bfg_hostname}
                </Link>
              </CommandItem>
            ))}
          </CommandGroup>
        </CommandList>
      </CommandDialog>
    </>
  );
};
