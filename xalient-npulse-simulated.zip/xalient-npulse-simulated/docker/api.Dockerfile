# Multi-stage build for API service in a pnpm monorepo

# 1) Base with pnpm and workspace for building TypeScript
FROM node:20-alpine AS build
WORKDIR /repo

# Enable pnpm via corepack
RUN corepack enable && corepack prepare pnpm@9.0.0 --activate

# Copy minimal files to resolve workspace deps
COPY pnpm-workspace.yaml ./
COPY pnpm-lock.yaml ./
COPY package.json ./
COPY turbo.json ./

# Copy workspace packages and the API app
COPY packages ./packages
COPY apps/api ./apps/api

# Install all workspace deps (dev included) to build
RUN pnpm install --frozen-lockfile

# Build API using a temporary tsconfig that emits JS
RUN printf '{\n  "extends": "./tsconfig.json",\n  "compilerOptions": {\n    "noEmit": false,\n    "allowImportingTsExtensions": false,\n    "outDir": "./dist"\n  }\n}\n' > apps/api/tsconfig.build.json \
  && pnpm -C apps/api exec tsc -p tsconfig.build.json

# 2) Migration image to run database migrations and seed data
FROM build AS migrate
WORKDIR /repo
RUN chmod +x apps/api/scripts/run-migrations.sh
ENTRYPOINT ["./apps/api/scripts/run-migrations.sh"]

# 3) Create a self-contained bundle for API with pnpm deploy
FROM node:20-alpine AS prod-bundle
WORKDIR /repo
RUN corepack enable && corepack prepare pnpm@9.0.0 --activate

# Copy workspace to compute prod deployment
COPY pnpm-workspace.yaml ./
COPY pnpm-lock.yaml ./
COPY package.json ./
COPY packages ./packages
COPY apps/api ./apps/api

# Generate a production deployment for the API into /out
RUN mkdir -p /out \
  && pnpm deploy /out --filter api --ignore-scripts

# Also copy the built dist from build stage
COPY --from=build /repo/apps/api/dist /out/dist

# 4) Runtime image
FROM node:20-alpine AS runner
ENV NODE_ENV=production
ENV DATABASE_URL=postgres://postgres:postgres@host.docker.internal:5432/postgres
ENV LOG_LEVEL=info
WORKDIR /app

RUN corepack enable && corepack prepare pnpm@9.0.0 --activate

# Copy the self-contained prod bundle
COPY --from=prod-bundle /out/ .

# Ensure we have the built dist and package.json
COPY --from=build /repo/apps/api/package.json ./package.json
COPY --from=build /repo/apps/api/drizzle.config.ts ./drizzle.config.ts
COPY --from=build /repo/apps/api/src ./src
COPY --from=build /repo/apps/api/src/db/migrations ./dist/src/db/migrations
RUN mkdir -p scripts
COPY --from=build /repo/apps/api/scripts/start.sh ./scripts/start.sh

RUN chmod +x ./scripts/start.sh

EXPOSE 3000
CMD ["./scripts/start.sh"]
