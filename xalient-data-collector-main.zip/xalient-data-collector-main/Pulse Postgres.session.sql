SELECT * FROM alarms

