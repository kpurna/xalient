import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { formatDate } from "@/lib/utils";
import DeviceTopologyMap from "../DeviceTopology";
import type { DeviceCardTypes, StatusBadgeProps } from "./types";

export default function DeviceCard({ device, interfaces, deviceId, TopologyComponent }: DeviceCardTypes) {
  const Topology = TopologyComponent ?? DeviceTopologyMap;

  const StatusBadge = ({ status }: StatusBadgeProps) => {
    const map: Record<string, string> = {
      Expired: "bg-red-100 text-red-800",
      Planned: "bg-yellow-100 text-yellow-800",
      Active: "bg-green-100 text-green-800",
      Deprecated: "bg-orange-100 text-orange-800"
    };

    const cls = map[status] ?? "bg-gray-100 text-gray-800";

    return (
      <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ${cls}`}>{status}</span>
    );
  };

  return (
    <Card>
      <CardHeader className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
        <div>
          <CardTitle className="flex items-center gap-3">
            <div className="flex flex-col">
              <span className="text-lg font-semibold">Device name: {device.bfg_hostname}</span>
              <span className="text-muted-foreground text-sm">
                {device.site_type} · {device.site_cus_type} · {device.site_cus_region}
              </span>
            </div>
          </CardTitle>
        </div>
        <div className="flex items-center gap-3">
          <div className="text-right">
            <div className="text-sm">Model</div>
            <div className="text-sm">{device.model}</div>
          </div>
          <div className="text-right">
            <div className="text-sm">Serial</div>
            <div className="text-sm">{device.serial_number}</div>
          </div>
          <div className="flex flex-col items-end gap-1">
            <div className="text-sm">Vendor</div>
            <Badge className="uppercase">{device.vendor}</Badge>
          </div>
        </div>
      </CardHeader>
      <div className="px-6 pb-6">
        <Topology interfaces={interfaces} deviceId={deviceId} />
      </div>
      <CardContent className="grid grid-cols-1 gap-4 md:grid-cols-3">
        <div className="space-y-3">
          <h3 className="text-sm font-semibold">Connectivity</h3>
          <div className="text-sm">
            <div>
              <span className="font-medium">Hostname:</span> {device.bfg_hostname}
            </div>
            <div>
              <span className="font-medium">IP:</span> {device.bfg_ip_address}
            </div>
            <div>
              <span className="font-medium">Network:</span> {device.bfg_ntn_type}
            </div>
          </div>

          <Separator className="my-2" />

          <h3 className="text-sm font-semibold">Identifiers</h3>
          <div className="text-sm">
            <div>
              <span className="font-medium">ID:</span> {device.id}
            </div>
            <div>
              <span className="font-medium">RFQ:</span> {device.rfq}
            </div>
            <div>
              <span className="font-medium">Risk ref:</span> {device.risk_reference}
            </div>
          </div>
        </div>

        <div className="space-y-3">
          <h3 className="text-sm font-semibold">Software</h3>
          <div className="text-sm">
            <div>
              <span className="font-medium">iOS Version:</span> {device.current_ios_version}
            </div>
            <div>
              <span className="font-medium">Recommended:</span> {device.recommended_ios ? "Yes" : "No"}
            </div>
            <div>
              <span className="font-medium">SW EOL:</span> {device.sw_eol_date} ({device.sw_eol_year})
            </div>
            <div>
              <span className="font-medium">SW status:</span> <StatusBadge status={device.sw_status as string} />
            </div>
          </div>

          <Separator className="my-2" />

          <h3 className="text-sm font-semibold">Hardware</h3>
          <div className="text-sm">
            <div>
              <span className="font-medium">Final EOL:</span> {device.final_hw_eol}
            </div>
            <div>
              <span className="font-medium">Final EOVSS:</span> {device.final_hw_eovss}
            </div>
            <div>
              <span className="font-medium">HW dependency:</span> {device.hw_customer_dependency ? "Yes" : "No"}
            </div>
            <div>
              <span className="font-medium">HW exceptions:</span> {device.hw_exceptions}
            </div>
          </div>
        </div>

        <div className="space-y-3">
          <h3 className="text-sm font-semibold">Metadata</h3>
          <div className="space-y-1 text-sm">
            <div>
              <span className="font-medium">Action:</span> {device.action}
            </div>
            <div>
              <span className="font-medium">Vendor Region:</span> {device.adr_country}
            </div>
            <div>
              <span className="font-medium">LSA / MSA:</span> {device.lsa} / {device.msa}
            </div>
            <div>
              <span className="font-medium">Tower:</span> {device.tower}
            </div>
            <div>
              <span className="font-medium">SSV:</span> {device.ssv_label}
            </div>
            <div>
              <span className="font-medium">Created:</span> {formatDate(device.created_at as unknown as number)}
            </div>
          </div>

          <Separator className="my-2" />

          <div className="mt-2 flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <div className="text-sm">Refresh status</div>
              <div className="text-sm">{device.refesh_status}</div>
            </div>

            <div className="flex items-center justify-between">
              <div className="text-sm">Riverbed</div>
              <div className="text-sm">{device.riverbed ? "Installed" : "None"}</div>
            </div>
          </div>
        </div>
      </CardContent>
      <CardFooter className="flex items-center justify-between">
        <div className="text-muted-foreground text-sm">
          Site: {device.site_name} · Region: {device.site_cus_region}
        </div>
        <div className="flex items-center gap-3">
          <div className="text-xs">
            SW EOL Year: <span className="ml-1 font-medium">{device.sw_eol_year}</span>
          </div>
          <div className="text-xs">
            HW EOL Year: <span className="ml-1 font-medium">{device.hw_eol_year}</span>
          </div>
        </div>
      </CardFooter>
    </Card>
  );
}
