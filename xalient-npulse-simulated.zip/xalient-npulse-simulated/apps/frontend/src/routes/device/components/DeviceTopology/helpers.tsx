export const severityToEdgeColor = (severity: string | null | undefined) => {
  switch ((severity ?? "").toUpperCase()) {
    case "CRITICAL":
    case "HIGH":
      return "#ef4444";
    case "MAJOR":
    case "MEDIUM":
      return "#f97316";
    case "MINOR":
    case "LOW":
      return "#facc15";
    default:
      return "#22c55e";
  }
};
