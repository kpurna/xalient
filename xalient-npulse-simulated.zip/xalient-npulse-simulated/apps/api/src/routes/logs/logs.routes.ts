import { createRoute, z } from "@hono/zod-openapi";
import { ReasonPhrases, StatusCodes } from "http-status-codes";

const logEntrySchema = z.object({
  time: z.string(),
  tag: z.string().nullable(),
  message: z.string().nullable()
});

export const getLogs = createRoute({
  path: "api/logs",
  method: "get",
  tags: ["Logs"],
  request: {
    query: z.object({
      device: z.string(),
      startTime: z.coerce.number().optional(),
      endTime: z.coerce.number().optional(),
      tag: z.string().optional(),
      limit: z.coerce.number().optional().default(100)
    })
  },
  responses: {
    [StatusCodes.OK.valueOf()]: {
      description: ReasonPhrases.OK,
      content: {
        "application/json": {
          schema: z.object({
            data: z.object({
              logs: z.array(logEntrySchema),
              total: z.number()
            })
          })
        }
      }
    }
  }
});

export type GetLogs = typeof getLogs;
