# Routing

Follow this structure when implementating routes:

```
  ├─ src/
  │ ├─ index.ts # runs app
  │ ├─ app.ts # App entry: mounts feature routers (authors, books, etc.), sentry, logger, open api documentation
  │ ├─ routes/ # Feature routers (mounted via app.route('/x', xRouter))
  | | ├─ authors
  │ | | ├─ authors.index.ts
  │ | | ├─ authors.handlers.ts
  │ | | ├─ authors.routes.ts
  │ | | ├─ authors.test.ts
  │ | ├─ books
  │ | | ├─ books.index.ts
  │ | | ├─ books.handlers.ts
  │ | | ├─ books.routes.ts
  │ | | ├─ books.test.ts
  │ ├─ middlewares/ # Cross-cutting middleware (auth, logging, CORS…)
```
