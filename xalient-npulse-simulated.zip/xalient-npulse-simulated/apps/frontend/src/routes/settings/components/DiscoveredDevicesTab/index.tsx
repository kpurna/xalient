import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useState } from "react";
import { StatusIcon } from "../StatusIcon";
import type { DiscoveredDevicesTabProps } from "./types";

export default function DiscoveredDevicesTab({
  devices,
  canAddHost,
  hasActiveEdit,
  isMutationPending,
  onAddHost,
  onShowLogsSummary,
  onPromote
}: DiscoveredDevicesTabProps) {
  const [selectedDevice, setSelectedDevice] = useState<(typeof devices)[number] | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isPromoting, setIsPromoting] = useState(false);

  const handleOpenDialog = (device: (typeof devices)[number]) => {
    setSelectedDevice(device);
    setIsDialogOpen(true);
  };

  const handleCloseDialog = () => {
    if (isPromoting) return;
    setIsDialogOpen(false);
    setSelectedDevice(null);
  };

  const handleConfirmPromotion = async () => {
    if (!selectedDevice) return;
    setIsPromoting(true);
    try {
      await onPromote(selectedDevice);
      setIsDialogOpen(false);
      setSelectedDevice(null);
    } catch {
      setIsPromoting(false);
    } finally {
      setIsPromoting(false);
    }
  };

  return (
    <>
      <div className="mb-4 flex items-center justify-between gap-4">
        <div className="flex flex-col">
          <h2 className="text-base font-semibold">Discovered devices</h2>
          <p className="text-muted-foreground text-sm">Hosts detected by discovery but not yet monitored.</p>
        </div>
        <Button size="sm" onClick={onAddHost} disabled={!canAddHost}>
          Add device
        </Button>
      </div>
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Hostname</TableHead>
              <TableHead className="text-center">Collector</TableHead>
              <TableHead className="text-center">Sensor</TableHead>
              <TableHead className="text-center">NetFlow</TableHead>
              <TableHead className="text-center">SNMP</TableHead>
              <TableHead className="text-center">Syslog</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {devices.length ? (
              devices.map((device) => (
                <TableRow key={device.id}>
                  <TableCell className="align-middle">
                    <span className="font-medium">{device.device_name ?? "-"}</span>
                  </TableCell>
                  <TableCell className="text-center align-middle">
                    <span></span>
                  </TableCell>
                  <TableCell className="text-center align-middle">
                    <span></span>
                  </TableCell>
                  <TableCell className="text-center align-middle">
                    <StatusIcon checked={Boolean(device.netflow)} />
                  </TableCell>
                  <TableCell className="text-center align-middle">
                    <StatusIcon checked={Boolean(device.snmp)} />
                  </TableCell>
                  <TableCell className="text-center align-middle">
                    <StatusIcon checked={Boolean(device.sys_logs)} />
                  </TableCell>
                  <TableCell className="text-right align-middle">
                    <div className="flex items-center justify-end gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => onShowLogsSummary(device)}
                        disabled={isMutationPending || hasActiveEdit || !device.device_name}
                      >
                        Logs
                      </Button>
                      <Button size="sm" variant="outline" disabled>
                        Metrics
                      </Button>
                      <Button
                        size="sm"
                        onClick={() => handleOpenDialog(device)}
                        disabled={isMutationPending || hasActiveEdit || isPromoting}
                      >
                        Promote to Managed devices
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={5} className="h-24 text-center">
                  No discovery devices available.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
      <Dialog
        open={isDialogOpen}
        onOpenChange={(open) => {
          if (!open) {
            handleCloseDialog();
          }
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Promote device to managed?</DialogTitle>
            <DialogDescription>
              {selectedDevice
                ? `This will begin monitoring for ${selectedDevice.device_name ?? "the selected device"}.`
                : "This will begin monitoring the selected device."}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={handleCloseDialog} disabled={isPromoting || isMutationPending}>
              Cancel
            </Button>
            <Button onClick={() => void handleConfirmPromotion()} disabled={isPromoting || isMutationPending}>
              {isPromoting || isMutationPending ? "Promoting..." : "Confirm"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
