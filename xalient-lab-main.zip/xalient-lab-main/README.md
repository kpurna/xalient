### Project Layout
```
lab/
├─ .env
├─ compose.yaml
├─ configs/
│  ├─ fluent-bit.conf
│  ├─ otel-config.conf
│  ├─ lldp-r1.conf
│  ├─ lldp-r2.conf
│  ├─ lldp-r3.conf
│  ├─ rsyslog-r1.conf
│  ├─ rsyslog-r2.conf
│  ├─ rsyslog-r3.conf
│  ├─ snmpd-r1.conf
│  ├─ snmpd-r2.conf
│  └─ snmpd-r3.conf
├─ images/
│  ├─ lldpd/
│  │  └─ Dockerfile
│  ├─ snmpd/
│  │  └─ Dockerfile
│  └─ rsyslog/
│     └─ Dockerfile
├─ logs/
│  ├─ r1/
│  ├─ r2/
│  └─ r3/
├─ scripts/
│  ├─ poll_lldp.sh
│  └─ wiring.sh
└─ state/
   ├─ flb-storage
   ├─ r1/
   ├─ r2/
   └─ r3/
```

**This project requires the [Pulse](https://github.com/unmod-zurich/pulse) Docker network and database to be running**
### Routers
This repository will create three virtual containerised routers:
- r1-frr
- r2-frr
- r3-frr

They are running FRR https://en.wikipedia.org/wiki/FRRouting
### Sidecars
Three sidecars for syslog:
- r1-syslog
- r2-syslog
- r3-syslog

Three sidecars for LLDP:
- r1-lldp
- r2-lldp
- r3-lldp

Three sidecars for SNMP:
- r1-snmp
- r2-snmp
- r3-snmp
### Collector
- otelcol
### Forwarder
- fluentbit
### Running
To build the custom images (only do this once):
```
docker compose --profile build up --no-start lldpd-image lldp-poller-image snmpd-image rsyslog-image 
```
To start the containers:
```
docker compose up -d
```
To stop the containers:
```
docker compose down
```
### Validating
To check Routers:
```
docker exec -it r1-frr ip -br addr
```
To check OSPF:
```
docker exec -it r1-frr vtysh -c 'show ip ospf neighbor'
```
To check BGP:
```
docker exec -it r1-frr vtysh -c 'show ip bgp summary'
```
To check LLDP:
```
docker exec -it r1-lldp lldpcli show chassis
docker exec -it r1-lldp lldpcli show interfaces
docker exec -it r1-lldp lldpcli show neighbors
```