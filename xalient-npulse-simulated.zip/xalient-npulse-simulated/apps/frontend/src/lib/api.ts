import { hc } from "hono/client";
import type { ApiRoutes } from "../../../api/src/app";

const client = hc<ApiRoutes>("/");

export const api = client.api;
