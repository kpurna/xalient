import { createRouter } from "../../lib/create-app.js";
import * as handlers from "./settings.js";
import * as routes from "./settings.routes.js";

const router = createRouter()
  .openapi(routes.deviceSettings, handlers.deviceSettings)
  .openapi(routes.upsertDeviceSetting, handlers.upsertDeviceSetting);

export default router;
