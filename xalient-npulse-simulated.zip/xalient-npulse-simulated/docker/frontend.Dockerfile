# Build stage: build React app with pnpm
FROM node:20-alpine AS build
WORKDIR /repo

RUN corepack enable && corepack prepare pnpm@9.0.0 --activate

# Build-time envs for Vite
ARG VITE_APP_NAME="Pulse"
ENV VITE_APP_NAME=${VITE_APP_NAME}

# Copy workspace manifests
COPY pnpm-workspace.yaml ./
COPY pnpm-lock.yaml ./
COPY package.json ./
COPY turbo.json ./

# Copy workspace packages and apps needed for type-checking/build
COPY packages ./packages
COPY apps/api ./apps/api
COPY apps/frontend ./apps/frontend

# Install deps and build
RUN pnpm install --frozen-lockfile
RUN pnpm -C apps/frontend build

# Runtime stage: nginx serving static files
FROM nginx:1.27-alpine AS runner

# Copy built assets to nginx html
COPY --from=build /repo/apps/frontend/dist /usr/share/nginx/html

# Add default nginx config (we will override with our own in compose)
COPY docker/nginx/frontend.conf /etc/nginx/conf.d/default.conf

EXPOSE 5173 80
CMD ["nginx", "-g", "daemon off;"]
