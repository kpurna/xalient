import { useAppStore } from "@/store";
import { useState } from "react";
import { Breadcrumbs } from "./breadcrumbs";
import { GlobalSearch } from "./global-search";
import { SidebarTrigger } from "./ui/sidebar";
export const Header = () => {
  const { breadcrumbs } = useAppStore();
  const [openCommand, setOpenCommand] = useState<boolean>(false);
  return (
    <div className="mx-10 my-5 flex items-center gap-5">
      <div className="flex">
        <SidebarTrigger className="p-3" />
      </div>
      <div className="flex">
        <Breadcrumbs breadcrumbs={breadcrumbs} />
      </div>
      <div className="flex grow">
        <GlobalSearch openCommand={openCommand} setOpenCommand={setOpenCommand} />
      </div>
    </div>
  );
};
