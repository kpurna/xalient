import type { api } from "@/lib/api";
import type { InferResponseType } from "hono/client";

type Response = InferResponseType<typeof api.alerts.$get>;

export type Data = Response["data"][number];

export interface GraphTypes {
  data: Data[];
  timerangePeriod: string;
  setTimerangePeriod: React.Dispatch<React.SetStateAction<string>>;
}
