import { drizzle } from "drizzle-orm/node-postgres";
import { sql } from "drizzle-orm/sql";
import env from "../env.js";

const db = drizzle(env.DATABASE_URL);

async function dropAllTables() {
  // if (env.NODE_ENV === "production") {
  //   console.log("Skipping table drop: running in production environment.");
  //   return;
  // }

  // Fetch all table names in the public schema
  const tables = await db.execute(sql`
    SELECT tablename
    FROM pg_tables
    WHERE schemaname = 'public';
  `);

  for (const table of tables.rows as { tablename: string }[]) {
    await db.execute(sql`DROP TABLE IF EXISTS ${sql.identifier(table.tablename)} CASCADE;`);
    console.log(`Dropped table: ${table.tablename}`);
  }

  console.log("All tables dropped successfully.");
}

dropAllTables().catch((err) => {
  console.error("Error dropping tables:", err);
});
