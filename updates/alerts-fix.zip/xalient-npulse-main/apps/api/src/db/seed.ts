import { faker } from "@faker-js/faker";
import type { InferInsertModel } from "drizzle-orm";
import { drizzle, NodePgDatabase } from "drizzle-orm/node-postgres";
import type { PgTable } from "drizzle-orm/pg-core";
import env from "../env.js";
import { alerts } from "./schema/alerts.js";
import { changes } from "./schema/changes.js";
import { interfaces } from "./schema/interfaces.js";
import { inventory } from "./schema/inventory.js";
import { settings } from "./schema/settings.js";
import { smarts_discovery_status_rgt } from "./schema/smarts_discovery_status_rgt.js";

function parseArgs() {
  const args = process.argv.slice(2);
  return args.reduce(
    (acc, arg) => {
      const [key, value] = arg.replace(/^--/, "").split("=");
      acc[key] = parseInt(value, 10) || 0;
      return acc;
    },
    {} as Record<string, number>
  );
}

function chunkArray<T>(arr: T[], size: number): T[][] {
  const chunks: T[][] = [];
  for (let i = 0; i < arr.length; i += size) {
    chunks.push(arr.slice(i, i + size));
  }
  return chunks;
}

async function insertInChunks<TTable extends PgTable>(
  db: NodePgDatabase,
  table: TTable,
  records: InferInsertModel<TTable>[],
  chunkSize = 50
): Promise<void> {
  for (const chunk of chunkArray(records, chunkSize)) {
    await db.insert(table).values(chunk);
  }
}

async function main() {
  const db = drizzle(env.DATABASE_URL);
  const args = parseArgs();

  for (const [tableName, count] of Object.entries(args)) {
    if ((count as number) > 0) {
      switch (tableName) {
        case "alerts": {
          const severities = ["CRITICAL", "MAJOR", "MINOR", "WARNING", "INDETERMINATE", "CLEARED"];
          const states = ["ACTIVE", "CLEARED", "ACKNOWLEDGED"];
          const alarmTypes = ["CommunicationsAlarm", "ProcessingErrorAlarm", "EquipmentAlarm", "QualityOfServiceAlarm", "EnvironmentalAlarm"];
          const sourceSystems = ["NetCool", "SMARTS", "SolarWinds", "Zabbix", "Nagios"];
          const elementClasses = ["Router", "Switch", "Firewall", "Server", "Link", "Interface"];
          const ackStates = ["UNACKNOWLEDGED", "ACKNOWLEDGED", "CLEARED"];

          const records = Array.from({ length: Number(count) }).map(() => {
            const raisedTime = faker.date.recent({ days: 30 });
            const clearedTime = faker.datatype.boolean()
              ? new Date(raisedTime.getTime() + faker.number.int({ min: 60000, max: 86400000 }))
              : null;
            const reportingTime = new Date(raisedTime.getTime() + faker.number.int({ min: 0, max: 5000 }));
            const changedTime = new Date(raisedTime.getTime() + faker.number.int({ min: 0, max: 3600000 }));

            const deviceIndex = faker.number.int({ min: 1, max: 32 });
            const deviceName = `device-${deviceIndex}`;
            const siteCode = faker.string.alphanumeric({ length: 4, casing: "upper" });
            const externalId = `ALM-${faker.string.alphanumeric({ length: 8, casing: "upper" })}`;

            return {
              id: faker.string.uuid(),
              alarmraisedtime: raisedTime,
              alarmclearedtime: clearedTime,
              alarmreportingtime: reportingTime,
              alarmchangedtime: changedTime,
              alarmedobjecttype: faker.helpers.arrayElement(elementClasses),
              perceivedseverity: faker.helpers.arrayElement(severities),
              probablecause: faker.helpers.arrayElement([
                "softwareError",
                "hardwareFailure",
                "connectionEstablishmentError",
                "communicationsSubsystemFailure",
                "configurationOrCustomizationError",
                "thresholdCrossed",
                "transmissionError"
              ]),
              btelementclass: faker.helpers.arrayElement(elementClasses),
              state: faker.helpers.arrayElement(states),
              externalalarmid: externalId,
              btcustomer: faker.helpers.arrayElement(["BT-Enterprise", "BT-Consumer", "BT-Wholesale", "BT-Global"]),
              btsourcesystem: faker.helpers.arrayElement(sourceSystems),
              btinstancename: deviceName,
              btcount: String(faker.number.int({ min: 1, max: 50 })),
              btuserdefined: faker.helpers.arrayElement(["true", "false", null]),
              btntnid: `NTN-${faker.string.alphanumeric({ length: 6, casing: "upper" })}`,
              btpewmso: faker.helpers.arrayElement(["PEW-NORTH", "PEW-SOUTH", "PEW-EAST", "PEW-WEST", null]),
              btaffectedcircuit: faker.helpers.arrayElement([
                `CKT-${faker.string.alphanumeric({ length: 8, casing: "upper" })}`,
                null
              ]),
              btservername: `srv-${faker.string.alphanumeric({ length: 6, casing: "lower" })}`,
              btsite: siteCode,
              sourcesystemid: `${faker.helpers.arrayElement(sourceSystems)}-${faker.string.alphanumeric({ length: 4, casing: "upper" })}`,
              ackuserid: faker.datatype.boolean() ? faker.internet.username() : null,
              acksystemid: faker.helpers.arrayElement(sourceSystems),
              ackstate: faker.helpers.arrayElement(ackStates),
              alarmtype: faker.helpers.arrayElement(alarmTypes),
              plannedoutageindicator: faker.helpers.arrayElement(["true", "false"]),
              category: faker.helpers.arrayElement(["Network", "Server", "Application", "Security", "Storage"]),
              incidentid: faker.datatype.boolean()
                ? `INC${faker.number.int({ min: 1000000, max: 9999999 })}`
                : null,
              specificproblem: faker.lorem.sentence(),
              alarmdetails: faker.lorem.sentences(2),
              isrootcause: faker.datatype.boolean(),
              correlatedalarm: faker.datatype.boolean()
                ? { alarmId: faker.string.uuid(), relation: "rootCause" }
                : null,
              alarmedobject: {
                objectType: faker.helpers.arrayElement(elementClasses),
                objectName: deviceName,
                ipAddress: faker.internet.ip()
              },
              affectedservice: faker.datatype.boolean()
                ? { serviceId: `SVC-${faker.string.alphanumeric({ length: 6, casing: "upper" })}`, serviceName: faker.commerce.productName() }
                : null,
              parentalarm: null
            };
          });

          await insertInChunks(db, alerts, records);
          console.log(`Seeded ${records.length} alerts (alarms table)`);
          break;
        }

        case "changes": {
          const records = Array.from({ length: Number(count) }).map(() => {
            const now = Date.now();
            const plannedStart = now - faker.number.int({ min: 0, max: 30 * 24 * 60 * 60 * 1000 });
            const plannedEnd =
              plannedStart + faker.number.int({ min: 1 * 60 * 60 * 1000, max: 7 * 24 * 60 * 60 * 1000 });

            return {
              change_number: `CHG${faker.number.int({ min: 100000, max: 999999 })}`,
              assignment_group: faker.helpers.arrayElement([
                "Network Team",
                "Server Ops",
                "Database Admins",
                "Security",
                "Service Desk"
              ]),
              category: faker.helpers.arrayElement(["Hardware", "Software", "Network", "Security", "Maintenance"]),
              short_description: faker.lorem.sentence(),
              assigned_to: faker.person.fullName(),
              planned_start_date: plannedStart,
              planned_end_date: plannedEnd,
              state: faker.helpers.arrayElement(["Scheduled", "In Progress", "Completed", "Cancelled"]),
              close_code: faker.helpers.arrayElement(["Successful", "Unsuccessful", "Cancelled", "No Impact"])
            };
          });

          await insertInChunks(db, changes, records);
          break;
        }

        case "interfaces": {
          const records = Array.from({ length: Number(count) }).map(() => {
            return {
              region: faker.location.state(),
              country: faker.location.country(),
              site_name: faker.company.name(),
              device_name: faker.helpers.arrayElement(Array.from({ length: 32 }, (_, i) => `device-${i + 1}`)),
              name: faker.lorem.word(),
              description: faker.lorem.words(10),
              speed: faker.helpers.arrayElement(["100Mbps", "1Gbps", "10Gbps"]),
              inbound_util: faker.number.int({ min: 0, max: 100 }) + "%",
              outbound_util: faker.number.int({ min: 0, max: 100 }) + "%",
              will_be_exception: faker.datatype.boolean(),
              overall_exception: faker.helpers.arrayElement(["None", "Minor", "Major", "Critical"]),
              status: faker.helpers.arrayElement(["IN-SERVICE", "CEASED"])
            };
          });

          await insertInChunks(db, interfaces, records);
          break;
        }

        case "settings": {
          const records = [
            { device_name: "R1", ip: "", snmp: false, netflow: false, sys_logs: false, is_monitored: false },
            { device_name: "R2", ip: "", snmp: false, netflow: false, sys_logs: false, is_monitored: false },
            { device_name: "R3", ip: "", snmp: false, netflow: false, sys_logs: false, is_monitored: false }
          ];

          await insertInChunks(db, settings, records);
          break;
        }

        case "inventory": {
          const hostnames = Array.from({ length: Number(count) }, (_, i) => `device-${i + 1}`);
          const records = hostnames.map((hostname) => {
            return {
              bfg_hostname: hostname,
              site_cus_type: faker.helpers.arrayElement(["Enterprise", "Edge"]),
              site_name: faker.company.name(),
              site_cus_region: faker.helpers.arrayElement(["NA", "EMEA", "APAC", "LATAM"]),
              adr_country: faker.location.country(),
              msa: faker.location.city(),
              lsa: faker.location.state(),
              bfg_ip_address: faker.internet.ip(),
              vendor: faker.helpers.arrayElement(["Cisco"]),
              model: faker.helpers.arrayElement(["ASR-9001", "MX480", "7050X3", "Nexus9K"]),
              serial_number: faker.string.alphanumeric(12).toUpperCase(),
              final_hw_eovss: faker.date.future().toISOString().split("T")[0],
              hw_eovss_year: faker.date.future().getFullYear().toString(),
              final_hw_eol: faker.date.future().toISOString().split("T")[0],
              hw_eol_year: faker.date.future().getFullYear().toString(),
              current_ios_version: faker.system.semver(),
              sw_eol_date: faker.date.future().toISOString().split("T")[0],
              sw_eol_year: faker.date.future().getFullYear().toString(),
              ssv_label: faker.helpers.arrayElement(["SSV-A", "SSV-B", "SSV-C"]),
              site_type: faker.helpers.arrayElement(["Hub", "Spoke", "HQ"]),
              tower: faker.helpers.arrayElement(["Tower1", "Tower2", "Tower3"]),
              bfg_ntn_type: faker.helpers.arrayElement(["MPLS", "Internet", "5G"]),
              sw_status: faker.helpers.arrayElement(["Active", "Expired", "Pending"]),
              hw_customer_dependency: faker.datatype.boolean(),
              sw_customer_dep_dependency: faker.datatype.boolean(),
              riverbed: faker.datatype.boolean(),
              hw_exceptions: faker.lorem.word(),
              major_minor_sw_version_upgrade: faker.datatype.boolean(),
              recommended_ios: faker.datatype.boolean(),
              refesh_status: faker.helpers.arrayElement(["Planned", "In Progress", "Completed"]),
              rfq: faker.string.alphanumeric(8).toUpperCase(),
              risk_reference: faker.string.alphanumeric(6).toUpperCase(),
              action: faker.helpers.arrayElement(["Monitor", "Upgrade", "Replace"])
            };
          });

          await insertInChunks(db, inventory, records);
          break;
        }

        case "smarts_discovery_status_rgt": {
          const records = Array.from({ length: Number(count) }).map(() => {
            return {
              man_hostname: faker.internet.domainName(),
              ip_address: faker.internet.ipv4(),
              previous_successful_discovery: faker.datatype.boolean(),
              current_discovery_error_message: faker.helpers.arrayElement([
                "Successfully Discovered",
                "No response from SNMP agent"
              ]),
              model: faker.helpers.arrayElement([
                "Cisco 2900",
                "Juniper MX960",
                "HP ProCurve",
                "Dell S-Series",
                "Arista 7500R"
              ]),
              type: faker.helpers.arrayElement(["Router", "Switch", "Firewall", "Server", "Load Balancer"]),
              certification: faker.helpers.arrayElement(["ISO 27001", "CCIE", "CompTIA Security+", "CEH", "None"]),
              apm_name: faker.commerce.productName(),
              first_discovered: faker.date.past().toISOString(),
              last_discovered: faker.date.recent().toISOString(),
              access_mode: faker.helpers.arrayElement(["SSH", "Telnet", "SNMP", "HTTPS"])
            };
          });

          await insertInChunks(db, smarts_discovery_status_rgt, records);
          break;
        }

        default:
          console.warn(`No seeder defined for table: ${tableName}`);
      }
    }
  }
}

main();
