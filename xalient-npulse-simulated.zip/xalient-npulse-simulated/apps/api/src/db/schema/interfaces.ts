import { boolean, pgTable, serial, timestamp, varchar } from "drizzle-orm/pg-core";
import { createSelectSchema } from "drizzle-zod";

export const interfaces = pgTable("interfaces", {
  id: serial().primaryKey().unique(),
  region: varchar({ length: 255 }),
  country: varchar({ length: 255 }),
  site_name: varchar({ length: 255 }),
  device_name: varchar({ length: 255 }),
  name: varchar({ length: 255 }),
  description: varchar({ length: 255 }),
  speed: varchar({ length: 255 }),
  inbound_util: varchar({ length: 255 }),
  outbound_util: varchar({ length: 255 }),
  will_be_exception: boolean(),
  overall_exception: varchar({ length: 255 }),
  status: varchar({ length: 255 }),
  updated_at: timestamp(),
  created_at: timestamp().defaultNow().notNull(),
  deleted_at: timestamp()
});
export const interfaceSelectSchema = createSelectSchema(interfaces);
