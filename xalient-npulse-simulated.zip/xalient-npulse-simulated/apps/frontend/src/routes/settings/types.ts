import type { api } from "@/lib/api";
import type { InferResponseType } from "hono/client";

export type SettingsResponse = InferResponseType<typeof api.settings.$get>;
export type SettingRow = SettingsResponse["data"][number] & {
  tempId?: number;
  isNew?: boolean;
};

export type UpsertSettingsResponse = InferResponseType<typeof api.settings.$post>;
export type SaveSettingPayload = {
  id: number;
  device_name: string;
  ip: string;
  netflow: boolean;
  snmp: boolean;
  sys_logs: boolean;
  is_monitored: boolean;
};
