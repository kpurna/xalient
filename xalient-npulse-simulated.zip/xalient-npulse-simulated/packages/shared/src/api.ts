/** Creating API types */
export interface ApiDashboardResponse {
  items: { id: string; name: string }[];
}
