import { Toast } from "@/components/toast";
import { fireEvent, render, screen } from "@testing-library/react";
describe("Toast", () => {
  it("renders default toast with title and description", () => {
    render(<Toast id="test-toast" title="Test Toast" description="This is a test toast description." type="default" />);
    const titleElement = document.querySelector("[data-testid='toast-title']");
    const descriptionElement = document.querySelector("[data-testid='toast-description']");
    expect(titleElement).toHaveTextContent("Test Toast");
    expect(descriptionElement).toHaveTextContent("This is a test toast description.");
  });
  // Loop through toast types
  it.each([
    {
      type: "success" as const,
      testId: "toast-icon-success",
      title: "Success Toast",
      description: "This is a success toast."
    },
    {
      type: "error" as const,
      testId: "toast-icon-error",
      title: "Error Toast",
      description: "This is an error toast."
    },
    {
      type: "warning" as const,
      testId: "toast-icon-warning",
      title: "Warning Toast",
      description: "This is a warning toast."
    }
  ])("renders $title with correct icon", ({ type, testId, title, description }) => {
    render(<Toast id={`${type}-toast`} title={title} description={description} type={type} />);
    const iconElement = document.querySelector(`[data-testid='${testId}']`);
    expect(iconElement).toBeInTheDocument();
    expect(screen.getByTestId(`toast-title`)).toHaveTextContent(title);
    expect(screen.getByTestId(`toast-description`)).toHaveTextContent(description);
  });
  it("renders toast with action button", () => {
    const mockOnClick = vi.fn();
    render(
      <Toast
        id="action-toast"
        title="Action Required"
        description="Please take action."
        button={{ label: "Take Action", onClick: mockOnClick }}
      />
    );
    const buttonElement = document.querySelector("[data-testid='toast-button']");
    if (buttonElement === null) {
      throw new Error("Button element not found");
    }
    fireEvent.click(buttonElement);
    expect(mockOnClick).toHaveBeenCalled();
    expect(buttonElement).toBeInTheDocument();
    expect(buttonElement).toHaveTextContent("Take Action");
  });
});
