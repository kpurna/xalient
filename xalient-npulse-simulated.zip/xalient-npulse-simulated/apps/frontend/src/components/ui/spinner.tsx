import { Loader2Icon } from "lucide-react";

import { cn } from "@/lib/utils";

function Spinner({ className, ...props }: React.ComponentProps<"svg">) {
  return (
    <div className="flex w-full items-center justify-center gap-3 py-16">
      <Loader2Icon role="status" aria-label="Loading" className={cn("size-4 animate-spin", className)} {...props} />
      <p className="text-sm text-neutral-500 dark:text-neutral-400">Loading...</p>
    </div>
  );
}

export { Spinner };
