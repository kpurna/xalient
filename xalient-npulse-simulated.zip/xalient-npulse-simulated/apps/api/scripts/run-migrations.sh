#!/bin/sh
set -euo pipefail

echo "Running database migrations and seed..."
cd /repo/apps/api

pnpm db:drop-tables 
pnpm db:generate
pnpm db:push
pnpm db:seed --alerts=200 --changes=100 --interfaces=200 --inventory=30 --smarts_discovery_status_rgt=10 --settings=3

echo "Database initialized."
