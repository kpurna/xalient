import { drizzle } from "drizzle-orm/node-postgres";
import { migrate } from "drizzle-orm/node-postgres/migrator";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { Pool } from "pg";
import env from "../env.js";

async function runMigrations(): Promise<void> {
  const pool = new Pool({
    connectionString: env.DATABASE_URL,
    // ssl: env.SSL
    //   ? {
    //       rejectUnauthorized: false
    //     }
    //   : false
    ssl: false
  });

  try {
    const db = drizzle(pool);
    const migrationsFolder = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "./migrations");

    await migrate(db, { migrationsFolder });
  } finally {
    await pool.end();
  }
}

runMigrations().catch((error) => {
  console.error("Database migration failed.", error);
  process.exit(1);
});
