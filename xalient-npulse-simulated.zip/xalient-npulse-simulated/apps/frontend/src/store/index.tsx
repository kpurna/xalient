import { create } from "zustand";

export interface TBreadcrumb {
  title: string;
  href?: string;
}
interface AppStoreState {
  breadcrumbs: TBreadcrumb[];
  addBreadcrumbs: (breadcrumbs: TBreadcrumb[]) => void;
  setBreadcrumbs: (breadcrumbs: TBreadcrumb[]) => void;
}

export const useAppStore = create<AppStoreState>((set) => ({
  breadcrumbs: [
    {
      title: "Home",
      href: "/"
    }
  ],
  addBreadcrumbs: (breadcrumbs: TBreadcrumb[]) =>
    set((state) => ({
      breadcrumbs: [...state.breadcrumbs, ...breadcrumbs]
    })),
  setBreadcrumbs: (breadcrumbs: TBreadcrumb[]) => set(() => ({ breadcrumbs }))
}));
