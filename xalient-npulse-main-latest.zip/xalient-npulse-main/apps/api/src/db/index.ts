import * as dotenv from "dotenv";
import { drizzle } from "drizzle-orm/node-postgres";
dotenv.config();

const db = drizzle({
  connection: {
    connectionString: process.env.DATABASE_URL
    // ssl: Boolean(process.env.SSL)
  }
});

export default db;
