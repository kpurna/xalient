import { Handle, Position, type NodeProps } from "@xyflow/react";
import { memo } from "react";
import type { InterfaceNodeData } from "../../types";

export const InterfaceNode = memo(({ data, selected }: NodeProps) => {
  const { label, status, severityColor } = data as InterfaceNodeData;
  const isCeased = (status ?? "").toUpperCase().includes("CEASE");
  const borderColor = isCeased ? "#94a3b8" : severityColor;
  return (
    <div className="pointer-events-none flex flex-col items-center gap-2 text-neutral-900">
      <div
        className={`pointer-events-auto relative flex h-24 w-24 cursor-pointer items-center justify-center rounded-full border-4 bg-white text-xs font-semibold shadow ${
          selected ? "ring-2 ring-sky-400" : ""
        }`}
        style={{ borderColor, color: "#0f172a" }}
      >
        <Handle
          type="target"
          id="left"
          position={Position.Left}
          style={{
            width: 12,
            height: 12,
            borderRadius: "999px",
            border: `2px solid ${borderColor}`,
            background: isCeased ? "#e2e8f0" : "#fff",
            left: -8,
            pointerEvents: "none"
          }}
        />
        <Handle
          type="target"
          id="right"
          position={Position.Right}
          style={{
            width: 12,
            height: 12,
            borderRadius: "999px",
            border: `2px solid ${borderColor}`,
            background: isCeased ? "#e2e8f0" : "#fff",
            right: -8,
            pointerEvents: "none"
          }}
        />
        <span className={`px-2 text-center text-[11px] leading-tight ${isCeased ? "text-neutral-500" : ""}`}>
          {label}
        </span>
      </div>
    </div>
  );
});
