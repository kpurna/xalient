import { Handle, Position, type NodeProps } from "@xyflow/react";
import { memo } from "react";
import type { DeviceNodeData } from "../../types";

export const DeviceNode = memo(({ data }: NodeProps) => {
  const { hasLeft, hasRight, label } = data as DeviceNodeData;
  return (
    <div className="pointer-events-none flex flex-col items-center gap-2 text-neutral-900">
      <div className="relative flex h-28 w-28 items-center justify-center rounded-full border-4 border-sky-400 bg-white shadow-xl">
        {hasLeft ? (
          <Handle
            type="source"
            id="left"
            position={Position.Left}
            style={{
              width: 14,
              height: 14,
              borderRadius: "999px",
              background: "#0ea5e9",
              border: "2px solid #fff",
              left: -8,
              pointerEvents: "none"
            }}
          />
        ) : null}
        {hasRight ? (
          <Handle
            type="source"
            id="right"
            position={Position.Right}
            style={{
              width: 14,
              height: 14,
              borderRadius: "999px",
              background: "#0ea5e9",
              border: "2px solid #fff",
              right: -8,
              pointerEvents: "none"
            }}
          />
        ) : null}
        <span className="px-4 text-center text-sm leading-tight font-semibold">{label}</span>
      </div>
    </div>
  );
});
