import { OpenAPIHono } from "@hono/zod-openapi";
import type { Schema } from "hono";
import type { AppBindings, AppOpenAPI } from "./types.js";

export function createRouter() {
  return new OpenAPIHono<AppBindings>();
}

export default function createApp() {
  return createRouter();
}

export function createTestApp<S extends Schema>(router: AppOpenAPI<S>) {
  return createApp().route("api/", router);
}
