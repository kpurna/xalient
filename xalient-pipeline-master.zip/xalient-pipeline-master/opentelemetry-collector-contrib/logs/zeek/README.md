# Zeek to OpenTelemetry Pipeline

This document outlines a data pipeline designed to collect, process, and forward Zeek logs to a storage backend using the OpenTelemetry Collector.  

## Diagram

```mermaid
graph LR
    %% --- Style Definitions ---
    classDef log fill:#a7d5f9,stroke:#0d5db8,stroke-width:2px;
    %% --- Sources  ---
    DT("Devices / Tools<br>(Various Types / Vendors)")
    Zeek("Packets<br>Zeek")

    %% --- OpenTelemetry Collector  ---
    subgraph OTel["OpenTelemetry Collector"]
        direction TB
        
        subgraph Receivers
            direction TB
            R_CM_conns("Connections Log<br>Receiver (FileLog)"):::log
            R_CM_ssl("SSL Log<br>Receiver (FileLog)"):::log
            R_CM_x509("X509 Log<br>Receiver (FileLog)"):::log
        end
        
        subgraph Processors
            direction TB
            P_CM_conns("Transform<br>OTTL Processor"):::log
            P_CM_ssl("Transform<br>OTTL Processor"):::log
            P_CM_x509("Transform<br>OTTL Processor"):::log
            P_Batch_CM(Batch<br>OTTL Processor):::log
        end
        
        subgraph Exporters
            direction TB
            E_logs_CM("OTLP Exporter<br>(ElasticSearch)"):::log
        end

        subgraph Extensions
            direction TB
            Ext_BA("basicauth<br>Authentication")
        end
    end

    %% --- Storage  ---
    S_logs("Storage<br>(Logs)"):::log
    
    %% --- Connections ---
    DT --> Zeek
    
    Zeek -- "Log Pipeline" --> R_CM_conns
    Zeek -- "Log Pipeline" --> R_CM_ssl
    Zeek -- "Log Pipeline" --> R_CM_x509

    R_CM_conns --> P_CM_conns
    R_CM_ssl --> P_CM_ssl
    R_CM_x509 --> P_CM_x509

    P_CM_conns --> P_Batch_CM
    P_CM_ssl --> P_Batch_CM
    P_CM_x509 --> P_Batch_CM

    P_Batch_CM --> E_logs_CM

    E_logs_CM --> S_logs
```

## Pipeline Architecture

The pipeline is configured to process logs from Zeek. It standardizes this data into the OpenTelemetry (OTel) format, enriching it with semantic conventions before exporting it for long-term storage.  

The OpenTelemetry Collector is configured with the following components:

### Receivers (filelog):

- The Collector uses multiple filelog receivers, one for each specific Zeek log file (conn.log, ssl.log, x509.log, etc.).

- Each receiver is configured to tail its target log file, parsing new log entries as they are written by Zeek.

- Initially, all fields are parsed as string values.

### Processors:

- Transform Processor (transform): This processor is used to perform data type conversions. It applies OpenTelemetry Transformation Language (OTTL) statements to cast the string values from the filelog receiver into their correct data types (e.g., integer, double, boolean, array) as defined in the schema tables below.

- Batch Processor (batch): This processor groups multiple log records into batches before sending them to the exporter. This is a performance best practice that improves throughput and reduces the number of outbound connections.

### Exporters (otlp/elasticsearch):

- The processed and batched logs are sent via the OpenTelemetry Protocol (OTLP) to an Elasticsearch instance for storage, indexing, and analysis.

### Extensions (basicauth):

- This extension provides server authentication credentials for the exporter. It is configured to handle the username and password required for the Collector to successfully connect and write data to the Elasticsearch cluster.

## Schema Mapping


The following tables document the mapping from the native Zeek log fields to the OpenTelemetry semantic conventions. For fields that are specific to Zeek and do not have a standard OTel equivalent, a custom namespace (zeek.*) is used to ensure clarity and prevent naming conflicts.  
Convertors Reference: Type casting is handled by the OTTL convert functions. For more details, see the official documentation:  
https://github.com/open-telemetry/opentelemetry-collector-contrib/blob/main/pkg/ottl/ottlfuncs/README.md#converters  

### conn.log

https://docs.zeek.org/en/master/logs/conn.html

|Zeek fields    |Zeek types  |OTel fields                  |OTel types
|---            |---         |---                          |---
|ts             |time        |(LogRecord Timestamp)        |Timestamp
|uid            |string      |zeek.conn.uid                |string
|id.orig_h      |addr        |source.address               |string
|id.orig_p	    |port        |source.port                  |int
|id.resp_h	    |addr        |destination.address          |string
|id.resp_p	    |port        |destination.port             |int
|proto	        |enum        |network.protocol.name        |string
|service        |string      |network.application.protocol |string
|duration	    |interval    |network.connection.duration  |double
|orig_bytes	    |count       |source.bytes                 |int
|resp_bytes	    |count       |destination.bytes            |int
|conn_state	    |string      |zeek.conn.state              |string
|local_orig     |bool        |zeek.source.is_local         |boolean
|local_resp	    |bool        |zeek.destination.is_local    |boolean
|missed_bytes   |count       |zeek.conn.missed_bytes       |int
|history        |string      |zeek.conn.history            |string
|orig_pkts	    |count       |source.packets               |int
|orig_ip_bytes  |count       |zeek.source.ip_bytes         |int
|resp_pkts	    |count       |destination.packets          |int
|resp_ip_bytes  |count       |zeek.destination.ip_bytes    |int
|tunnel_parents |set[string] |zeek.conn.tunnel_parents     |string[]
|ip_proto       |count       |network.protocol.number      |int

### ssl.log

https://docs.zeek.org/en/master/logs/ssl.html

|Zeek fields           |Zeek types     |OTel fields                            |OTel types
|---                   |---            |---                                    |---
|ts                    |time           |(LogRecord Timestamp)                  |Timestamp
|uid                   |string         |zeek.conn.uid                          |string
|id.orig_h             |addr           |source.address                         |string
|id.orig_p             |port           |source.port                            |int
|id.resp_h             |addr           |destination.address                    |string
|id.resp_p             |port           |destination.port                       |int
|version               |string         |tls.protocol.version                   |string
|cipher                |string         |tls.cipher                             |string
|curve                 |string         |tls.key_exchange.curve                 |string
|server_name           |string         |tls.server.name                        |string
|resumed               |bool           |tls.session.resumed                    |boolean
|last_alert            |string         |zeek.tls.last_alert                    |string
|next_protocol         |string         |tls.next_protocol                      |string
|established           |bool           |zeek.tls.established                   |boolean
|ssl_history           |string         |zeek.tls.history                       |string
|cert_chain_fps        |vector[string] |zeek.tls.server.certificate_chain.sha1 |string[]
|client_cert_chain_fps |vector[string] |zeek.tls.client.certificate_chain.sha1 |string[]
|sni_matches_cert	   |bool		   |zeek.tls.sni_matches_cert              |boolean
  
---
  
### x509.log

https://docs.zeek.org/en/master/logs/x509.html  
https://docs.zeek.org/en/master/scripts/base/files/x509/main.zeek.html#type-X509::Info  

|Zeek field                   |Zeek type      |OTel field                                                                                             |OTel type (format)    |Notes
|---                          |---            |---                                                                                                    |---                   |---
|ts                           |time           |(LogRecord Timestamp)                                                                                  |uint64 ns since epoch |
|fingerprint                  |string         |tls.server.hash.sha256 **or**<br>tls.client.hash.sha256 **or**<br>zeek.x509.fingerprint                |string (uppercase)    |**(1)**
|certificate.version          |count          |zeek.x509.version                                                                                      |int                   |
|certificate.serial           |string         |zeek.x509.serial_number                                                                                |string                |
|certificate.subject          |string         |tls.server.subject **or**<br>tls.client.subject **or**<br>zeek.x509.certificate.subject                |string                |**(1)**
|certificate.issuer           |string         |tls.server.issuer **or**<br>tls.client.issuer **or**<br>zeek.x509.certificate.issuer                   |string                |**(1)**
|certificate.not_valid_before |time           |tls.server.not_before **or**<br>tls.client.not_before **or**<br>zeek.x509.certificate.not_valid_before |string (ISO-8601 sec) |**(1)**
|certificate.not_valid_after  |time           |tls.server.not_after **or**<br>tls.client.not_after **or**<br>zeek.x509.certificate.not_valid_after    |string (ISO-8601 sec) |**(1)**
|certificate.key_alg          |string         |zeek.x509.public_key.algorithm                                                                         |string                |
|certificate.sig_alg          |string         |zeek.x509.signature.algorithm                                                                          |string                |
|certificate.key_type         |string         |zeek.x509.public_key.type                                                                              |string                |
|certificate.key_length       |count          |zeek.x509.public_key.size                                                                              |int                   |
|certificate.exponent         |string         |zeek.x509.public_key.exponent                                                                          |string                |
|certificate.curve            |string         |zeek.x509.public_key.curve                                                                             |string                |
|san.dns                      |vector[string] |zeek.x509.san.dns                                                                                      |string[]              |
|san.uri                      |vector[string] |zeek.x509.san.uri                                                                                      |string[]              |
|san.email                    |vector[string] |zeek.x509.san.email                                                                                    |string[]              |
|san.ip                       |vector[addr]   |zeek.x509.san.ip                                                                                       |string[]              |
|basic_constraints.ca         |bool           |zeek.x509.basic_constraints.is_ca                                                                      |boolean               |
|basic_constraints.path_len   |count          |zeek.x509.basic_constraints.path_length                                                                |int                   |
|host_cert                    |bool           |zeek.x509.is_host_cert                                                                                 |boolean               |**(2)**
|client_cert                  |bool           |zeek.x509.is_client_cert                                                                               |boolean               |**(2)**

**(1)** tls.server.* **or** tls.client.* **or** zeek.x509.* is chosen based on the boolean value of **(2)** (host_cert **or** client_cert).  
If host_cert == true → set tls.server.*  
If client_cert == true → set tls.client.*  
If both false set zeek.x509.*  
