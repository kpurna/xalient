import { bigint, boolean, jsonb, pgEnum, pgTable, serial, text, timestamp, varchar } from "drizzle-orm/pg-core";
import { createSelectSchema } from "drizzle-zod";

export const originEnum = pgEnum("origin", ["UNKNOWN", "SYSTEM", "USER"]);
export const severityEnum = pgEnum("severity", ["LOW", "MEDIUM", "HIGH", "EMERGENCY"]);

// ── Real alarm data written by the data-collector (xalient-data-collector-main)
// Maps to the "alarms" postgres table populated via the OTLP pipeline
export const alarms = pgTable("alarms", {
  id: varchar({ length: 255 }).primaryKey().unique(),

  alarmraisedtime: timestamp({ withTimezone: true }),
  alarmclearedtime: timestamp({ withTimezone: true }),
  alarmreportingtime: timestamp({ withTimezone: true }),
  alarmchangedtime: timestamp({ withTimezone: true }),

  alarmedobjecttype: varchar({ length: 255 }),
  perceivedseverity: varchar({ length: 255 }),
  probablecause: varchar({ length: 255 }),
  btelementclass: varchar({ length: 255 }),
  state: varchar({ length: 255 }),
  externalalarmid: varchar({ length: 255 }),

  btcustomer: varchar({ length: 255 }),
  btsourcesystem: varchar({ length: 255 }),
  btinstancename: varchar({ length: 255 }),
  btcount: varchar({ length: 255 }),
  btuserdefined: varchar({ length: 255 }),
  btntnid: varchar({ length: 255 }),
  btpewmso: varchar({ length: 255 }),
  btaffectedcircuit: varchar({ length: 255 }),
  btservername: varchar({ length: 255 }),
  btsite: varchar({ length: 255 }),

  sourcesystemid: varchar({ length: 255 }),
  ackuserid: varchar({ length: 255 }),
  acksystemid: varchar({ length: 255 }),
  ackstate: varchar({ length: 255 }),

  alarmtype: varchar({ length: 255 }),
  plannedoutageindicator: varchar({ length: 255 }),
  category: varchar({ length: 255 }),
  incidentid: varchar({ length: 255 }),

  specificproblem: text(),
  alarmdetails: text(),

  isrootcause: boolean(),

  correlatedalarm: jsonb(),
  alarmedobject: jsonb(),
  affectedservice: jsonb(),
  parentalarm: jsonb()
});

// ── Simulated alert data seeded on startup (matches the simulated repo shape)
// Maps to the "alerts" postgres table populated by seed.ts
export const alerts = pgTable("alerts", {
  id: serial().primaryKey().unique(),
  device_name: varchar({ length: 255 }),
  first: bigint({ mode: "number" }),
  last: bigint({ mode: "number" }),
  clear: bigint({ mode: "number" }),
  assigned_to: varchar({ length: 255 }),
  severity: severityEnum().default("LOW"),
  message: text(),
  comments: text(),
  occurrences: bigint({ mode: "number" }),
  updated_at: timestamp(),
  created_at: timestamp().defaultNow().notNull(),
  deleted_at: timestamp()
});

export const alarmSelectSchema = createSelectSchema(alarms);
export const alertSelectSchema = createSelectSchema(alerts);
