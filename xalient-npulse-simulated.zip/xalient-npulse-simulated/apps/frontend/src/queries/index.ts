import { QueryClient } from "@tanstack/react-query";

// Setting these as the defaults for visibility
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {}
  }
});

const query = async (method: "GET" | "POST" | "PUT" | "DELETE", endpoint: string) => {
  const BASE_API_URL = process.env.VITE_API_URL;

  const options: RequestInit = {
    method,
    headers: {
      "Content-Type": "application/json"
    }
  };

  console.log(`${BASE_API_URL}${endpoint}`);
  /** A fetch wrapper for making API requests */
  return fetch(`${BASE_API_URL}${endpoint}`, options);
};

export { query, queryClient };
