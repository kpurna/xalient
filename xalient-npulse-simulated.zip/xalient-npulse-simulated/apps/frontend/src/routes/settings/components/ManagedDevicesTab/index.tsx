import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import type { CheckedState } from "@radix-ui/react-checkbox";
import { Pencil, Save, XCircle } from "lucide-react";
import { useEffect, useState } from "react";
import { getRowKey } from "../../helpers";
import type { SettingRow } from "../../types";
import { StatusIcon } from "../StatusIcon";
import type { ManagedDevicesTabProps } from "./types";

export default function ManagedDevicesTab({
  rows,
  isMutationPending,
  onSaveRow,
  onEditingChange,
  onShowLogsSummary
}: ManagedDevicesTabProps) {
  const [editingKey, setEditingKey] = useState<number | null>(null);
  const [draft, setDraft] = useState<SettingRow | null>(null);

  useEffect(() => {
    onEditingChange(editingKey !== null);
  }, [editingKey, onEditingChange]);

  useEffect(
    () => () => {
      onEditingChange(false);
    },
    [onEditingChange]
  );

  useEffect(() => {
    if (editingKey === null) return;
    const matchingRow = rows.find((row) => getRowKey(row) === editingKey);
    if (!matchingRow) {
      setEditingKey(null);
      setDraft(null);
    }
  }, [rows, editingKey]);

  const hasActiveEdit = editingKey !== null;

  const handleBeginEdit = (row: SettingRow) => {
    const key = getRowKey(row);
    setEditingKey(key);
    setDraft({ ...row });
  };

  const handleCancelEdit = () => {
    setEditingKey(null);
    setDraft(null);
  };

  const handleBooleanChange =
    (field: "netflow" | "snmp" | "sys_logs") =>
    (value: CheckedState): void => {
      setDraft((prev) => (prev ? { ...prev, [field]: value === true } : prev));
    };

  const handleSaveEdit = async () => {
    if (!draft) return;

    await onSaveRow(draft);
    setEditingKey(null);
    setDraft(null);
  };

  return (
    <>
      <div className="mb-4 flex items-center justify-between gap-4">
        <div className="flex flex-col">
          <h2 className="text-base font-semibold">Managed devices</h2>
          <p className="text-muted-foreground text-sm">Manage data collection for actively monitored hosts.</p>
        </div>
      </div>
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Hostname</TableHead>
              <TableHead className="text-center">Collector</TableHead>
              <TableHead className="text-center">Sensor</TableHead>
              <TableHead className="text-center">NetFlow</TableHead>
              <TableHead className="text-center">SNMP</TableHead>
              <TableHead className="text-center">Syslog</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {rows.length ? (
              rows.map((row) => {
                const key = getRowKey(row);
                const isEditing = editingKey === key;
                const rowData = isEditing && draft ? draft : row;

                return (
                  <TableRow key={key} data-state={isEditing ? "editing" : undefined}>
                    <TableCell className="align-middle">
                      <span className="font-medium">{row.device_name ?? "-"}</span>
                    </TableCell>
                    <TableCell className="text-center align-middle">
                      <span></span>
                    </TableCell>
                    <TableCell className="text-center align-middle">
                      <span></span>
                    </TableCell>
                    <TableCell className="text-center align-middle">
                      {isEditing ? (
                        <Checkbox
                          checked={Boolean(rowData.netflow)}
                          onCheckedChange={handleBooleanChange("netflow")}
                          disabled={isMutationPending}
                        />
                      ) : (
                        <StatusIcon checked={Boolean(row.netflow)} />
                      )}
                    </TableCell>
                    <TableCell className="text-center align-middle">
                      {isEditing ? (
                        <Checkbox
                          checked={Boolean(rowData.snmp)}
                          onCheckedChange={handleBooleanChange("snmp")}
                          disabled={isMutationPending}
                        />
                      ) : (
                        <StatusIcon checked={Boolean(row.snmp)} />
                      )}
                    </TableCell>
                    <TableCell className="text-center align-middle">
                      {isEditing ? (
                        <Checkbox
                          checked={Boolean(rowData.sys_logs)}
                          onCheckedChange={handleBooleanChange("sys_logs")}
                          disabled={isMutationPending}
                        />
                      ) : (
                        <StatusIcon checked={Boolean(row.sys_logs)} />
                      )}
                    </TableCell>
                    <TableCell className="text-right align-middle">
                      {isEditing ? (
                        <div className="flex items-center justify-end gap-2">
                          <Button size="sm" onClick={() => void handleSaveEdit()} disabled={isMutationPending}>
                            <Save className="mr-1 h-4 w-4" />
                            {isMutationPending ? "Saving..." : "Save"}
                          </Button>
                          <Button size="sm" variant="outline" onClick={handleCancelEdit} disabled={isMutationPending}>
                            <XCircle className="mr-1 h-4 w-4" />
                            Cancel
                          </Button>
                        </div>
                      ) : (
                        <div className="flex items-center justify-end gap-2">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleBeginEdit(row)}
                            disabled={hasActiveEdit || isMutationPending}
                          >
                            <Pencil className="mr-1 h-4 w-4" />
                            Edit
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => onShowLogsSummary(row)}
                            disabled={isMutationPending || hasActiveEdit || !row.device_name}
                          >
                            Logs
                          </Button>
                          <Button size="sm" variant="outline" disabled>
                            Metrics
                          </Button>
                        </div>
                      )}
                    </TableCell>
                  </TableRow>
                );
              })
            ) : (
              <TableRow>
                <TableCell colSpan={6} className="h-24 text-center">
                  No settings found.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </>
  );
}
