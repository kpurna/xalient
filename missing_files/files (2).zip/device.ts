// @ts-nocheck

import { gte, lte } from "drizzle-orm";
import { StatusCodes } from "http-status-codes";
import type { AppRouteHandler } from "../../lib/types.js";

import { and, or, sql, type AnyColumn, type SQLWrapper } from "drizzle-orm";
import db from "../../db/index.js";
import { alarms } from "../../db/schema/alarms.js";
import { alerts } from "../../db/schema/alerts.js";
import { changes } from "../../db/schema/changes.js";
import { interfaces } from "../../db/schema/interfaces.js";
import { inventory } from "../../db/schema/inventory.js";
import { smarts_discovery_status_rgt } from "../../db/schema/smarts_discovery_status_rgt.js";
import { sortType } from "./device.helper.js";
import type {
  AlertRoute,
  DeviceAlert,
  DeviceChange,
  DeviceDetails,
  DeviceInterface,
  ListRoute,
  StatRoute
} from "./device.routes.js";

export const deviceData: AppRouteHandler<ListRoute> = async (c) => {
  const { sortDirection, sortField, searchBy } = c.req.valid("query");

  const sort = sortType(sortDirection);

  const columnMap: Record<string, AnyColumn | SQLWrapper> = {
    id: inventory.id,
    bfg_hostname: inventory.bfg_hostname,
    site_name: inventory.site_name,
    country: inventory.adr_country
  };

  const column = columnMap[sortField] ?? inventory.id;

  const conditions: (SQLWrapper | undefined)[] = [
    searchBy
      ? or(
          sql`${inventory.bfg_hostname}::text ILIKE ${`%${searchBy}%`}`,
          sql`${inventory.site_name}::text ILIKE ${`%${searchBy}%`}`,
          sql`${inventory.adr_country}::text ILIKE ${`%${searchBy}%`}`
        )
      : undefined
  ].filter(Boolean);

  const inventoryWithAlerts = await db
    .select({
      bfg_hostname: sql<string>`${inventory.bfg_hostname}`,
      site_name: sql<string>`${inventory.site_name}`,
      country: sql<string>`${inventory.adr_country}`,

      number_of_alerts: sql<number>`COUNT(${alarms.id})`,
      severity: sql<number>`
      COALESCE(
        MAX(
          CASE ${alarms.perceivedSeverity}
            WHEN 'Critical' THEN 4
            WHEN 'Major' THEN 3
            WHEN 'Minor' THEN 2
            WHEN 'Warning' THEN 1
            ELSE 0
          END
        ), 0
      )
    `
    })
    .from(inventory)
    .leftJoin(alarms, sql`true`)
    .groupBy(inventory.id, inventory.bfg_hostname, inventory.site_name, inventory.adr_country)
    .orderBy(sort(column));

  return c.json(
    {
      message: "success",
      data: inventoryWithAlerts
    },
    StatusCodes.OK
  );
};

export const stats: AppRouteHandler<StatRoute> = async (c) => {
  const inventoryData = await db.select().from(inventory);

  const successfullyDiscoveredDevices = await db
    .select({
      count: sql<number>`COUNT(DISTINCT ${smarts_discovery_status_rgt.man_hostname})`
    })
    .from(smarts_discovery_status_rgt)
    .where(sql`current_discovery_error_message = 'Successfully Discovered'`);

  const deviceNames = [...new Set(inventoryData.map((item) => item.bfg_hostname as string))];
  const siteNames = [...new Set(inventoryData.map((item) => item.site_name as string))];

  return c.json(
    {
      message: "success",
      totalDevices: deviceNames.length,
      deviceWithAlerts: deviceNames.length,
      totalSites: siteNames.length,
      totalSuccessfullyDiscoveredDevices: Number(successfullyDiscoveredDevices[0].count)
    },
    StatusCodes.OK
  );
};

export const allAlerts: AppRouteHandler<AlertRoute> = async (c) => {
  const { startTime, endTime } = c.req.valid("query");

  const startDate = new Date(Number(startTime));
  const endDate = new Date(Number(endTime));

  const data = await db
    .select()
    .from(alarms)
    .where(and(gte(alarms.alarmRaisedTime, startDate), lte(alarms.alarmRaisedTime, endDate)));

  return c.json({ message: "Success", data }, StatusCodes.OK);
};

export const deviceChanges: AppRouteHandler<DeviceChange> = async (c) => {
  const { sortDirection, sortField, searchBy } = c.req.valid("query");

  const sort = sortType(sortDirection);

  const columnMap: Record<string, AnyColumn | SQLWrapper> = {
    id: changes.id,
    change_number: changes.change_number,
    assignment_group: changes.assignment_group,
    category: changes.category,
    assigned_to: changes.assigned_to,
    planned_start_date: changes.planned_start_date,
    planned_end_date: changes.planned_end_date,
    state: changes.state,
    short_description: changes.short_description,
    close_code: changes.close_code
  };

  const column = columnMap[sortField] ?? changes.id;

  const conditions: (SQLWrapper | undefined)[] = [
    searchBy
      ? or(
          sql`${changes.change_number}::text ILIKE ${`%${searchBy}%`}`,
          sql`${changes.assigned_to}::text ILIKE ${`%${searchBy}%`}`,
          sql`${changes.assignment_group}::text ILIKE ${`%${searchBy}%`}`,
          sql`${changes.category}::text ILIKE ${`%${searchBy}%`}`,
          sql`${changes.close_code}::text ILIKE ${`%${searchBy}%`}`,
          sql`${changes.short_description}::text ILIKE ${`%${searchBy}%`}`,
          sql`${changes.state}::text ILIKE ${`%${searchBy}%`}`
        )
      : undefined
  ].filter(Boolean);

  const rows = await db
    .select()
    .from(changes)
    .where(and(...conditions))
    .orderBy(sort(column));

  return c.json(
    {
      message: "Success",
      data: rows
    },
    StatusCodes.OK
  );
};

export const deviceAlerts: AppRouteHandler<DeviceAlert> = async (c) => {
  const { sortDirection, sortField, searchBy } = c.req.valid("query");

  const sort = sortType(sortDirection);

  const columnMap: Record<string, AnyColumn | SQLWrapper> = {
    alarmRaisedTime: alarms.alarmRaisedTime,
    alarmClearedTime: alarms.alarmClearedTime,
    alarmReportingTime: alarms.alarmReportingTime,
    alarmChangedTime: alarms.alarmChangedTime,
    alarmedObjectType: alarms.alarmedObjectType,
    perceivedSeverity: alarms.perceivedSeverity,
    probableCause: alarms.probableCause,
    btElementClass: alarms.btElementClass,
    state: alarms.state,
    externalAlarmId: alarms.externalAlarmId,
    btCustomer: alarms.btCustomer,
    btSourceSystem: alarms.btSourceSystem,
    btInstanceName: alarms.btInstanceName,
    btCount: alarms.btCount,
    btUserDefined: alarms.btUserDefined,
    btNtnId: alarms.btNtnId,
    btPewMso: alarms.btPewMso,
    btAffectedCircuit: alarms.btAffectedCircuit,
    btServerName: alarms.btServerName,
    btSite: alarms.btSite,
    sourceSystemId: alarms.sourceSystemId,
    ackUserId: alarms.ackUserId,
    ackSystemId: alarms.ackSystemId,
    ackState: alarms.ackState,
    alarmType: alarms.alarmType,
    plannedOutageIndicator: alarms.plannedOutageIndicator,
    category: alarms.category,
    incidentId: alarms.incidentId,
    specificProblem: alarms.specificProblem,
    alarmDetails: alarms.alarmDetails,
    isRootCause: alarms.isRootCause,
    correlatedAlarm: alarms.correlatedAlarm,
    alarmedObject: alarms.alarmedObject,
    affectedService: alarms.affectedService,
    parentAlarm: alarms.parentAlarm
  };

  const column = columnMap[sortField] ?? alarms.externalAlarmId;

  const conditions: (SQLWrapper | undefined)[] = [
    searchBy
      ? or(
          sql`${alarms.alarmRaisedTime}::text ILIKE ${`%${searchBy}%`}`,
          sql`${alarms.alarmClearedTime}::text ILIKE ${`%${searchBy}%`}`,
          sql`${alarms.alarmReportingTime}::text ILIKE ${`%${searchBy}%`}`,
          sql`${alarms.alarmChangedTime}::text ILIKE ${`%${searchBy}%`}`,
          sql`${alarms.alarmedObjectType}::text ILIKE ${`%${searchBy}%`}`,
          sql`${alarms.perceivedSeverity}::text ILIKE ${`%${searchBy}%`}`,
          sql`${alarms.probableCause}::text ILIKE ${`%${searchBy}%`}`,
          sql`${alarms.btElementClass}::text ILIKE ${`%${searchBy}%`}`,
          sql`${alarms.state}::text ILIKE ${`%${searchBy}%`}`,
          sql`${alarms.externalAlarmId}::text ILIKE ${`%${searchBy}%`}`,
          sql`${alarms.btCustomer}::text ILIKE ${`%${searchBy}%`}`,
          sql`${alarms.btSourceSystem}::text ILIKE ${`%${searchBy}%`}`,
          sql`${alarms.btInstanceName}::text ILIKE ${`%${searchBy}%`}`,
          sql`${alarms.btCount}::text ILIKE ${`%${searchBy}%`}`,
          sql`${alarms.btUserDefined}::text ILIKE ${`%${searchBy}%`}`,
          sql`${alarms.btNtnId}::text ILIKE ${`%${searchBy}%`}`,
          sql`${alarms.btPewMso}::text ILIKE ${`%${searchBy}%`}`,
          sql`${alarms.btAffectedCircuit}::text ILIKE ${`%${searchBy}%`}`,
          sql`${alarms.btServerName}::text ILIKE ${`%${searchBy}%`}`,
          sql`${alarms.btSite}::text ILIKE ${`%${searchBy}%`}`,
          sql`${alarms.sourceSystemId}::text ILIKE ${`%${searchBy}%`}`,
          sql`${alarms.ackUserId}::text ILIKE ${`%${searchBy}%`}`,
          sql`${alarms.ackSystemId}::text ILIKE ${`%${searchBy}%`}`,
          sql`${alarms.ackState}::text ILIKE ${`%${searchBy}%`}`,
          sql`${alarms.alarmType}::text ILIKE ${`%${searchBy}%`}`,
          sql`${alarms.plannedOutageIndicator}::text ILIKE ${`%${searchBy}%`}`,
          sql`${alarms.category}::text ILIKE ${`%${searchBy}%`}`,
          sql`${alarms.incidentId}::text ILIKE ${`%${searchBy}%`}`,
          sql`${alarms.specificProblem}::text ILIKE ${`%${searchBy}%`}`,
          sql`${alarms.alarmDetails}::text ILIKE ${`%${searchBy}%`}`,
          sql`${alarms.isRootCause}::text ILIKE ${`%${searchBy}%`}`,
          sql`${alarms.correlatedAlarm}::text ILIKE ${`%${searchBy}%`}`,
          sql`${alarms.alarmedObject}::text ILIKE ${`%${searchBy}%`}`,
          sql`${alarms.affectedService}::text ILIKE ${`%${searchBy}%`}`,
          sql`${alarms.parentAlarm}::text ILIKE ${`%${searchBy}%`}`
        )
      : undefined
  ].filter(Boolean);

  const data = await db
    .select()
    .from(alarms)
    .where(and(...conditions))
    .orderBy(sort(column));

  return c.json(
    {
      message: "Success",
      data: data
    },
    StatusCodes.OK
  );
};

export const deviceInterfaces: AppRouteHandler<DeviceInterface> = async (c) => {
  const { deviceId } = c.req.valid("query");

  const data = await db
    .select()
    .from(interfaces)
    .where(sql`device_name = ${deviceId}`);

  return c.json(
    {
      message: "Success",
      data: data
    },
    StatusCodes.OK
  );
};

export const deviceDetails: AppRouteHandler<DeviceDetails> = async (c) => {
  const { deviceId } = c.req.valid("query");

  const data = await db
    .select()
    .from(inventory)
    .where(sql`bfg_hostname = ${deviceId}`);

  return c.json(
    {
      message: "Success",
      data: data
    },
    StatusCodes.OK
  );
};
