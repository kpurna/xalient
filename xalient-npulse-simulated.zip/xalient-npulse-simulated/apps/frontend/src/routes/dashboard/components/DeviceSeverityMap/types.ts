import type { DeviceData } from "@/components/table/types";
import type { DivIcon, LatLngTuple } from "leaflet";

export type SeverityLevel = "Critical" | "Major" | "Minor" | "Warning";

export type DeviceMarker = {
  id: string;
  position: LatLngTuple;
  label: string;
  severity: SeverityLevel;
  alertCount: number;
  devices: DeviceData[];
  severityCounts: Record<SeverityLevel, number>;
};

export type DeviceMarkerWithIcon = DeviceMarker & {
  icon: DivIcon;
  markerLabel: string;
};

export interface DeviceSeverityMapProps {
  devices?: DeviceData[];
  isLoading?: boolean;
}

export type MarkerPopupContentProps = {
  marker: DeviceMarker;
  onNavigate: (deviceId: string) => void;
};
