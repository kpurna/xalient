export const SEVERITY_COLORS: Record<string, string> = {
  healthy: "bg-green-100 text-green-800",
  low: "bg-yellow-100 text-yellow-800",
  medium: "bg-orange-100 text-orange-800",
  high: "bg-red-100 text-red-800",
  0: "bg-green-100 text-green-800",
  1: "bg-yellow-100 text-yellow-800",
  2: "bg-orange-100 text-orange-800",
  3: "bg-red-100 text-red-800"
};
export const SEVERITY = {
  0: "Healthy",
  1: "Low",
  2: "Medium",
  3: "High"
};
