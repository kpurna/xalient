import gzip
import json
import logging
import os
from datetime import datetime

from fastapi import FastAPI, HTTPException, Request
from sqlalchemy import MetaData, Table, create_engine, select
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.orm import sessionmaker

DATABASE_URL = os.environ["DATABASE_URL"]

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

engine = create_engine(DATABASE_URL, future=True)
SessionLocal = sessionmaker(
    bind=engine, expire_on_commit=False, autoflush=False, future=True
)
metadata = MetaData()
alarms_table = Table("alarms", metadata, autoload_with=engine)

TIMESTAMP_COLUMNS = {
    "alarmraisedtime",
    "alarmclearedtime",
    "alarmreportingtime",
    "alarmchangedtime",
}
JSON_COLUMNS = {"correlatedalarm", "alarmedobject", "affectedservice", "parentalarm"}
BOOLEAN_COLUMNS = {"isrootcause"}
DEDUP_KEY = "externalalarmid"

ALARM_COLUMN_MAP = {
    "id": "ID",
    "alarmraisedtime": "ALARMRAISEDTIME",
    "alarmclearedtime": "ALARMCLEAREDTIME",
    "alarmedobjecttype": "ALARMEDOBJECTTYPE",
    "correlatedalarm": "CORRELATEDALARM",
    "btcustomer": "BTCUSTOMER",
    "alarmreportingtime": "ALARMREPORTINGTIME",
    "alarmedobject": "ALARMEDOBJECT",
    "alarmchangedtime": "ALARMCHANGEDTIME",
    "perceivedseverity": "PERCEIVEDSEVERITY",
    "probablecause": "PROBABLECAUSE",
    "btelementclass": "BTELEMENTCLASS",
    "affectedservice": "AFFECTEDSERVICE",
    "acksystemid": "ACKSYSTEMID",
    "state": "STATE",
    "externalalarmid": "EXTERNALALARMID",
    "parentalarm": "PARENTALARM",
    "isrootcause": "ISROOTCAUSE",
    "btsourcesystem": "BTSOURCESYSTEM",
    "ackuserid": "ACKUSERID",
    "btinstancename": "BTINSTANCENAME",
    "btcount": "BTCOUNT",
    "btuserdefined": "BTUSERDEFINED",
    "sourcesystemid": "SOURCESYSTEMID",
    "btntnid": "BTNTNID",
    "btpewmso": "BTPEWMSO",
    "btaffectedcircuit": "BTAFFECTEDCIRCUIT",
    "ackstate": "ACKSTATE",
    "alarmtype": "ALARMTYPE",
    "specificproblem": "SPECIFICPROBLEM",
    "plannedoutageindicator": "PLANNEDOUTAGEINDICATOR",
    "btservername": "BTSERVERNAME",
    "alarmdetails": "ALARMDETAILS",
    "category": "CATEGORY",
    "incidentid": "INCIDENTID",
    "btsite": "BTSITE",
}

app = FastAPI()


def _parse_timestamp(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        logging.warning("Unable to parse timestamp '%s'", value)
        return None


def _normalize_value(column: str, value):
    if value in (None, ""):
        return None
    if column in TIMESTAMP_COLUMNS:
        # return _parse_timestamp(value)
        return value
    if column in BOOLEAN_COLUMNS:
        if isinstance(value, bool):
            return value
        return str(value).lower() == "true"
    if column in JSON_COLUMNS:
        if isinstance(value, (dict, list)):
            return value
        try:
            return json.loads(value)
        except (json.JSONDecodeError, TypeError):
            logging.warning("Unable to parse JSON field '%s': %s", column, value)
            return None
    return value


def _extract_alarm_data(log_record: dict) -> dict | None:
    body = log_record.get("body", {}).get("stringValue")
    if not body:
        return None
    try:
        alarm_payload = json.loads(body)
    except json.JSONDecodeError:
        logging.warning("Skipping log with unparsable body")
        return None

    row = {}
    for column, payload_key in ALARM_COLUMN_MAP.items():
        row[column] = _normalize_value(column, alarm_payload.get(payload_key))
    return row


@app.post("/v1/logs")
async def ingest(request: Request):
    body = await request.body()
    if request.headers.get("content-encoding", "").lower() == "gzip":
        body = gzip.decompress(body)

    try:
        payload = json.loads(body.decode("utf-8"))
    except json.JSONDecodeError as exc:
        raise HTTPException(
            status_code=400, detail=f"Invalid JSON payload: {exc}"
        ) from exc

    rows_to_insert: list[dict] = []
    for resource in payload.get("resourceLogs", []):
        for scope in resource.get("scopeLogs", []):
            for log_record in scope.get("logRecords", []):
                alarm_row = _extract_alarm_data(log_record)
                if alarm_row:
                    rows_to_insert.append(alarm_row)

    if not rows_to_insert:
        return {"status": "ok", "inserted": 0, "updated": 0}

    with SessionLocal() as session:
        insert_rows, update_rows = _split_insert_update(session, rows_to_insert)
        inserted = 0
        updated = 0

        if insert_rows:
            insert_stmt = pg_insert(alarms_table).values(insert_rows)
            update_columns = {
                column.name: insert_stmt.excluded[column.name]
                for column in alarms_table.c
                if column.name != DEDUP_KEY
            }
            session.execute(
                insert_stmt.on_conflict_do_update(
                    index_elements=[getattr(alarms_table.c, DEDUP_KEY)],
                    set_=update_columns,
                )
            )
            inserted = len(insert_rows)

        for key_value, payload in update_rows:
            session.execute(
                alarms_table.update()
                .where(getattr(alarms_table.c, DEDUP_KEY) == key_value)
                .values(**payload)
            )
        if update_rows:
            updated = len(update_rows)

        if insert_rows or update_rows:
            session.commit()

    logging.info(
        "Inserted %d alarm rows, updated %d alarm rows (payload %d)",
        inserted,
        updated,
        len(rows_to_insert),
    )
    return {"status": "ok", "inserted": inserted, "updated": updated}


def _split_insert_update(session, rows):
    keys = {row.get(DEDUP_KEY) for row in rows if row.get(DEDUP_KEY)}
    existing_by_key = {}
    if keys:
        result = session.execute(
            select(alarms_table).where(getattr(alarms_table.c, DEDUP_KEY).in_(keys))
        )
        for row in result.mappings():
            existing_by_key[row[DEDUP_KEY]] = row

    inserts = []
    updates = []
    batch_inserts = set()

    for row in rows:
        key_value = row.get(DEDUP_KEY)
        if not key_value:
            inserts.append(row)
            continue

        existing = existing_by_key.get(key_value)
        if existing is None:
            if key_value not in batch_inserts:
                inserts.append(row)
                batch_inserts.add(key_value)
            continue

        if _has_changes(existing, row):
            updates.append((key_value, row))

    return inserts, updates


def _has_changes(existing_row, new_row):
    for column, value in new_row.items():
        if existing_row.get(column) != value:
            return True
    return False
