import { type Node } from "@xyflow/react";

export type DeviceTopologyProps = {
  interfaces?: {
    id: number;
    name: string | null;
    description: string | null;
    inbound_util: string | null;
    outbound_util: string | null;
    status: string | null;
  }[];
  deviceId?: string;
};

export type DeviceNodeData = {
  label: string;
  hasLeft: boolean;
  hasRight: boolean;
};

export type InterfaceNodeData = {
  label: string;
  description: string;
  inbound: string | null;
  outbound: string | null;
  status: string | null;
  severityColor: string;
};

export type DeviceFlowNode = Node<DeviceNodeData, "deviceNode">;
export type InterfaceFlowNode = Node<InterfaceNodeData, "interfaceNode">;
