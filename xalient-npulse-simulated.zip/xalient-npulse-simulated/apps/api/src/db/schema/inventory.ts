import { boolean, pgTable, serial, timestamp, varchar } from "drizzle-orm/pg-core";
import { createSelectSchema } from "drizzle-zod";

export const inventory = pgTable("inventory", {
  id: serial().primaryKey().unique(),
  bfg_hostname: varchar({ length: 255 }),
  site_cus_type: varchar({ length: 255 }),
  site_name: varchar({ length: 255 }),
  site_cus_region: varchar({ length: 255 }),
  adr_country: varchar({ length: 255 }),
  msa: varchar({ length: 255 }),
  lsa: varchar({ length: 255 }),
  bfg_ip_address: varchar({ length: 255 }),
  vendor: varchar({ length: 255 }),
  model: varchar({ length: 255 }),
  serial_number: varchar({ length: 255 }),
  final_hw_eovss: varchar({ length: 255 }),
  hw_eovss_year: varchar({ length: 255 }),
  final_hw_eol: varchar({ length: 255 }),
  hw_eol_year: varchar({ length: 255 }),
  current_ios_version: varchar({ length: 255 }),
  sw_eol_date: varchar({ length: 255 }),
  sw_eol_year: varchar({ length: 255 }),
  ssv_label: varchar({ length: 255 }),
  site_type: varchar({ length: 255 }),
  tower: varchar({ length: 255 }),
  bfg_ntn_type: varchar({ length: 255 }),
  sw_status: varchar({ length: 255 }),
  hw_customer_dependency: boolean(),
  sw_customer_dep_dependency: boolean(),
  riverbed: boolean(),
  hw_exceptions: varchar({ length: 255 }),
  major_minor_sw_version_upgrade: boolean(),
  recommended_ios: boolean(),
  refesh_status: varchar({ length: 255 }),
  rfq: varchar({ length: 255 }),
  risk_reference: varchar({ length: 255 }),
  action: varchar({ length: 255 }),
  updated_at: timestamp(),
  created_at: timestamp().defaultNow().notNull(),
  deleted_at: timestamp()
});

export const inventorySelectSchema = createSelectSchema(inventory);
