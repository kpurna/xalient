import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export const isMac = () => {
  const userAgent = navigator.userAgent;

  return /Macintosh|Mac|Mac OS|MacIntel|MacPPC|Mac68K/gi.test(userAgent);
};

const getInitials = (name: string) => {
  if (!name) return "";
  const names = name.trim().split(/\s+/);

  // If only one name, return first letter
  if (names.length === 1) {
    return names[0].charAt(0).toUpperCase();
  }

  // If multiple names, return first letter of first and last name
  return (names[0].charAt(0) + names[names.length - 1].charAt(0)).toUpperCase();
};

const formatDate = (timestamp: string) => {
  if (timestamp?.includes("1970")) {
    return "-";
  }
  return timestamp;
  // try {
  //   const d = new Date(timestamp);
  //   return d.toUTCString();
  // } catch (e) {
  //   console.error(e);
  //   return timestamp ?? "-";
  // }
};

export { cn, formatDate, getInitials };
