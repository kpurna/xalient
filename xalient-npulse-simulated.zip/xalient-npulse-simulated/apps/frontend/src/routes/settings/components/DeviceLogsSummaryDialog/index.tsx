import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

// type LogSummaryResponse = InferResponseType<typeof api.logs.$get>;

type DeviceLogsSummaryDialogProps = {
  device: string | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onViewDetails: (device: string) => void;
};

export default function DeviceLogsSummaryDialog({
  device,
  open,
  onOpenChange,
  onViewDetails
}: DeviceLogsSummaryDialogProps) {
  return (
    <Dialog
      open={open}
      onOpenChange={(nextOpen) => {
        if (!nextOpen) {
          onOpenChange(false);
        }
      }}
    >
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Log summary</DialogTitle>
          <DialogDescription>
            {device
              ? `Log types collected for ${device}. Choose “View logs” for detailed records.`
              : "Select a device from the Settings page to see a log summary."}
          </DialogDescription>
        </DialogHeader>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Type</TableHead>
                <TableHead className="text-center">Count</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              <TableRow>
                <TableCell className="capitalize">Syslog</TableCell>
                <TableCell className="text-center">{9}</TableCell>
                <TableCell className="text-right">
                  <Button
                    onClick={() => {
                      if (device) {
                        onViewDetails(device);
                      }
                    }}
                    size={"sm"}
                    disabled={!device}
                  >
                    View logs
                  </Button>
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="capitalize">DPI Metadata</TableCell>
                <TableCell className="text-center">{0}</TableCell>
                <TableCell className="text-right">
                  <Button
                    onClick={() => {
                      if (device) {
                        onViewDetails(device);
                      }
                    }}
                    size={"sm"}
                    disabled={!device}
                  >
                    View logs
                  </Button>
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="capitalize">Netflow</TableCell>
                <TableCell className="text-center">{0}</TableCell>
                <TableCell className="text-right">
                  <Button
                    onClick={() => {
                      if (device) {
                        onViewDetails(device);
                      }
                    }}
                    size={"sm"}
                    disabled={!device}
                  >
                    View logs
                  </Button>
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
