import { boolean, pgTable, serial, timestamp, varchar } from "drizzle-orm/pg-core";

export const smarts_discovery_status_rgt = pgTable("smarts_discovery_status_rgt", {
  id: serial().primaryKey().unique(),
  man_hostname: varchar({ length: 255 }),
  ip_address: varchar({ length: 255 }),
  previous_successful_discovery: boolean(),
  current_discovery_error_message: varchar({ length: 255 }),
  model: varchar({ length: 255 }),
  type: varchar({ length: 255 }),
  certification: varchar({ length: 255 }),
  apm_name: varchar({ length: 255 }),
  first_discovered: varchar({ length: 255 }),
  last_discovered: varchar({ length: 255 }),
  access_mode: varchar({ length: 255 }),
  updated_at: timestamp(),
  created_at: timestamp().defaultNow().notNull(),
  deleted_at: timestamp()
});
