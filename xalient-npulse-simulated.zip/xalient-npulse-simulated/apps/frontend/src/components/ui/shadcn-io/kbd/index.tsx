import { cn } from "@/lib/utils";
import { type ComponentProps, Fragment, type ReactNode } from "react";
import type { Key } from "ts-key-enum";

const DefaultKbdSeparator = ({ className, children = "+", ...props }: ComponentProps<"span">) => (
  <span className={cn("text-neutral-500/50 dark:text-neutral-400/50", className)} {...props}>
    {children}
  </span>
);

export type KbdProps = ComponentProps<"span"> & {
  separator?: ReactNode;
};

export const Kbd = ({ className, separator = <DefaultKbdSeparator />, children, ...props }: KbdProps) => (
  <span
    className={cn(
      "inline-flex items-center gap-1 rounded border border-neutral-200 bg-neutral-100 px-1.5 align-middle font-mono text-[10px] leading-loose font-medium text-neutral-500 select-none dark:border-neutral-800 dark:bg-neutral-800 dark:text-neutral-400",
      className
    )}
    {...props}
  >
    {Array.isArray(children)
      ? children.map((child, index) => (
          <Fragment key={index}>
            {child}
            {index < children.length - 1 && separator}
          </Fragment>
        ))
      : children}
  </span>
);

export type KbdKeyProps = Omit<ComponentProps<"kbd">, "aria-label"> & {
  "aria-label"?: keyof typeof Key | (string & {});
};

// eslint-disable-next-line @typescript-eslint/no-unused-vars
export const KbdKey = ({ className, ...props }: KbdKeyProps) => <kbd {...props} />;
