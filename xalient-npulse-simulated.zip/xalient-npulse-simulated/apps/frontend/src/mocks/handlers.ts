import { http, HttpResponse } from "msw";
export const handlers = [
  http.get("/api/device", () => {
    return HttpResponse.json({
      data: [
        {
          bfg_hostname: "device-14",
          site_name: "Champlin, Veum and Gutmann",
          country: "Ukraine",
          number_of_alerts: "0",
          assigned_to: null,
          severity: "0"
        },
        {
          bfg_hostname: "device-13",
          site_name: "Boyer - McGlynn",
          country: "Seychelles",
          number_of_alerts: "0",
          assigned_to: null,
          severity: "0"
        },
        {
          bfg_hostname: "device-12",
          site_name: "MacGyver LLC",
          country: "Australia",
          number_of_alerts: "1",
          assigned_to: "Sharon Wunsch",
          severity: "2"
        },
        {
          bfg_hostname: "device-11",
          site_name: "Kirlin - Gleason",
          country: "Hungary",
          number_of_alerts: "1",
          assigned_to: "Caleb Leffler",
          severity: "2"
        },
        {
          bfg_hostname: "device-10",
          site_name: "Frami, Stokes and Kub",
          country: "Central African Republic",
          number_of_alerts: "1",
          assigned_to: "Randal Carter Sr.",
          severity: "3"
        },
        {
          bfg_hostname: "device-1",
          site_name: "Volkman - Ruecker",
          country: "Holy See (Vatican City State)",
          number_of_alerts: "2",
          assigned_to: "Bertha Hintz,Randy Welch",
          severity: "1"
        }
      ]
    });
  })
];
