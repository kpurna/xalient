#!/usr/bin/env bash
set -euxo pipefail

export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y --no-install-recommends iproute2 util-linux docker.io ca-certificates
rm -rf /var/lib/apt/lists/*

pid() { docker inspect -f "{{.State.Pid}}" "$1"; }

# Wait until FRR containers have PIDs
for c in r1-frr r2-frr r3-frr; do
  until n="$(pid "$c" 2>/dev/null || true)"; do sleep 0.5; done
  [ "$n" -gt 0 ] || exit 1
done

del_if_in_ns() {
  local ifname="$1" ns_pid="$2"
  nsenter -t "$ns_pid" -n ip link show "$ifname" >/dev/null 2>&1 && \
    nsenter -t "$ns_pid" -n ip link del "$ifname" || true
}

# make_link L R LCONT@LIF RCONT@RIF LIP RIP LMAC RMAC
make_link() {
  local L="$1" R="$2" LNAME="$3" RNAME="$4" LIP="$5" RIP="$6" LMAC="$7" RMAC="$8"

  local LCONT=${LNAME%@*}; local LIF=${LNAME#*@}
  local RCONT=${RNAME%@*}; local RIF=${RNAME#*@}
  local LPID="$(pid "$LCONT")"
  local RPID="$(pid "$RCONT")"

  # Clean any stale pieces
  del_if_in_ns "$L" "$LPID" || true
  del_if_in_ns "$R" "$RPID" || true
  ip link show "$L" >/dev/null 2>&1 && ip link del "$L" || true
  ip link show "$R" >/dev/null 2>&1 && ip link del "$R" || true

  # Create veth pair in host and move ends
  ip link add "$L" type veth peer name "$R"
  ip link set "$L" netns "$LPID"
  ip link set "$R" netns "$RPID"

  # Left end: rename, set MAC, up, address
  nsenter -t "$LPID" -n bash -euxc "
    ip link set dev $L name $LIF
    ip link set dev $LIF address $LMAC
    ip addr flush dev $LIF || true
    ip addr add $LIP dev $LIF
    ip link set dev $LIF up
  "

  # Right end: rename, set MAC, up, address
  nsenter -t "$RPID" -n bash -euxc "
    ip link set dev $R name $RIF
    ip link set dev $RIF address $RMAC
    ip addr flush dev $RIF || true
    ip addr add $RIP dev $RIF
    ip link set dev $RIF up
  "
}

# Stable lab MAC plan (locally administered, unique):
# r1: 02:00:00:01:01:01 (eth1), 02:00:00:01:02:01 (eth2)
# r2: 02:00:00:02:01:01 (eth1), 02:00:00:02:02:01 (eth2)
# r3: 02:00:00:03:01:01 (eth1), 02:00:00:03:02:01 (eth2)

# r1 <-> r2
make_link r1r2-r1 r1r2-r2 \
  r1-frr@eth1 r2-frr@eth1 \
  10.101.0.2/29 10.101.0.3/29 \
  02:00:00:01:01:01 02:00:00:02:01:01

# r1 <-> r3
make_link r1r3-r1 r1r3-r3 \
  r1-frr@eth2 r3-frr@eth1 \
  10.102.0.2/29 10.102.0.4/29 \
  02:00:00:01:02:01 02:00:00:03:01:01

# r2 <-> r3
make_link r2r3-r2 r2r3-r3 \
  r2-frr@eth2 r3-frr@eth2 \
  10.103.0.3/29 10.103.0.4/29 \
  02:00:00:02:02:01 02:00:00:03:02:01

# keep container alive
tail -f /dev/null