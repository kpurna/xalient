import { beforeEach, describe, expect, it, vi } from "vitest";
import createApp from "../../lib/create-app.js";
import deviceRouter from "./device.index.js";

const { selectMock } = vi.hoisted(() => ({
  selectMock: vi.fn()
}));

vi.mock("../../db/index.js", () => ({
  default: {
    select: selectMock
  }
}));

const createDeviceApp = () => {
  const app = createApp();
  app.route("/", deviceRouter);
  return app;
};

let currentQueryParams: Record<string, string> = {};

const requestDeviceApi = async (path: string) => {
  currentQueryParams = Object.fromEntries(new URL(`http://localhost${path}`).searchParams.entries());
  const app = createDeviceApp();
  return app.request(path);
};

const matchesSearch = (value: unknown, search: string) => {
  if (value === null || value === undefined) {
    return false;
  }
  const normalized = search.toLowerCase();
  return value.toString().toLowerCase().includes(normalized);
};

describe("device routes", () => {
  beforeEach(() => {
    selectMock.mockReset();
    currentQueryParams = {};
  });

  const setupDeviceListMock = (rows: Array<Record<string, unknown>>) => {
    selectMock.mockImplementationOnce(() => {
      let whereApplied = false;

      const orderBy = vi.fn(async () => {
        const search = currentQueryParams.searchBy;
        if (!search) {
          return rows;
        }

        if (!whereApplied) {
          return rows;
        }

        return rows.filter((row) =>
          [row.bfg_hostname, row.site_name, row.country, row.assigned_to, row.severity].some((value) =>
            matchesSearch(value, search)
          )
        );
      });

      const groupBy = vi.fn(() => ({ orderBy }));
      const where = vi.fn(() => {
        whereApplied = Boolean(currentQueryParams.searchBy);
        return { groupBy };
      });
      const leftJoin = vi.fn(() => ({ where, groupBy }));
      const from = vi.fn(() => ({ leftJoin, where, groupBy }));

      return { from };
    });
  };

  it("GET /api/device filters aggregated inventory data by search term", async () => {
    const aggregatedInventory = [
      {
        bfg_hostname: "edge-01",
        site_name: "Site A",
        country: "USA",
        number_of_alerts: 4,
        assigned_to: "alice",
        severity: 3
      }
    ];

    setupDeviceListMock(aggregatedInventory);

    const response = await requestDeviceApi("/api/device?sortField=site_name&sortDirection=asc&searchBy=edge");
    const body = await response.json();

    expect(response.status).toBe(200);
    expect(body).toEqual({
      message: "success",
      data: aggregatedInventory
    });
  });

  it("GET /api/device returns empty data when search term is unmatched", async () => {
    const aggregatedInventory = [
      {
        bfg_hostname: "edge-01",
        site_name: "Site A",
        country: "USA",
        number_of_alerts: 4,
        assigned_to: "alice",
        severity: 3
      }
    ];

    setupDeviceListMock(aggregatedInventory);

    const response = await requestDeviceApi("/api/device?sortField=site_name&sortDirection=asc&searchBy=unmatched");
    const body = await response.json();

    expect(response.status).toBe(200);
    expect(body).toEqual({
      message: "success",
      data: []
    });
  });

  it("GET /api/deviceStats returns device statistics", async () => {
    const inventoryRows = [
      { bfg_hostname: "edge-01", site_name: "Site A" },
      { bfg_hostname: "edge-02", site_name: "Site B" },
      { bfg_hostname: "edge-01", site_name: "Site A" }
    ];

    selectMock.mockImplementationOnce(() => {
      const from = vi.fn(async () => inventoryRows);
      return { from };
    });

    selectMock.mockImplementationOnce(() => {
      const where = vi.fn(async () => [{ count: 5 }]);
      const from = vi.fn(() => ({ where }));
      return { from };
    });

    selectMock.mockImplementationOnce(() => {
      const where = vi.fn(async () => [{ count: 1 }]);
      const from = vi.fn(() => ({ where }));
      return { from };
    });

    const response = await requestDeviceApi("/api/deviceStats");
    const body = await response.json();

    expect(response.status).toBe(200);
    expect(body).toEqual({
      message: "success",
      totalDevices: 2,
      deviceWithAlerts: 1,
      totalSites: 2,
      totalSuccessfullyDiscoveredDevices: 5
    });
  });

  it("GET /api/alerts returns alert history within a window", async () => {
    const alerts = [{ id: 1, device_name: "edge-01", severity: "HIGH" }];

    selectMock.mockImplementationOnce(() => {
      const where = vi.fn(async () => alerts);
      const from = vi.fn(() => ({ where }));
      return { from };
    });

    const response = await requestDeviceApi("/api/alerts?startTime=1&endTime=2");
    const body = await response.json();

    expect(response.status).toBe(200);
    expect(body).toEqual({
      message: "Success",
      data: alerts
    });
  });

  it("GET /api/deviceChanges returns change records", async () => {
    const changes = [
      { id: 1, change_number: "CHG001", assignment_group: "NOC" },
      { id: 2, change_number: "CHG001", assignment_group: "NOC" }
    ];

    selectMock.mockImplementationOnce(() => {
      const orderBy = vi.fn().mockResolvedValue(changes);
      const where = vi.fn(() => ({ orderBy }));
      const from = vi.fn(() => ({ where }));
      return { from };
    });

    const response = await requestDeviceApi("/api/deviceChanges?sortField=id&sortDirection=desc&searchBy=");
    const body = await response.json();

    expect(response.status).toBe(200);
    expect(body).toEqual({
      message: "Success",
      data: changes
    });
  });

  it("GET /api/deviceAlerts returns alerts for a device", async () => {
    const alerts = [
      { id: 10, device_name: "edge-01", severity: "LOW" },
      { id: 11, device_name: "edge-02", severity: "HIGH" }
    ];

    selectMock.mockImplementationOnce(() => {
      const orderBy = vi.fn(async () => {
        const deviceId = currentQueryParams.deviceId;
        return deviceId ? alerts.filter((row) => row.device_name === deviceId) : [];
      });
      const where = vi.fn(() => ({ orderBy }));
      const from = vi.fn(() => ({ where }));
      return { from };
    });

    const response = await requestDeviceApi(
      "/api/deviceAlerts?deviceId=edge-01&sortField=id&sortDirection=asc&searchBy="
    );
    const body = await response.json();

    expect(response.status).toBe(200);
    expect(body).toEqual({
      message: "Success",
      data: [{ id: 10, device_name: "edge-01", severity: "LOW" }]
    });
  });

  it("GET /api/deviceInterfaces returns interface list", async () => {
    const interfaces = [
      { id: 1, device_name: "edge-01", interface_name: "eth0" },
      { id: 2, device_name: "edge-02", interface_name: "eth1" },
      { id: 3, device_name: "edge-02", interface_name: "eth0" }
    ];

    selectMock.mockImplementationOnce(() => {
      const where = vi.fn(async () => {
        const deviceId = currentQueryParams.deviceId;
        return deviceId ? interfaces.filter((row) => row.device_name === deviceId) : interfaces;
      });
      const from = vi.fn(() => ({ where }));
      return { from };
    });

    const response = await requestDeviceApi("/api/deviceInterfaces?deviceId=edge-02");
    const body = await response.json();

    expect(response.status).toBe(200);
    expect(body).toEqual({
      message: "Success",
      data: [
        { id: 2, device_name: "edge-02", interface_name: "eth1" },
        { id: 3, device_name: "edge-02", interface_name: "eth0" }
      ]
    });
  });

  it("GET /api/deviceDetails returns inventory rows for a device", async () => {
    const details = [
      { id: 1, bfg_hostname: "edge-01", site_name: "Site A" },
      { id: 2, bfg_hostname: "edge-02", site_name: "Site B" }
    ];

    selectMock.mockImplementationOnce(() => {
      const where = vi.fn(async () => {
        const deviceId = currentQueryParams.deviceId;
        return deviceId ? details.filter((row) => row.bfg_hostname === deviceId) : details;
      });
      const from = vi.fn(() => ({ where }));
      return { from };
    });

    const response = await requestDeviceApi("/api/deviceDetails?deviceId=edge-01");
    const body = await response.json();

    expect(response.status).toBe(200);
    expect(body).toEqual({
      message: "Success",
      data: [{ id: 1, bfg_hostname: "edge-01", site_name: "Site A" }]
    });
  });
});
