import { faker } from "@faker-js/faker";

export const generateMockData = () => {
  return {
    clearTime: faker.date.anytime().toLocaleString(),
    deviceId: faker.number.bigInt({ min: 0, max: 100000000 }).toString(),
    endTime: faker.date.anytime().toLocaleString(),
    ignoreComment: faker.lorem.word(),
    ignoreUid: faker.number.bigInt({ min: 0, max: 10000000 }).toString(),
    ignoreUntil: faker.lorem.word(),
    message: faker.number.int().toString(),
    number: faker.number.bigInt({ min: 0, max: 10000000 }).toString(),
    objectId: faker.number.bigInt({ min: 0, max: 10000000 }).toString(),
    origin: faker.helpers.arrayElement(["UNKNOWN", "SYSTEM", "USER"]),
    pluginName: faker.number.bigInt().toString(),
    pollId: faker.number.bigInt({ min: 0, max: 10000000 }).toString(),
    severity: faker.helpers.arrayElement(["LOW", "MEDIUM", "HIGH", "EMERGENCY"]),
    startTime: faker.date.anytime().toLocaleString()
  };
};

export function generateMockAlerts(count = 10) {
  return Array.from({ length: count }).map(() => generateMockData());
}
