import { ThemeProviderContext } from "@/context/theme-context";
import { render, screen } from "@testing-library/react";
import type { AgCartesianSeriesOptions } from "ag-charts-enterprise";
import { describe, expect, it } from "vitest";
import Chart from ".";

vi.mock("ag-charts-react", () => {
  return {
    AgCharts: vi.fn(() => <div data-testid="ag-charts-mock" />)
  };
});

describe("Chart component rendering", () => {
  const mockSetTheme = vi.fn();
  const mockSeries: AgCartesianSeriesOptions[] = [{ type: "line", xKey: "x", yKey: "y" }];
  const mockData = [{ x: 1, y: 2 }];

  it("renders chart container and AgChartsReact", () => {
    render(
      <ThemeProviderContext.Provider value={{ theme: "light", setTheme: mockSetTheme }}>
        <Chart series={mockSeries} data={mockData} axes={[]} />
      </ThemeProviderContext.Provider>
    );

    expect(screen.getByTestId("ag-charts-mock")).toBeInTheDocument();
    expect(screen.getByTestId("ag-charts-mock")).toBeInTheDocument();
  });
});
