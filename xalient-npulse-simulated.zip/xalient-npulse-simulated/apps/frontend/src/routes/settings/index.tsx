import { createToast } from "@/components/toast/helper";
import { Spinner } from "@/components/ui/spinner";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useBreadcrumbs } from "@/hooks/use-breadcrumbs";
import { api } from "@/lib/api";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import AddDeviceDialog from "./components/AddDeviceDialog";
import type { AddDeviceFormValues } from "./components/AddDeviceDialog/types";
import CollectorsTab from "./components/CollectorsTab";
import DeviceLogsSummaryDialog from "./components/DeviceLogsSummaryDialog";
import DiscoveredDevicesTab from "./components/DiscoveredDevicesTab";
import ManagedDevicesTab from "./components/ManagedDevicesTab";
import SensorsTab from "./components/SensorsTab";
import { getRowKey } from "./helpers";
import type { SaveSettingPayload, SettingRow, UpsertSettingsResponse } from "./types";

const settingsQueryParams = {
  sortField: "device_name",
  sortDirection: "asc",
  searchBy: ""
} as const;

export const Route = createFileRoute("/settings/")({
  component: SettingsPage
});

function SettingsPage() {
  useBreadcrumbs({
    type: "set",
    breadcrumbs: [
      {
        title: "Settings",
        href: "/settings"
      }
    ]
  });

  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const { data, isLoading, isError } = useQuery({
    queryKey: ["settings"],
    queryFn: async () => (await api.settings.$get({ query: settingsQueryParams })).json()
  });

  const saveSettingMutation = useMutation({
    mutationFn: async (payload: SaveSettingPayload) => {
      const response = await api.settings.$post({
        json: payload
      });
      const result: UpsertSettingsResponse = await response.json();
      if (!response.ok) {
        throw new Error(result?.message ?? "Failed to save device settings");
      }
      return result;
    }
  });

  const [rows, setRows] = useState<SettingRow[]>([]);
  const [activeTab, setActiveTab] = useState<"discovery" | "managed" | "collectors" | "sensors">("managed");
  const [isAddDeviceOpen, setIsAddDeviceOpen] = useState(false);
  const [hasActiveEdit, setHasActiveEdit] = useState(false);
  const [logsSummaryDevice, setLogsSummaryDevice] = useState<SettingRow | null>(null);
  const [isLogsSummaryOpen, setIsLogsSummaryOpen] = useState(false);

  const monitoredDevices = useMemo<SettingRow[]>(() => {
    if (!data?.data) return [];

    return data.data.filter((item) => item.is_monitored).map((item) => ({ ...item }));
  }, [data?.data]);

  const availableDevices = useMemo<SettingRow[]>(() => {
    if (!data?.data) return [];

    return data.data.filter((item) => !item.is_monitored).map((item) => ({ ...item }));
  }, [data?.data]);

  useEffect(() => {
    setRows(monitoredDevices);
  }, [monitoredDevices]);

  const handlePromoteDiscoveredDevice = async (device: SettingRow) => {
    if (saveSettingMutation.isPending || !device) return;

    const payload: SaveSettingPayload = {
      id: device.id,
      device_name: device.device_name,
      ip: device.ip,
      netflow: Boolean(device.netflow),
      snmp: Boolean(device.snmp),
      sys_logs: Boolean(device.sys_logs),
      is_monitored: true
    };

    try {
      const result = await saveSettingMutation.mutateAsync(payload);
      const saved = result?.data;

      if (!saved) {
        throw new Error("Invalid response from the server.");
      }

      setRows((prev) => {
        const exists = prev.some((row) => getRowKey(row) === saved.id);
        if (exists) {
          return prev.map((row) => (getRowKey(row) === saved.id ? { ...saved } : row));
        }
        return [{ ...saved }, ...prev];
      });

      setActiveTab("managed");

      createToast({
        title: "Device promoted",
        description: `${saved.device_name ?? "Device"} is now managed.`,
        type: "success"
      });

      void queryClient.invalidateQueries({ queryKey: ["settings"] });
    } catch (error) {
      const message =
        (error instanceof Error && error.message) || "Unable to promote device to managed. Please try again.";

      createToast({
        title: "Promotion failed",
        description: message,
        type: "error"
      });
    }
  };

  if (isLoading) {
    return (
      <div className="flex min-h-[200px] items-center justify-center p-8">
        <Spinner />
      </div>
    );
  }

  if (isError) {
    return (
      <div className="p-4">
        <h1 className="text-2xl font-semibold">Settings</h1>
        <p className="text-muted-foreground mt-2 text-sm">Unable to load device settings right now.</p>
      </div>
    );
  }

  const openLogsSummaryForDevice = (device: SettingRow) => {
    if (!device.device_name) {
      createToast({
        title: "Device name missing",
        description: "Unable to show logs without a device name.",
        type: "warning"
      });
      return;
    }
    setLogsSummaryDevice(device);
    setIsLogsSummaryOpen(true);
  };

  const handleCreateManagedDevice = async (values: AddDeviceFormValues) => {
    if (saveSettingMutation.isPending) return;

    const payload: SaveSettingPayload = {
      id: 0,
      device_name: values.device_name,
      ip: values.ip,
      netflow: values.netflow,
      snmp: values.snmp,
      sys_logs: values.sys_logs,
      is_monitored: true
    };

    try {
      const result = await saveSettingMutation.mutateAsync(payload);
      const saved = result?.data;

      if (!saved) {
        throw new Error("Invalid response from the server.");
      }

      setRows((prev) => {
        const exists = prev.some((row) => getRowKey(row) === saved.id);
        if (exists) {
          return prev.map((row) => (getRowKey(row) === saved.id ? { ...saved } : row));
        }
        return [{ ...saved }, ...prev];
      });

      setActiveTab("managed");
      setIsAddDeviceOpen(false);

      createToast({
        title: "Device added",
        description: `${saved.device_name ?? "Device"} is now managed.`,
        type: "success"
      });

      void queryClient.invalidateQueries({ queryKey: ["settings"] });
    } catch (error) {
      const message = (error instanceof Error && error.message) || "Unable to add device. Please try again.";

      createToast({
        title: "Add failed",
        description: message,
        type: "error"
      });

      throw error;
    }
  };

  const handleUpdateManagedDevice = async (row: SettingRow) => {
    if (saveSettingMutation.isPending) return;

    if (!row.device_name) {
      createToast({
        title: "Device name required",
        description: "Enter a hostname before saving.",
        type: "warning"
      });
      return;
    }

    const payload: SaveSettingPayload = {
      id: row.id,
      device_name: row.device_name,
      ip: row.ip,
      netflow: Boolean(row.netflow),
      snmp: Boolean(row.snmp),
      sys_logs: Boolean(row.sys_logs),
      is_monitored: Boolean(row.is_monitored)
    };

    try {
      const result = await saveSettingMutation.mutateAsync(payload);
      const saved = result?.data;

      if (!saved) {
        throw new Error("Invalid response from the server.");
      }

      setRows((prev) =>
        prev.map((item) => (getRowKey(item) === saved.id ? { ...saved, tempId: undefined, isNew: false } : item))
      );

      createToast({
        title: "Settings saved",
        description: `${saved.device_name ?? "Device"} updated successfully.`,
        type: "success"
      });

      void queryClient.invalidateQueries({ queryKey: ["settings"] });
    } catch (error) {
      const message = (error instanceof Error && error.message) || "Unable to save device settings. Please try again.";
      createToast({
        title: "Save failed",
        description: message,
        type: "error"
      });

      throw error;
    }
  };

  return (
    <div className="p-4">
      <div className="flex flex-1 flex-col gap-4">
        <div className="rounded-2xl border bg-white p-6 dark:border-neutral-800 dark:bg-neutral-900">
          <Tabs
            value={activeTab}
            onValueChange={(value) => {
              setActiveTab(value as typeof activeTab);
            }}
          >
            <TabsList className="gap-2">
              <TabsTrigger value="managed">Managed Devices</TabsTrigger>
              <TabsTrigger value="discovery">Discovered Devices</TabsTrigger>
              <TabsTrigger value="collectors">Collectors</TabsTrigger>
              <TabsTrigger value="sensors">Sensors</TabsTrigger>
            </TabsList>
            <TabsContent value="discovery" className="mt-4">
              <DiscoveredDevicesTab
                devices={availableDevices}
                canAddHost={!saveSettingMutation.isPending && !hasActiveEdit}
                hasActiveEdit={hasActiveEdit}
                isMutationPending={saveSettingMutation.isPending}
                onAddHost={() => setIsAddDeviceOpen(true)}
                onShowLogsSummary={openLogsSummaryForDevice}
                onPromote={handlePromoteDiscoveredDevice}
              />
            </TabsContent>
            <TabsContent value="managed" className="mt-4">
              <ManagedDevicesTab
                rows={rows}
                isMutationPending={saveSettingMutation.isPending}
                onSaveRow={handleUpdateManagedDevice}
                onEditingChange={setHasActiveEdit}
                onShowLogsSummary={openLogsSummaryForDevice}
              />
            </TabsContent>
            <TabsContent value="collectors" className="mt-4">
              <CollectorsTab />
            </TabsContent>
            <TabsContent value="sensors" className="mt-4">
              <SensorsTab />
            </TabsContent>
          </Tabs>
        </div>
      </div>
      <AddDeviceDialog
        open={isAddDeviceOpen}
        isSubmitting={saveSettingMutation.isPending}
        onOpenChange={(open) => setIsAddDeviceOpen(open)}
        onSubmit={handleCreateManagedDevice}
      />
      <DeviceLogsSummaryDialog
        device={logsSummaryDevice?.device_name ?? null}
        open={isLogsSummaryOpen}
        onOpenChange={(open) => {
          setIsLogsSummaryOpen(open);
          if (!open) {
            setLogsSummaryDevice(null);
          }
        }}
        onViewDetails={(deviceName) => {
          setIsLogsSummaryOpen(false);
          setLogsSummaryDevice(null);
          navigate({
            to: "/logs",
            search: { device: deviceName }
          });
        }}
      />
    </div>
  );
}
