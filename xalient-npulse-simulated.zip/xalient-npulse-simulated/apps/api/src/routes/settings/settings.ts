import { StatusCodes } from "http-status-codes";
import type { AppRouteHandler } from "../../lib/types.ts";

import { and, eq, or, sql, type AnyColumn, type SQLWrapper } from "drizzle-orm";
import db from "../../db/index.js";
import { settings } from "../../db/schema/settings.js";
import { sortType } from "./settings.helper.js";
import type { SettingList, SettingUpsert } from "./settings.routes.js";

export const deviceSettings: AppRouteHandler<SettingList> = async (c) => {
  const { sortDirection, sortField, searchBy } = c.req.valid("query");

  const sort = sortType(sortDirection);

  const columnMap: Record<string, AnyColumn | SQLWrapper> = {
    ip: settings.ip,
    device_name: settings.device_name
  };

  const column = columnMap[sortField] ?? settings.id;

  const conditions: (SQLWrapper | undefined)[] = [
    searchBy
      ? or(
          sql`${settings.ip}::text ILIKE ${`%${searchBy}%`}`,
          sql`${settings.device_name}::text ILIKE ${`%${searchBy}%`}`
        )
      : undefined
  ].filter(Boolean);

  const devices = await db
    .select()
    .from(settings)
    .where(and(...conditions))
    .orderBy(sort(column));
  // .limit(pageSize);

  return c.json(
    {
      message: "success",
      data: devices
    },
    StatusCodes.OK
  );
};

export const upsertDeviceSetting: AppRouteHandler<SettingUpsert> = async (c) => {
  const body = c.req.valid("json");
  const { id, device_name, ip, netflow, snmp, sys_logs, is_monitored } = body;

  const payload = {
    device_name: device_name,
    ip: ip,
    netflow: netflow ?? false,
    snmp: snmp ?? false,
    sys_logs: sys_logs ?? false,
    is_monitored: is_monitored ?? false
  };

  const save = async (settingId: number) => {
    const [updated] = await db.update(settings).set(payload).where(eq(settings.id, settingId)).returning();

    return updated ?? null;
  };

  if (id) {
    const updated = await save(id);

    if (!updated) {
      return c.json(
        {
          message: "Device setting not found",
          data: { id, ...payload }
        },
        StatusCodes.NOT_FOUND
      );
    }

    return c.json(
      {
        message: "success",
        data: updated
      },
      StatusCodes.OK
    );
  }

  const [existing] = await db.select().from(settings).where(eq(settings.device_name, device_name)).limit(1);

  if (existing) {
    const updated = await save(existing.id);

    return c.json(
      {
        message: "success",
        data: updated
      },
      StatusCodes.OK
    );
  }

  const [created] = await db.insert(settings).values(payload).returning();

  return c.json(
    {
      message: "success",
      data: created
    },
    StatusCodes.CREATED
  );
};
