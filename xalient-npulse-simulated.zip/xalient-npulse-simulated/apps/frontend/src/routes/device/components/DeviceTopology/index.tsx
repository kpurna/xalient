import { useNavigate } from "@tanstack/react-router";
import { Background, Controls, ReactFlow } from "@xyflow/react";
import "@xyflow/react/dist/style.css";
import { memo, useCallback, useMemo } from "react";
import { buildNodesAndEdges } from "./components/BuildNodeAndEdges";
import { DeviceNode } from "./components/DeviceNode";
import { InterfaceNode } from "./components/InterfaceNode";
import type { DeviceTopologyProps } from "./types";

function DeviceTopologyMap({ interfaces, deviceId }: DeviceTopologyProps) {
  const navigate = useNavigate();
  const { nodes, edges } = useMemo(() => buildNodesAndEdges(interfaces), [interfaces]);
  const handleNodeClick = useCallback(
    (
      event: { preventDefault: () => void; stopPropagation: () => void },
      node: { id: string; data: { url?: string; label?: string } }
    ) => {
      event.preventDefault();
      event.stopPropagation();

      if (node.id.startsWith("interface-") && node?.data?.label) {
        navigate({
          to: "/device/components/Interface/interface/$interfaceId",
          params: { interfaceId: encodeURIComponent(node.data.label) },
          search: deviceId ? { deviceId } : undefined
        });
      }
    },
    [navigate, deviceId]
  );

  const nodeTypes = useMemo(
    () => ({
      deviceNode: DeviceNode,
      interfaceNode: InterfaceNode
    }),
    []
  );

  return (
    <div className="relative h-[360px] overflow-hidden rounded-2xl border border-neutral-200 bg-white shadow-sm dark:border-neutral-800 dark:bg-neutral-900">
      <ReactFlow
        className="device-topology-flow"
        nodes={nodes}
        edges={edges}
        fitView
        onNodeClick={handleNodeClick}
        nodeTypes={nodeTypes}
      >
        <Controls showZoom={true} showInteractive={false} showFitView={true} position="top-right" />
        <Background gap={20} color="#e2e8f0" />
      </ReactFlow>
    </div>
  );
}

export default memo(DeviceTopologyMap);
