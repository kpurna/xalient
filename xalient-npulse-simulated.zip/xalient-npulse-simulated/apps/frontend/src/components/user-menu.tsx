import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { getInitials } from "@/lib/utils";
import { Avatar, AvatarFallback, AvatarImage } from "@radix-ui/react-avatar";
import { Link } from "@tanstack/react-router";
import { ThemeSelector } from "./theme-selector";
interface UserMenuProps {
  name: string;
  role: string;
  routes: { title: string; href: string; icon: React.ReactNode }[];
  imageUrl?: string;
}
const UserMenu = ({ name, role, routes, imageUrl }: UserMenuProps) => {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger className="rounded-lg p-3 transition-colors hover:bg-gray-100 data-[state=open]:bg-gray-100 dark:hover:bg-black dark:data-[state=open]:bg-black">
        <div className="flex items-center gap-4">
          <Avatar className="h-10 w-10">
            <AvatarImage src={imageUrl || undefined} />
            <AvatarFallback>{getInitials(name)}</AvatarFallback>
          </Avatar>
          <div className="flex flex-col">
            <span className="text-sm font-bold">{name}</span>
            <span className="text-sm tracking-wider text-gray-500">{role}</span>
          </div>
        </div>
      </DropdownMenuTrigger>
      <DropdownMenuContent side="right" align="end">
        <DropdownMenuLabel>My Account</DropdownMenuLabel>
        <DropdownMenuSeparator />
        {routes.map((item) => (
          <DropdownMenuItem key={item.title} asChild>
            <Link to={item.href} reloadDocument={item.href.includes("api/docs") ? true : false}>
              {item.icon}
              {item.title}
            </Link>
          </DropdownMenuItem>
        ))}
        <DropdownMenuSeparator />

        <ThemeSelector />
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

export default UserMenu;
