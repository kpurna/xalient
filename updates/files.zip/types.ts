import type { api } from "@/lib/api";
import type { PaginationState, SortingState } from "@tanstack/react-table";
import type { InferResponseType } from "hono/client";

type DeviceAlertsResponse = InferResponseType<typeof api.deviceAlerts.$get>;
type ChangeResponse = InferResponseType<typeof api.deviceChanges.$get>;
type DeviceDataResponse = InferResponseType<typeof api.device.$get>;
type AlarmsResponse = InferResponseType<typeof api.alerts.$get>;

export type DeviceAlert = DeviceAlertsResponse["data"][number];
export type DeviceData = DeviceDataResponse["data"][number];
export type Change = ChangeResponse["data"][number];
export type Alarm = AlarmsResponse["data"][number];

export interface DataTableType {
  data: DeviceAlert[] | Change[] | DeviceData[];
  paginationFilters: PaginationState;
  setPaginationFilters: React.Dispatch<React.SetStateAction<PaginationState>>;
  searchBy: string;
  setSearchBy: React.Dispatch<React.SetStateAction<string>>;
  sorting: SortingState;
  setSorting: React.Dispatch<React.SetStateAction<SortingState>>;
  total: number;
  tableName: "changes" | "dashboard" | "deviceAlerts";
  isLoading?: boolean;
}
