import { Check, X } from "lucide-react";

export function StatusIcon({ checked }: { checked: boolean }) {
  return checked ? (
    <Check className="mx-auto h-5 w-5 text-emerald-500" aria-label="enabled" />
  ) : (
    <X className="mx-auto h-5 w-5 text-red-500" aria-label="disabled" />
  );
}
