# Monorepo Template

## Useful links

- [Getting Started](https://github.com/unmod-zurich/pulse/wiki/Getting-Started)
