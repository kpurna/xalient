import { eq, sql } from "drizzle-orm";
import { StatusCodes } from "http-status-codes";
import db from "../../db/index.js";
import { otelLogs } from "../../db/schema/otelLogs.js";
import type { AppRouteHandler } from "../../lib/types.js";
import type { GetLogs } from "./logs.routes.js";

export const logsHandler: AppRouteHandler<GetLogs> = async (c) => {
  const { device, limit } = c.req.valid("query");

  const rows = await db
    .select({
      time: sql<string>`${otelLogs.time}::text`,
      tag: otelLogs.tag,
      message: sql<string>`${otelLogs.data}::text`
    })
    .from(otelLogs)
    .where(eq(otelLogs.tag, device))
    .limit(limit);

  return c.json(
    {
      data: {
        logs: rows,
        total: rows.length
      }
    },
    StatusCodes.OK
  );
};
