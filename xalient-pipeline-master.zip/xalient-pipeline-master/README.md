# Pipelines - OpenTelemetry Collector

This repository holds a **modular OpenTelemetry Collector configuration** split config by concern across small YAML files, plus a CI pipeline that validates/merges those files and publishes a single rendered `config.yaml` for deployment.

## Goal

* Author small, focused YAML files under `opentelemetry-collector-contrib/**`.
* GitHub Actions:

  1. **validate** — lint + parse + merge
  2. **smoke\_test** — boot the Collector for \~20s
  3. **publish** — commit rendered config to `dist/otelcol/config.yaml` (main branch only)
* GitOps:

  1. A Fedora host **pulls** the rendered file and **reloads** the Collector.

---

## Repository layout

```
.
├─ .github/workflows/
│  └─ otel-config-ci.yaml           # CI: lint, validate, merge, smoke test, publish
├─ .yamllint.yaml                   # Lint rules for YAML
├─ opentelemetry-collector-contrib/
│  ├─ versions.env                  # Pins Collector image version for CI
│  ├─ 20-extensions.yaml            # (global) extensions and optional service.extensions
│  ├─ 40-processors.yaml            # (global) processors
│  ├─ logs/
│  │  └─ zeek/
│  │     ├─ 30-receivers.yaml       # receivers (e.g., filelog/*)
│  │     ├─ 40-processors.yaml      # processors (resource/…, transform/…, batch)
│  │     ├─ 50-exporters.yaml       # exporters (e.g., elasticsearch, debug)
│  │     └─ 90-pipelines.yaml       # service.pipelines for this signal
│  └─ metrics/
│     └─ … (snmp, gnmi, etc.)       # same 30/40/50/90 pattern
├─ dist/
│  └─ otelcol/
│     └─ config.yaml                # rendered by CI after tests pass (GitOps target)
└─ README.md                        # this file
```

### File-ordering convention

Files are merged in **lexicographic** order using a simple numeric prefix:

* `20-extensions.yaml` (global)
* `30-*` receivers
* `40-*` processors
* `50-*` exporters
* `90-*` pipelines (keep pipelines last)

> **Merging rules (important):**
>
> * **Maps** (e.g., `receivers:`, `processors:`) are merged by **key**; later files can **override** existing keys.
> * **Lists** (e.g., `service.pipelines.logs/conn.processors`) are **replaced** by the last file that sets them.

---

## Authoring guidelines

* **OTTL statements** (in `transform/*`):

  * Use **folded block scalars** (`>-`) for readability; YAML folds newlines into spaces so OTTL sees one clean line.
  * Use explicit context to avoid info logs: `log.attributes["…"]`, `log.time_unix_nano`.
* **Regex in receivers**:

  * Keep as **double-quoted strings**. If you must wrap lines, end them with a backslash (`\`) and ensure **no trailing spaces**.
  * Example:

    ```yaml
    - regex: "^(?P<ts>[^\t]+)\t(?P<uid>[^\t]+)\t\
    (?P<id_orig_h>[^\t]+)\t(?P<id_orig_p>[^\t]+)\t..."
    ```
* **YAML linting**: We enforce `.yamllint.yml`. Prefer 2-space indent, `---` document start, and newline at EOF.

---

## CI pipeline (GitHub Actions)

Workflow: `.github/workflows/otel-config-ci.yml`

1. **validate** (runs on pushes/PRs to YAML under `opentelemetry-collector-contrib/**`)

   * Loads **pinned version** from `versions.env` (e.g., `otel/opentelemetry-collector-contrib:0.132.0`).
   * Lints YAML with `yamllint`.
   * Builds the ordered file list (20/30/40/50/90) and runs:

     * `validate` — schema/config parsing
     * `print-initial-config` (feature gate enabled) — writes `merged-config.yaml`
   * Reinserts **auth placeholders** so secrets aren’t baked into artifacts:

     ```yaml
     username: ${ELASTIC_USERNAME}
     password: ${ELASTIC_PASSWORD}
     ```
   * Uploads `merged-config.yaml` as an artifact.

2. **smoke\_test** (needs: validate)

   * Downloads `merged-config.yaml` to auto-discover pipelines.
   * Generates a CI-only override that swaps **all exporters** to `debug/ci` (so no external services are required).
   * Boots the Collector in a container for \~20s; **timeout is treated as success**.
   * Uploads `smoke-startup.log`.

3. **publish** (needs: validate, smoke\_test) — **main branch only**

   * Commits the rendered config to `dist/otelcol/config.yaml` in this repo with a stamped comment.
   * Uses `[skip ci]` to avoid loops.
   * Result: the latest, tested render is always available for GitOps pull.

---

## Secrets

We **never** commit real secrets. Rendered config uses placeholders (`${ELASTIC_USERNAME}`, `${ELASTIC_PASSWORD}`).

On the Linux host, a systemd **EnvironmentFile** supplies the values:

```
/etc/otelcol-contrib/secrets/elasticsearch.env (0600)
ELASTIC_USERNAME=...
ELASTIC_PASSWORD=...
```

And the service has a drop-in:

```
/etc/systemd/system/otelcol-contrib.service.d/20-env.conf
[Service]
EnvironmentFile=/etc/otelcol-contrib/secrets/elasticsearch.env
```

Alternative: use a single **API key** header:
`Authorization: ApiKey ${ELASTIC_API_KEY}`.

---

## GitOps on Fedora

A lightweight systemd timer **pulls** the repo and **reloads** the Collector if `dist/otelcol/config.yaml` changed.

* Repo clone: `/opt/gitops/pipelines`
* Rendered file: `dist/otelcol/config.yaml`
* Deployed file: `/etc/otelcol-contrib/config.yaml`
* Reload: `systemctl reload otelcol-contrib` (SIGHUP)
  *(drop-in adds `ExecReload=/bin/kill -HUP $MAINPID`)*

---

## Version pinning

* CI pins the Collector image via `opentelemetry-collector-contrib/versions.env`.
  Keep this aligned with the version on your hosts for deterministic renders.
* Tag repo releases (`vX.Y.Z`) when you want known-good checkpoints.

---

## Making changes

1. Create a branch off `main`.
2. Edit or add split files under `opentelemetry-collector-contrib/**`:

   * receivers → `30-*.yaml`
   * processors → `40-*.yaml`
   * exporters → `50-*.yaml`
   * pipelines → `90-*.yaml`
3. Push → CI runs (lint/validate/smoke). Fix any errors.
4. Open a PR. When merged to `main`, CI publishes `dist/otelcol/config.yaml`.

---

## Why this structure?

* Small files are easier to review, test, and reuse.
* The workflow guarantees every rendered config is **linted, valid, and boots** before it’s published.
* GitOps pull on the host keeps runtime in sync.

---

# Below needs updating

## Diagram

```mermaid
graph LR
    %% --- Style Definitions ---
    classDef metric fill:#f9d5a7,stroke:#b85d0d,stroke-width:2px;
    classDef log fill:#a7d5f9,stroke:#0d5db8,stroke-width:2px;
    %% --- Sources  ---
    DT("Devices / Tools<br>(Various Types / Vendors)")
    Zeek("Packets<br>Zeek")

    %% --- OpenTelemetry Collector  ---
    subgraph OTel["OpenTelemetry Collector"]
        direction TB
        
        subgraph Receivers
            direction TB
            R_SNMP("SNMP<br>OTLP Receiver (SNMP)"):::metric
            R_ST("Streaming Telemetry<br>OTLP Receiver (gRPC)"):::metric
            R_Flows("Flows<br>OTLP Receiver (NetFlow)"):::log
            R_CM_conns("Connections Log<br>OTLP Receiver (FileLog)"):::log
            R_CM_ssl("SSL Log<br>OTLP Receiver (FileLog)"):::log
            R_CM_x509("X509 Log<br>OTLP Receiver (FileLog)"):::log
        end
        
        subgraph Processors
            direction TB
            subgraph ProcessorChain1[" "]
                direction LR
                P_Filter_SNMP("Filter<br>(Clean)"):::metric --> P_Resource_SNMP("Resource<br>(Enrich)"):::metric --> P_Batch_SNMP("Batch<br>(Group)"):::metric
            end
            subgraph ProcessorChain2[" "]
                direction LR
                P_Filter_ST("Filter<br>(Clean)"):::metric --> P_Resource_ST("Resource<br>(Enrich)"):::metric --> P_Batch_ST("Batch<br>(Group)"):::metric
            end
            subgraph ProcessorChain3[" "]
                direction LR
                P_Filter_Flows("Filter<br>(Clean)"):::log --> P_Resource_Flows("Resource<br>(Enrich)"):::log --> P_Batch_Flows("Batch<br>(Group)"):::log
            end
            subgraph ProcessorChain4[" "]
                direction LR
                P_Transform_CM("Transform<br>(Type Cast)"):::log --> P_Batch_CM("Batch<br>(Group)"):::log
            end
        end
        
        subgraph Exporters
            direction TB
            E_Metrics_SNMP("OTLP Exporter<br>(InfluxDB)"):::metric
            E_Metrics_ST("OTLP Exporter<br>(InfluxDB)"):::metric
            E_logs_Flows("OTLP Exporter<br>(ElasticSearch)"):::log
            E_logs_CM("OTLP Exporter<br>(ElasticSearch)"):::log
        end

        subgraph Extensions
            direction TB
            Ext_Health("healthcheck<br>Collector & Pipeline Health")
            Ext_WAL("file_storage<br>Write-Ahead Log (WAL)")
            Ext_BA("basicauth<br>Authentication")
        end
    end

    %% --- Storage  ---
    S_Metrics("Storage<br>(Metrics)"):::metric
    S_logs("Storage<br>(Logs)"):::log
    
    %% --- Connections ---
    DT -- "Metric Pipeline" --> R_SNMP
    DT -- "Metric Pipeline" --> R_ST
    DT -- "Log Pipeline" --> R_Flows
    DT --> Zeek
    
    Zeek -- "Log Pipeline" --> R_CM_conns
    Zeek -- "Log Pipeline" --> R_CM_ssl
    Zeek -- "Log Pipeline" --> R_CM_x509

    R_SNMP --> P_Filter_SNMP
    R_ST --> P_Filter_ST
    R_Flows --> P_Filter_Flows
    R_CM_conns --> P_Transform_CM
    R_CM_ssl --> P_Transform_CM
    R_CM_x509 --> P_Transform_CM

    P_Batch_SNMP --> E_Metrics_SNMP
    P_Batch_ST --> E_Metrics_ST
    P_Batch_Flows --> E_logs_Flows
    P_Batch_CM --> E_logs_CM

    E_Metrics_SNMP --> S_Metrics
    E_Metrics_ST --> S_Metrics
    E_logs_Flows --> S_logs
    E_logs_CM --> S_logs
```
