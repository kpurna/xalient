export interface ToastProps {
  type?: "default" | "success" | "error" | "warning";
  id: string | number;
  title: string;
  description: string;
  button?: {
    label: string;
    onClick: () => void;
  };
}
