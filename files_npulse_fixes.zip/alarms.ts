import { boolean, json, pgTable, text, timestamp, varchar } from "drizzle-orm/pg-core";
import { createSelectSchema } from "drizzle-zod";

export const alarms = pgTable("alarms", {
  id: varchar({ length: 255 }).primaryKey(),
  alarmRaisedTime: timestamp({ withTimezone: true }),
  alarmClearedTime: timestamp({ withTimezone: true }),
  alarmedObjectType: varchar({ length: 255 }),
  correlatedAlarm: json(),
  btCustomer: varchar({ length: 255 }),
  alarmReportingTime: timestamp({ withTimezone: true }),
  alarmedObject: json(),
  alarmChangedTime: timestamp({ withTimezone: true }),
  perceivedSeverity: varchar({ length: 255 }),
  probableCause: varchar({ length: 255 }),
  btElementClass: varchar({ length: 255 }),
  affectedService: json(),
  ackSystemId: varchar({ length: 255 }),
  state: varchar({ length: 255 }),
  externalAlarmId: varchar({ length: 255 }).unique(),
  parentAlarm: json(),
  isRootCause: boolean(),
  btSourceSystem: varchar({ length: 255 }),
  ackUserId: varchar({ length: 255 }),
  btInstanceName: varchar({ length: 255 }),
  btCount: varchar({ length: 255 }),
  btUserDefined: varchar({ length: 255 }),
  sourceSystemId: varchar({ length: 255 }),
  btNtnId: varchar({ length: 255 }),
  btPewMso: varchar({ length: 255 }),
  btAffectedCircuit: varchar({ length: 255 }),
  ackState: varchar({ length: 255 }),
  alarmType: varchar({ length: 255 }),
  specificProblem: text(),
  plannedOutageIndicator: varchar({ length: 255 }),
  btServerName: varchar({ length: 255 }),
  alarmDetails: text(),
  category: varchar({ length: 255 }),
  incidentId: varchar({ length: 255 }),
  btSite: varchar({ length: 255 }),
});

// Zod schema for selects
export const alarmSelectSchema = createSelectSchema(alarms);