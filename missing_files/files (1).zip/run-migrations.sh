#!/bin/sh
set -euo pipefail

echo "Running database migrations and seed..."
cd /repo/apps/api

echo "Dropping existing tables..."
node dist/src/db/drop-all-tables.js

echo "Running Drizzle migrations..."
node dist/src/db/migrate.js

echo "Seeding database..."
node dist/src/db/seed.js --alerts=200 --changes=100 --interfaces=200 --inventory=30 --smarts_discovery_status_rgt=10 --settings=3

echo "Database initialized."
