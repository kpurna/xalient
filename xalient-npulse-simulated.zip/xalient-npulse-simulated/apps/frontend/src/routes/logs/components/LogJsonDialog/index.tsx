import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import type { LogJsonDialogProps } from "./types";

export function LogJsonDialog({ log, parsed, onClose }: LogJsonDialogProps) {
  return (
    <Dialog open={Boolean(log)} onOpenChange={(open) => (!open ? onClose() : null)}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Log JSON</DialogTitle>
        </DialogHeader>
        {log ? (
          <div className="space-y-4">
            <div className="text-muted-foreground grid gap-1 text-xs">
              <span className="font-medium text-neutral-600 dark:text-neutral-200">Timestamp</span>
              <span className="font-mono">{log.time}</span>
              <span className="font-medium text-neutral-600 dark:text-neutral-200">Tag</span>
              <span className="font-mono">{log.tag ?? "-"}</span>
            </div>
            <div className="rounded-xl border bg-neutral-950/90 p-4 text-neutral-100 dark:border-neutral-800 dark:bg-neutral-900">
              <pre className="max-h-[480px] overflow-auto text-xs leading-relaxed">
                {parsed ? JSON.stringify(parsed, null, 2) : (log.message ?? "-")}
              </pre>
            </div>
          </div>
        ) : null}
      </DialogContent>
    </Dialog>
  );
}
