import js from "@eslint/js";
import eslintConfigPrettier from "eslint-config-prettier/flat";
import turboPlugin from "eslint-plugin-turbo";
import tseslint from "typescript-eslint";
import onlyWarn from "eslint-plugin-only-warn";
import globals from "globals";
import { globalIgnores } from "eslint/config";

/**
 * A shared ESLint configuration for the repository.
 *
 * @type {import("eslint").Linter.Config[]}
 * */
export const config = [
  globalIgnores(["dist"]),
  js.configs.recommended,
  eslintConfigPrettier,
  ...tseslint.configs.strict,
  {
    plugins: {
      turbo: turboPlugin
    },
    rules: {
      "turbo/no-undeclared-env-vars": "warn"
    }
  },
  {
    plugins: {
      onlyWarn
    }
  },
  {
    ignores: ["dist/**", "coverage/**"]
  },
  {
    languageOptions: {
      ecmaVersion: 2020,
      globals: globals.browser
    }
  }
];
