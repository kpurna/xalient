import { DataTable } from "@/components/table";
import { useBreadcrumbs } from "@/hooks/use-breadcrumbs";
import { api } from "@/lib/api";
import { useQuery } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import type { PaginationState, SortingState } from "@tanstack/react-table";
import React, { useEffect } from "react";
import DeviceCard from "./components/DeviceCard";

export const Route = createFileRoute("/device/device/$deviceId")({
  component: Device
});

export function Device() {
  const { deviceId } = Route.useParams();
  useBreadcrumbs({
    type: "set",
    breadcrumbs: [
      {
        title: "Dashboard",
        href: "/dashboard"
      },
      {
        title: "Devices"
      },
      {
        title: deviceId
      }
    ]
  });
  // Default sort by "id" to match simulated repo
  const [sorting, setSorting] = React.useState<SortingState>([{ id: "id", desc: true }]);
  const [paginationFilters, setPaginationFilters] = React.useState<PaginationState>({ pageIndex: 0, pageSize: 10 });
  const [searchBy, setSearchBy] = React.useState<string>("");

  const { data: deviceDetails, refetch: refetchDeviceDetails } = useQuery({
    // eslint-disable-next-line @tanstack/query/exhaustive-deps
    queryKey: ["device-details"],
    enabled: false,
    queryFn: async () =>
      (
        await api.deviceDetails.$get({
          query: {
            deviceId
          }
        })
      ).json()
  });

  const {
    data: deviceAlerts,
    refetch: refetchTableData,
    isFetching: isFetchingDeviceAlerts,
    isPending: isPendingDeviceAlerts
  } = useQuery({
    // eslint-disable-next-line @tanstack/query/exhaustive-deps
    queryKey: ["device-alerts"],
    enabled: false,
    queryFn: async () =>
      (
        await api.deviceAlerts.$get({
          query: {
            deviceId,
            sortField: sorting[0].id,
            sortDirection: sorting[0].desc ? "desc" : "asc",
            searchBy
          }
        })
      ).json()
  });

  const { data: deviceInterfaces, refetch: refetchInterfacesData } = useQuery({
    // eslint-disable-next-line @tanstack/query/exhaustive-deps
    queryKey: ["device-interface"],
    enabled: false,
    queryFn: async () =>
      (
        await api.deviceInterfaces.$get({
          query: {
            deviceId
          }
        })
      ).json()
  });

  useEffect(() => {
    refetchTableData();
  }, [sorting, searchBy, refetchTableData]);

  useEffect(() => {
    refetchDeviceDetails();
    refetchInterfacesData();
  }, [refetchDeviceDetails, refetchInterfacesData]);

  const isAlertsLoading = isPendingDeviceAlerts || (isFetchingDeviceAlerts && !deviceAlerts);

  return (
    <div className="px-4 lg:px-6">
      <div className="space-y-8">
        {deviceDetails?.data && (
          <DeviceCard
            device={deviceDetails?.data[0] ?? {}}
            interfaces={deviceInterfaces?.data ?? []}
            deviceId={deviceId}
          />
        )}

        <h3 className="text-lg font-semibold">Alerts</h3>
        <div className="rounded-2xl border bg-white p-4 dark:border-neutral-800 dark:bg-neutral-900">
          <DataTable
            data={deviceAlerts?.data ?? []}
            sorting={sorting}
            paginationFilters={paginationFilters}
            setSorting={setSorting}
            setPaginationFilters={setPaginationFilters}
            setSearchBy={setSearchBy}
            searchBy={searchBy}
            total={deviceAlerts?.data.length ?? 0}
            tableName="deviceAlerts"
            isLoading={isAlertsLoading}
          />
        </div>
      </div>
    </div>
  );
}
