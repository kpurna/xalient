import { cn } from "@/lib/utils";
import { CircleAlert, CircleCheck, XCircleIcon } from "lucide-react";
import { toast as sonnerToast } from "sonner";
import type { ToastProps } from "./types";

const renderIcon = (type: ToastProps["type"]) => {
  const iconStyles = "h-4 w-4";
  const dataTestId = `toast-icon-${String(type)}`;
  switch (type) {
    case "success":
      return <CircleCheck data-testid={dataTestId} className={cn(iconStyles, "text-green-500")} />;
    case "error":
      return <XCircleIcon data-testid={dataTestId} className={cn(iconStyles, "text-red-500")} />;
    case "warning":
      return <CircleAlert data-testid={dataTestId} className={cn(iconStyles, "text-yellow-500")} />;
    default:
      return null;
  }
};

const Toast = ({ id, title, description, button, type = "default" }: ToastProps) => {
  return (
    <div className="flex w-full items-center rounded-lg bg-white p-4 shadow-lg ring-1 ring-black/5 md:max-w-[364px]">
      <div className="flex flex-1 items-center">
        <div className="w-full">
          <div className="flex items-center space-x-2">
            {renderIcon(type)}
            <p data-testid="toast-title" className="cursor-default text-sm font-medium text-gray-900 select-none">
              {title}
            </p>
          </div>
          <p data-testid="toast-description" className="mt-1 cursor-default text-sm text-gray-500 select-none">
            {description}
          </p>
        </div>
      </div>
      <div className="ml-5 shrink-0 rounded-md text-sm font-medium text-indigo-600 hover:text-indigo-500 focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 focus:outline-hidden">
        {button && (
          <button
            className="rounded bg-indigo-50 px-3 py-1 text-sm font-semibold text-indigo-600 hover:bg-indigo-100"
            data-testid="toast-button"
            onClick={() => {
              button.onClick();
              sonnerToast.dismiss(id);
            }}
          >
            {button.label}
          </button>
        )}
      </div>
    </div>
  );
};

export { Toast };
