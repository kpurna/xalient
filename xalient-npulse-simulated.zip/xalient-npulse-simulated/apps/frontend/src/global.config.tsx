/**
 * Global configuration file for the application.
 */

import { CogIcon, FileIcon, InfoIcon, LayoutDashboard, LogOutIcon, UserIcon } from "lucide-react";

const APP_NAME = import.meta.env.VITE_APP_NAME;

if (!APP_NAME) {
  throw new Error("APP_NAME is not defined in the environment variables.");
}

const devSettings = {
  devtools: {
    routerButtonPosition: "top-right" as const,
    queryPosition: "bottom" as const,
    queryButtonPosition: "bottom-right" as const
  }
};

const storage = {
  localStorage: {
    themeKey: `${APP_NAME}-theme`
  }
};

const sidebarUserSettings = {
  menu: [
    {
      id: "profile",
      icon: <UserIcon />,
      title: "Profile",
      href: "/profile"
    },
    {
      id: "settings",
      icon: <CogIcon />,
      title: "Settings",
      href: "/settings"
    },
    {
      id: "help",
      icon: <InfoIcon />,
      title: "Help",
      href: "/help"
    },
    {
      id: "documentation",
      icon: <FileIcon />,
      title: "API Documentation",
      href: "/api/docs"
    },
    {
      id: "logout",
      icon: <LogOutIcon />,
      title: "Logout",
      href: "/logout"
    }
  ]
};

const sidebarSettings = {
  COOKIE_NAME: "sidebar_state",
  COOKIE_MAX_AGE: 60 * 60 * 24 * 7, // 30 days
  WIDTH: "16rem",
  WIDTH_MOBILE: "75%",
  WIDTH_ICON: "3rem",
  KEYBOARD_SHORTCUT: "s",
  SIDE: "left" as "left" | "right",
  VARIANT: "sidebar" as "sidebar" | "floating" | "inset",
  COLLAPSIBLE: "icon" as "offcanvas" | "icon" | "none"
};
const sidebarRoutes = [
  // {
  //   title: "Home",
  //   path: "/",
  //   icon: <HomeIcon className="h-4 w-4" />
  // },
  {
    title: "Dashboard",
    path: "/dashboard",
    icon: <LayoutDashboard className="h-4 w-4" />
  },
  {
    title: "Settings",
    path: "/settings",
    icon: <CogIcon className="h-4 w-4" />
  }
  // {
  //   title: "About",
  //   path: "/about",
  //   icon: <InfoIcon className="h-4 w-4" />
  // }
];

export const globalConfig = {
  storage,
  sidebarRoutes,
  sidebarSettings,
  sidebarUserSettings,
  devSettings
};
