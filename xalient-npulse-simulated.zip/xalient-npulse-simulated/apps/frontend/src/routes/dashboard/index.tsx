import { DataTable } from "@/components/table";
import { useBreadcrumbs } from "@/hooks/use-breadcrumbs";
import { api } from "@/lib/api";
import { useQuery } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import type { PaginationState, SortingState } from "@tanstack/react-table";
import React, { useEffect } from "react";
import DeviceSeverityMap from "./components/DeviceSeverityMap";

export const Route = createFileRoute("/dashboard/")({
  component: RouteComponent
});

function RouteComponent() {
  useBreadcrumbs({
    type: "set",
    breadcrumbs: [
      {
        title: "Dashboard",
        href: "/dashboard"
      }
    ]
  });

  // TODO:Move to local storage
  const [sorting, setSorting] = React.useState<SortingState>([{ id: "site_name", desc: true }]);
  const [paginationFilters, setPaginationFilters] = React.useState<PaginationState>({ pageIndex: 0, pageSize: 10 });
  const [searchBy, setSearchBy] = React.useState<string>("");
  const {
    data: tableData,
    refetch: refetchTableData,
    isFetching: isFetchingDevices,
    isPending: isPendingDevices
  } = useQuery({
    // eslint-disable-next-line @tanstack/query/exhaustive-deps
    queryKey: ["dashboard"],
    enabled: false,
    queryFn: async () =>
      (
        await api.device.$get({
          query: {
            sortField: sorting[0].id,
            sortDirection: sorting[0].desc ? "desc" : "asc",
            searchBy
          }
        })
      ).json()
  });

  const { data: stats } = useQuery({
    queryKey: ["dashboard-stats"],
    queryFn: async () => (await api.deviceStats.$get()).json()
  });

  useEffect(() => {
    refetchTableData();
  }, [sorting, searchBy, refetchTableData]);

  const isDeviceDataLoading = isPendingDevices || (isFetchingDevices && !tableData);
  const totalDevices = stats?.totalDevices ?? 0;

  return (
    <div className="p-4">
      <div className="flex flex-1 flex-col">
        <div className="@container/main flex flex-1 flex-col gap-2">
          <div className="flex flex-col gap-4 py-4 md:gap-6 md:py-6">
            <div className="px-4 lg:px-6">
              <div className="rounded-2xl border bg-white p-6 dark:border-neutral-800 dark:bg-neutral-900">
                <DeviceSeverityMap devices={tableData?.data} isLoading={isDeviceDataLoading} />
              </div>
            </div>
            <div className="px-4 lg:px-6">
              <div className="rounded-2xl border bg-white p-4 dark:border-neutral-800 dark:bg-neutral-900">
                <DataTable
                  data={tableData?.data ?? []}
                  sorting={sorting}
                  paginationFilters={paginationFilters}
                  setSorting={setSorting}
                  setPaginationFilters={setPaginationFilters}
                  setSearchBy={setSearchBy}
                  searchBy={searchBy}
                  total={totalDevices}
                  tableName="dashboard"
                  isLoading={isDeviceDataLoading}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
