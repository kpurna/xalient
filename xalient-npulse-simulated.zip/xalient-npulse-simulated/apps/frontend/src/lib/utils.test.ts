import { getInitials } from "./utils";

describe("getInitials", () => {
  it("returns the first letter for a single name", () => {
    expect(getInitials("Alice")).toBe("A");
  });

  it("returns the initials for a full name", () => {
    expect(getInitials("Alice Smith")).toBe("AS");
    expect(getInitials("John Doe")).toBe("JD");
  });

  it("handles names with multiple spaces", () => {
    expect(getInitials("  Alice   Smith  ")).toBe("AS");
  });

  it("handles empty string", () => {
    expect(getInitials("")).toBe("");
  });

  it("handles multiple names", () => {
    expect(getInitials("Alice Bob Smith")).toBe("AS");
    expect(getInitials("John Paul Doe")).toBe("JD");
  });

  it("handles hyphenated names", () => {
    expect(getInitials("Anne-Marie Johnson")).toBe("AJ");
    expect(getInitials("Mary-Jane Smith")).toBe("MS");
  });
});
