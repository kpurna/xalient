import { Badge } from "@/components/ui/badge";
import { Card, CardAction, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { useMemo } from "react";
import type { SectionCardTypes } from "./types";

// An alert is "active" if clear is 0 or null (not yet cleared)
const isActive = (clear: number | null): boolean => !clear || clear === 0;

export function SectionCards({ alerts }: SectionCardTypes) {
  const stats = useMemo(() => {
    const alertList = alerts ?? [];

    const activeAlerts = alertList.filter((a) => isActive(a.clear));
    const devicesWithActiveAlerts = new Set(activeAlerts.map((a) => a.device_name).filter(Boolean));

    const severityTotals: Record<string, number> = {};
    for (const alert of activeAlerts) {
      const key = (alert.severity ?? "unknown").toLowerCase();
      severityTotals[key] = (severityTotals[key] ?? 0) + 1;
    }

    return {
      totalAlerts: alertList.length,
      activeAlerts: activeAlerts.length,
      devicesImpacted: devicesWithActiveAlerts.size,
      severityCounts: severityTotals
    };
  }, [alerts]);

  const emergencyCount = stats.severityCounts.emergency ?? 0;
  const highCount = stats.severityCounts.high ?? 0;
  const mediumCount = stats.severityCounts.medium ?? 0;
  const lowCount = stats.severityCounts.low ?? 0;

  return (
    <div className="grid grid-cols-1 gap-4 px-4 lg:px-6 @xl/main:grid-cols-2 @5xl/main:grid-cols-4">
      <Card className="from-primary/5 to-card dark:from-card-dark/50 dark:to-card-dark/80 @container/card overflow-hidden rounded-2xl bg-gradient-to-t shadow-xs">
        <CardHeader>
          <CardDescription>Active alerts</CardDescription>
          <CardTitle className="text-2xl font-semibold tabular-nums @[250px]/card:text-3xl">
            {stats.activeAlerts}
          </CardTitle>
          <CardAction>
            <Badge variant="outline">{stats.totalAlerts} total</Badge>
          </CardAction>
        </CardHeader>
        <CardFooter className="flex-col items-start gap-1.5 text-sm">
          <div className="line-clamp-1 flex gap-2 font-medium">
            {stats.activeAlerts} of {stats.totalAlerts} alerts are currently active
          </div>
          <div className="text-muted-foreground">Cleared: {stats.totalAlerts - stats.activeAlerts}</div>
        </CardFooter>
      </Card>

      <Card className="from-primary/5 to-card dark:from-card-dark/50 dark:to-card-dark/80 @container/card overflow-hidden rounded-2xl bg-gradient-to-t shadow-xs">
        <CardHeader>
          <CardDescription>Devices impacted</CardDescription>
          <CardTitle className="text-2xl font-semibold tabular-nums @[250px]/card:text-3xl">
            {stats.devicesImpacted}
          </CardTitle>
        </CardHeader>
        <CardFooter className="flex-col items-start gap-1.5 text-sm">
          <div className="line-clamp-1 flex gap-2 font-medium">
            {stats.devicesImpacted} device(s) with active alerts
          </div>
          <div className="text-muted-foreground">-</div>
        </CardFooter>
      </Card>

      <Card className="from-primary/5 to-card dark:from-card-dark/50 dark:to-card-dark/80 @container/card overflow-hidden rounded-2xl bg-gradient-to-t shadow-xs">
        <CardHeader>
          <CardDescription>Emergency &amp; High severity</CardDescription>
          <CardTitle className="text-2xl font-semibold tabular-nums @[250px]/card:text-3xl">
            {emergencyCount + highCount}
          </CardTitle>
          <CardAction>
            <Badge variant="outline">{emergencyCount} emergency</Badge>
          </CardAction>
        </CardHeader>
        <CardFooter className="flex-col items-start gap-1.5 text-sm">
          <div className="line-clamp-1 flex gap-2 font-medium">
            {emergencyCount} emergency · {highCount} high
          </div>
          <div className="text-muted-foreground">Requires immediate attention</div>
        </CardFooter>
      </Card>

      <Card className="from-primary/5 to-card dark:from-card-dark/50 dark:to-card-dark/80 @container/card overflow-hidden rounded-2xl bg-gradient-to-t shadow-xs">
        <CardHeader>
          <CardDescription>Medium &amp; Low severity</CardDescription>
          <CardTitle className="text-2xl font-semibold tabular-nums @[250px]/card:text-3xl">
            {mediumCount + lowCount}
          </CardTitle>
          <CardAction>
            <Badge variant="outline">{mediumCount} medium</Badge>
          </CardAction>
        </CardHeader>
        <CardFooter className="flex-col items-start gap-1.5 text-sm">
          <div className="line-clamp-1 flex gap-2 font-medium">
            {mediumCount} medium · {lowCount} low
          </div>
          <div className="text-muted-foreground">Lower priority active alerts</div>
        </CardFooter>
      </Card>
    </div>
  );
}
