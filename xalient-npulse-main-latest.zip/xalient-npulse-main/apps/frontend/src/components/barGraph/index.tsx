import Chart from "@/components/chart";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { useMemo, type FC, type ReactElement } from "react";
import type { GraphTypes } from "./types";

const Graph: FC<GraphTypes> = ({ data, timerangePeriod, setTimerangePeriod }): ReactElement => {
  const aggregated = useMemo(() => {
    const acc: Record<number, { minor: number; major: number; critical: number; date: number }> = {};

    for (const row of data ?? []) {
      const rawAlarmRaised = row.alarmraisedtime;
      const normalizedAlarmRaised = typeof rawAlarmRaised === "string" ? rawAlarmRaised.trim() : rawAlarmRaised;

      let d = normalizedAlarmRaised ? new Date(normalizedAlarmRaised) : null;
      if (d && Number.isNaN(d?.getTime())) {
        d = new Date();
      }

      if (d) {
        d.setHours(0, 0, 0, 0);
        const ts = d.getTime();

        if (!acc[ts]) {
          acc[ts] = { date: ts, minor: 0, major: 0, critical: 0 };
        }

        if (row.perceivedseverity === "MINOR") acc[ts].minor += 1;
        if (row.perceivedseverity === "MAJOR") acc[ts].major += 1;
        if (row.perceivedseverity === "CRITICAL") acc[ts].critical += 1;
      }
    }

    return Object.values(acc).sort((a, b) => a.date - b.date);
  }, [data]);

  return (
    <div>
      <div className="flex w-full items-center justify-between p-4">
        <h2 className="text-lg">Alarms</h2>
        <ToggleGroup
          type="single"
          value={timerangePeriod}
          onValueChange={(v) => v && setTimerangePeriod(v)}
          variant="outline"
          className="*:data-[slot=toggle-group-item]:!px-4 @[767px]/card:flex"
        >
          <ToggleGroupItem value="90d">Last 3 months</ToggleGroupItem>
          <ToggleGroupItem value="30d">Last 30 days</ToggleGroupItem>
          <ToggleGroupItem value="7d">Last 7 days</ToggleGroupItem>
        </ToggleGroup>
      </div>

      <Chart
        data={
          aggregated
            ? (Object.entries(aggregated) as [string, Record<string, number>][]).map(([first, severities]) => ({
                date: Number(first),
                ...severities
              }))
            : []
        }
        series={[
          {
            xKey: "date",
            yKey: "minor",
            yName: "Minor",
            type: "bar",
            stacked: true,
            fill: "#4caf50",
            stroke: "#4caf50"
          },
          {
            xKey: "date",
            yKey: "major",
            yName: "Major",
            type: "bar",
            stacked: true,
            fill: "#ff9800",
            stroke: "#ff9800"
          },
          {
            xKey: "date",
            yKey: "critical",
            yName: "Critical",
            type: "bar",
            stacked: true,
            fill: "#f44336",
            stroke: "#f44336"
          }
        ]}
        axes={[
          {
            type: "time",
            position: "bottom",
            title: { text: "Date" }
          },
          {
            type: "number",
            position: "left",
            title: { text: "Number of alarms" }
          }
        ]}
      />
    </div>
  );
};

export default Graph;
