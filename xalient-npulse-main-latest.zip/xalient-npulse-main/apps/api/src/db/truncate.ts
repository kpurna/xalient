import { drizzle } from "drizzle-orm/node-postgres";
import { reset } from "drizzle-seed";
import env from "../env.js";
import { alarms } from "./schema/alarms.js";
import { alerts } from "./schema/alerts.js";
import { changes } from "./schema/changes.js";
import { interfaces } from "./schema/interfaces.js";
import { inventory } from "./schema/inventory.js";
import { smarts_discovery_status_rgt } from "./schema/smarts_discovery_status_rgt.js";

async function truncate() {
  const db = drizzle(env.DATABASE_URL);

  // Simulated alerts table (device_name / severity shape)
  await reset(db, { alerts });

  // Real alarms table (BT alarm fields from data-collector)
  await reset(db, { alarms });

  // All other tables
  await reset(db, { changes, smarts_discovery_status_rgt, interfaces, inventory });

  console.log("All tables truncated");
}

truncate();
