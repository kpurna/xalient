import { bigint, pgTable, serial, text, timestamp, varchar } from "drizzle-orm/pg-core";
import { createSelectSchema } from "drizzle-zod";

export const changes = pgTable("changes", {
  id: serial().primaryKey().unique(),
  change_number: varchar({ length: 255 }),
  assignment_group: varchar({ length: 255 }),
  category: varchar({ length: 255 }),
  short_description: text(),
  assigned_to: varchar({ length: 255 }),
  planned_start_date: bigint({ mode: "number" }),
  planned_end_date: bigint({ mode: "number" }),
  state: varchar({ length: 255 }),
  close_code: varchar({ length: 255 }),
  updated_at: timestamp(),
  created_at: timestamp().defaultNow().notNull(),
  deleted_at: timestamp()
});

export const changeSelectSchema = createSelectSchema(changes);
