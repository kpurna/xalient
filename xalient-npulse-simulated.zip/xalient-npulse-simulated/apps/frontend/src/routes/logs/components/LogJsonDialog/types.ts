import type { LogEntry } from "../../types";

export type LogJsonDialogProps = {
  log: LogEntry | null;
  parsed: unknown | null;
  onClose: () => void;
};
