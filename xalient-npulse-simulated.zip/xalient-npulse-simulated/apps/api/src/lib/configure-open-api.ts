import { Scalar } from "@scalar/hono-api-reference";

import type { AppOpenAPI } from "./types.js";

export default function configureOpenAPI(app: AppOpenAPI) {
  app.doc("/api/doc", {
    openapi: "3.0.0",
    info: {
      version: "1.0.0",
      title: " API"
    }
  });

  app.get(
    "/api/docs",
    Scalar({
      url: "/api/doc",
      theme: "default",
      layout: "classic",
      defaultHttpClient: {
        targetKey: "js",
        clientKey: "fetch"
      }
    })
  );
}
