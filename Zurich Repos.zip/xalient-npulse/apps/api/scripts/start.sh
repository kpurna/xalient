#!/bin/sh
set -e

cd /app


echo "Drop tables..."
pnpm db:drop-tables

if [ -f dist/src/db/migrate.js ]; then
  echo "Running database table drop..."
  node dist/src/db/drop-all-tables.js
fi

echo "Generating Drizzle migrations..."
pnpm db:generate

if [ -f dist/src/db/migrate.js ]; then
  echo "Running database migrations..."
  node dist/src/db/migrate.js
fi

echo "Pushing schema changes..."
pnpm db:push

if [ "${RESET_DATA_ON_START:-true}" = "true" ] && [ -f dist/src/db/truncate.js ]; then
  echo "Resetting database tables..."
  node dist/src/db/truncate.js
fi

echo "Seeding database..."
pnpm db:seed --alerts=10 --changes=10 --interfaces=10 --inventory=10 --smarts_discovery_status_rgt=10 --settings=3

echo "Starting API server..."
exec node dist/src/index.js
