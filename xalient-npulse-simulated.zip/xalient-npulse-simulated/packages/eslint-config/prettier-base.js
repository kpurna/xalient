/**
 * @see https://prettier.io/docs/configuration
 * @type {import("prettier").Config}
 */
const config = {
  singleQuote: false,
  trailingComma: "none",
  printWidth: 120,
  tabWidth: 2,
  endOfLine: "auto"
};

export default config;
