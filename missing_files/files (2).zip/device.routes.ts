import { createRoute, z } from "@hono/zod-openapi";
import { ReasonPhrases, StatusCodes } from "http-status-codes";
import { alarmSelectSchema } from "../../db/schema/alarms.js";
import { changeSelectSchema } from "../../db/schema/changes.js";
import { interfaceSelectSchema } from "../../db/schema/interfaces.js";
import { inventorySelectSchema } from "../../db/schema/inventory.js";

export const deviceData = createRoute({
  path: "api/device",
  method: "get",
  tags: ["Device"],
  request: {
    query: z.object({
      sortField: z.string(),
      sortDirection: z.enum(["asc", "desc"]),
      searchBy: z.string()
    })
  },
  responses: {
    [StatusCodes.OK.valueOf()]: {
      description: ReasonPhrases.OK,
      content: {
        "application/json": {
          schema: z.object({
            data: z.array(
              z.object({
                country: z.string(),
                site_name: z.string(),
                bfg_hostname: z.string(),
                number_of_alerts: z.number(),
                assigned_to: z.string(),
                severity: z.number()
              })
            )
          })
        }
      }
    }
  }
});

export const stats = createRoute({
  path: "api/deviceStats",
  method: "get",
  tags: ["Device"],
  request: {},
  responses: {
    [StatusCodes.OK.valueOf()]: {
      description: ReasonPhrases.OK,
      content: {
        "application/json": {
          schema: z.object({
            totalDevices: z.number(),
            deviceWithAlerts: z.number(),
            totalSites: z.number(),
            totalSuccessfullyDiscoveredDevices: z.number()
          })
        }
      }
    }
  }
});

export const deviceAlerts = createRoute({
  path: "api/deviceAlerts",
  method: "get",
  tags: ["Device"],
  request: {
    query: z.object({
      // deviceId: z.string(),
      sortField: z.string(),
      sortDirection: z.enum(["asc", "desc"]),
      searchBy: z.string()
    })
  },
  responses: {
    [StatusCodes.OK.valueOf()]: {
      description: ReasonPhrases.OK,
      content: {
        "application/json": {
          schema: z.object({
            data: z.array(alarmSelectSchema)
          })
        }
      }
    }
  }
});

export const deviceInterfaces = createRoute({
  path: "api/deviceInterfaces",
  method: "get",
  tags: ["Device"],
  request: {
    query: z.object({
      deviceId: z.string()
    })
  },
  responses: {
    [StatusCodes.OK.valueOf()]: {
      description: ReasonPhrases.OK,
      content: {
        "application/json": {
          schema: z.object({
            data: z.array(interfaceSelectSchema)
          })
        }
      }
    }
  }
});

export const alerts = createRoute({
  path: "api/alerts",
  method: "get",
  tags: ["Alerts"],
  request: {
    query: z.object({
      startTime: z.coerce.number(),
      endTime: z.coerce.number()
    })
  },
  responses: {
    [StatusCodes.OK.valueOf()]: {
      description: ReasonPhrases.OK,
      content: {
        "application/json": {
          schema: z.object({
            data: z.array(alarmSelectSchema)
          })
        }
      }
    }
  }
});

export const deviceChanges = createRoute({
  path: "api/deviceChanges",
  method: "get",
  tags: ["Device"],
  request: {
    query: z.object({
      sortField: z.string(),
      sortDirection: z.enum(["asc", "desc"]),
      searchBy: z.string()
    })
  },
  responses: {
    [StatusCodes.OK.valueOf()]: {
      description: ReasonPhrases.OK,
      content: {
        "application/json": {
          schema: z.object({
            data: z.array(changeSelectSchema)
          })
        }
      }
    }
  }
});

export const deviceDetails = createRoute({
  path: "api/deviceDetails",
  method: "get",
  tags: ["Device"],
  request: {
    query: z.object({
      deviceId: z.string()
    })
  },
  responses: {
    [StatusCodes.OK.valueOf()]: {
      description: ReasonPhrases.OK,
      content: {
        "application/json": {
          schema: z.object({
            data: z.array(inventorySelectSchema)
          })
        }
      }
    }
  }
});

export type ListRoute = typeof deviceData;
export type AlertRoute = typeof alerts;
export type StatRoute = typeof stats;
export type DeviceChange = typeof deviceChanges;
export type DeviceAlert = typeof deviceAlerts;
export type DeviceInterface = typeof deviceInterfaces;
export type DeviceDetails = typeof deviceDetails;
