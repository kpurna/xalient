import { createToast } from "@/components/toast/helper";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import type { CheckedState } from "@radix-ui/react-checkbox";
import { Label } from "@radix-ui/react-dropdown-menu";
import { useCallback, useEffect, useMemo, useState } from "react";
import type { AddDeviceDialogProps } from "./types";

const INITIAL_COLLECTORS_STATE = {
  netflow: false,
  snmp: false,
  sys_logs: false
};

export default function AddDeviceDialog({ open, isSubmitting, onOpenChange, onSubmit }: AddDeviceDialogProps) {
  const [hostname, setHostname] = useState("");
  const [collectors, setCollectors] = useState(INITIAL_COLLECTORS_STATE);

  const resetForm = useCallback(() => {
    setHostname("");
    setCollectors(INITIAL_COLLECTORS_STATE);
  }, []);

  useEffect(() => {
    if (!open) {
      resetForm();
    }
  }, [open, resetForm]);

  const isSaveDisabled = useMemo(() => isSubmitting || !hostname.trim(), [hostname, isSubmitting]);

  const updateCollectors = (field: "netflow" | "snmp" | "sys_logs") => (value: CheckedState) => {
    setCollectors((prev) => ({
      ...prev,
      [field]: value === true
    }));
  };

  const handleSubmit = async () => {
    if (!hostname) {
      createToast({
        title: "Hostname required",
        description: "Enter a hostname before adding a device.",
        type: "warning"
      });
      return;
    }

    await onSubmit({
      device_name: hostname,
      ip: "",
      netflow: collectors.netflow,
      snmp: collectors.snmp,
      sys_logs: collectors.sys_logs
    });
    onOpenChange(false);
    resetForm();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Add device</DialogTitle>
          <DialogDescription>Provide the hostname to begin monitoring this device.</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label>Hostname</Label>
            <Input
              id="manual-device-hostname"
              value={hostname}
              onChange={(event) => setHostname(event.target.value)}
              placeholder="e.g. edge-router-01"
              disabled={isSubmitting}
            />
          </div>

          <div className="space-y-2">
            <span className="text-sm font-medium">Data collection</span>
            <div className="flex flex-col gap-2">
              <label className="flex items-center gap-2 text-sm">
                <Checkbox
                  id="manual-device-netflow"
                  checked={collectors.netflow}
                  onCheckedChange={updateCollectors("netflow")}
                  disabled={isSubmitting}
                />
                NetFlow
              </label>
              <label className="flex items-center gap-2 text-sm">
                <Checkbox
                  id="manual-device-snmp"
                  checked={collectors.snmp}
                  onCheckedChange={updateCollectors("snmp")}
                  disabled={isSubmitting}
                />
                SNMP
              </label>
              <label className="flex items-center gap-2 text-sm">
                <Checkbox
                  id="manual-device-syslog"
                  checked={collectors.sys_logs}
                  onCheckedChange={updateCollectors("sys_logs")}
                  disabled={isSubmitting}
                />
                Syslog
              </label>
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={isSubmitting}>
            Cancel
          </Button>
          <Button onClick={() => void handleSubmit()} disabled={isSaveDisabled}>
            {isSubmitting ? "Adding..." : "Add device"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
