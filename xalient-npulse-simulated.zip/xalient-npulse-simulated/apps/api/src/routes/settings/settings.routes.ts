import { createRoute, z } from "@hono/zod-openapi";
import { ReasonPhrases, StatusCodes } from "http-status-codes";

export const deviceSettings = createRoute({
  path: "api/settings",
  method: "get",
  tags: ["Settings"],
  request: {
    query: z.object({
      sortField: z.string(),
      sortDirection: z.enum(["asc", "desc"]),
      searchBy: z.string()
    })
  },
  responses: {
    [StatusCodes.OK.valueOf()]: {
      description: ReasonPhrases.OK,
      content: {
        "application/json": {
          schema: z.object({
            data: z.array(
              z.object({
                id: z.number(),
                device_name: z.string(),
                ip: z.string(),
                snmp: z.boolean(),
                netflow: z.boolean(),
                sys_logs: z.boolean(),
                is_monitored: z.boolean()
              })
            )
          })
        }
      }
    }
  }
});

export const upsertDeviceSetting = createRoute({
  path: "api/settings",
  method: "post",
  tags: ["Settings"],
  request: {
    body: {
      content: {
        "application/json": {
          schema: z.object({
            id: z.number().int().nonnegative(),
            device_name: z.string().min(1, "Device name is required"),
            ip: z.string().optional().default(""),
            netflow: z.boolean(),
            snmp: z.boolean(),
            sys_logs: z.boolean(),
            is_monitored: z.boolean()
          })
        }
      }
    }
  },
  responses: {
    [StatusCodes.OK.valueOf()]: {
      description: ReasonPhrases.OK,
      content: {
        "application/json": {
          schema: z.object({
            message: z.string(),
            data: z.object({
              id: z.number(),
              device_name: z.string(),
              ip: z.string(),
              netflow: z.boolean(),
              snmp: z.boolean(),
              sys_logs: z.boolean(),
              is_monitored: z.boolean()
            })
          })
        }
      }
    },
    [StatusCodes.CREATED.valueOf()]: {
      description: ReasonPhrases.CREATED,
      content: {
        "application/json": {
          schema: z.object({
            message: z.string(),
            data: z.object({
              id: z.number(),
              device_name: z.string(),
              ip: z.string(),
              netflow: z.boolean(),
              snmp: z.boolean(),
              sys_logs: z.boolean(),
              is_monitored: z.boolean()
            })
          })
        }
      }
    }
  }
});

export type SettingList = typeof deviceSettings;
export type SettingUpsert = typeof upsertDeviceSetting;
