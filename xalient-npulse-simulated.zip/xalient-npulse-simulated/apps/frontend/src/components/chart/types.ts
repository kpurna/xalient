import type { AgCartesianAxisOptions, AgCartesianSeriesOptions } from "ag-charts-enterprise";

export interface ChartTypes {
  series: AgCartesianSeriesOptions[];
  data: {
    [key: string]: string | number;
  }[];
  axes: AgCartesianAxisOptions[];
}
