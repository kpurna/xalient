// @ts-nocheck

import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { formatDate } from "@/lib/utils";
import { Link } from "@tanstack/react-router";
import type { ColumnDef, SortingState } from "@tanstack/react-table";
import { ArrowUpDown, LinkIcon, MoreHorizontal } from "lucide-react";
import type { Dispatch, SetStateAction } from "react";
import { Button } from "../ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "../ui/dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "../ui/dropdown-menu";
import { SEVERITY, SEVERITY_COLORS } from "./helper";
import type { Change, DeviceAlert, DeviceData } from "./types";

const VISIBLE_DEVICE_ALERT_COLUMNS = [
  "id",
  "btcustomer",
  "btsite",
  "perceivedseverity",
  "alarmraisedtime",
  "state",
  "alarmtype",
  "probablecause"
] as const;

const visibleDeviceAlertColumnSet = new Set(VISIBLE_DEVICE_ALERT_COLUMNS);

const COLUMN_LABELS: Record<string, string> = {
  btsite: "Site",
  btelementclass: "BT Element Class",
  incidentid: "Incident Id",
  btcustomer: "Customer",
  perceivedseverity: "Severity",
  alarmraisedtime: "Raised",
  alarmclearedtime: "Cleared",
  alarmreportingtime: "Reporting",
  alarmchangedtime: "Changed",
  alarmtype: "Alarm Type",
  alarmdetails: "Alarm Details",
  alarmedobjecttype: "Object Type",
  alarmedobject: "Alarmed Object",
  correlatedalarm: "Correlated Alarm",
  affectedservice: "Affected Service",
  parentalarm: "Parent Alarm",
  btsourcesystem: "Source System",
  probablecause: "Probable Cause",
  specificproblem: "Specific Problem",
  isrootcause: "Root Cause",
  state: "State",
  ackstate: "Ack State",
  ackuserid: "Ack User",
  acksystemid: "Ack System",
  externalalarmid: "External Alarm ID",
  btinstancename: "Instance Name",
  btcount: "Count",
  btuserdefined: "User Defined",
  btaffectedcircuit: "Affected Circuit",
  btservername: "Server Name",
  sourcesystemid: "Source System ID",
  plannedoutageindicator: "Planned Outage Indicator"
};

const formatDetailValue = (value: unknown) => {
  if (value === null || value === undefined) return "-";
  if (typeof value === "object") {
    try {
      return JSON.stringify(value, null, 2);
    } catch {
      return String(value);
    }
  }

  return String(value);
};

const formatDetailLabel = (key: string) => {
  if (COLUMN_LABELS[key]) {
    return COLUMN_LABELS[key];
  }

  return key;
};

export const deviceAlertColumns = ({
  setSorting
}: {
  setSorting: Dispatch<SetStateAction<SortingState>>;
}): ColumnDef<DeviceAlert>[] => {
  return [
    {
      accessorKey: "btcustomer",
      header: ({ column }) => (
        <Button
          variant="ghost"
          onClick={() => setSorting([{ id: "btcustomer", desc: column.getIsSorted() === "asc" }])}
        >
          Customer <ArrowUpDown />
        </Button>
      ),
      cell: ({ row }) => <div>{row.getValue("btcustomer")}</div>
    },
    {
      accessorKey: "btsite",
      header: ({ column }) => (
        <Button variant="ghost" onClick={() => setSorting([{ id: "btsite", desc: column.getIsSorted() === "asc" }])}>
          Site <ArrowUpDown />
        </Button>
      ),
      cell: ({ row }) => {
        return (
          <div className="max-w-[300px] truncate">
            <Tooltip>
              <TooltipTrigger asChild>
                <div className="max-w-[300px] truncate">{row.getValue("btsite")}</div>
              </TooltipTrigger>
              <TooltipContent>{row.getValue("btsite")}</TooltipContent>
            </Tooltip>
          </div>
        );
      }
    },
    {
      accessorKey: "perceivedseverity",
      header: ({ column }) => (
        <Button
          variant="ghost"
          onClick={() => setSorting([{ id: "perceivedseverity", desc: column.getIsSorted() === "asc" }])}
        >
          Severity <ArrowUpDown />
        </Button>
      ),
      cell: ({ row }) => {
        const severity = (row.getValue("perceivedseverity") as string)?.toLowerCase();
        return (
          <span
            className={`rounded-full px-2 py-1 text-xs font-medium capitalize ${
              SEVERITY_COLORS[severity] ?? "bg-gray-100 text-gray-800"
            }`}
          >
            {severity ?? "unknown"}
          </span>
        );
      }
    },
    {
      accessorKey: "alarmraisedtime",
      header: ({ column }) => (
        <Button
          variant="ghost"
          onClick={() => setSorting([{ id: "alarmraisedtime", desc: column.getIsSorted() === "asc" }])}
        >
          Raised <ArrowUpDown />
        </Button>
      ),
      cell: ({ row }) => <div>{formatDate(row.getValue("alarmraisedtime"))}</div>
    },
    {
      accessorKey: "alarmclearedtime",
      header: ({ column }) => (
        <Button
          variant="ghost"
          onClick={() => setSorting([{ id: "alarmclearedtime", desc: column.getIsSorted() === "asc" }])}
        >
          Cleared <ArrowUpDown />
        </Button>
      ),
      cell: ({ row }) => <div>{formatDate(row.getValue("alarmclearedtime"))}</div>
    },
    {
      accessorKey: "state",
      header: ({ column }) => (
        <Button variant="ghost" onClick={() => setSorting([{ id: "state", desc: column.getIsSorted() === "asc" }])}>
          State <ArrowUpDown />
        </Button>
      ),
      cell: ({ row }) => <div className="capitalize">{row.getValue("state")}</div>
    },
    {
      accessorKey: "alarmtype",
      header: ({ column }) => (
        <Button variant="ghost" onClick={() => setSorting([{ id: "alarmtype", desc: column.getIsSorted() === "asc" }])}>
          Type <ArrowUpDown />
        </Button>
      ),
      cell: ({ row }) => <div className="capitalize">{row.getValue("alarmtype")}</div>
    },
    {
      accessorKey: "probablecause",
      header: ({ column }) => (
        <Button
          variant="ghost"
          onClick={() => setSorting([{ id: "probablecause", desc: column.getIsSorted() === "asc" }])}
        >
          Probable Cause <ArrowUpDown />
        </Button>
      ),
      cell: ({ row }) => <div className="capitalize">{row.getValue("probablecause")}</div>
    },
    {
      id: "details",
      header: "Details",
      enableSorting: false,
      cell: ({ row }) => {
        const entries = Object.entries(row.original ?? {}).filter(([key]) => !visibleDeviceAlertColumnSet.has(key));
        const severity = (row.original?.perceivedseverity as string)?.toLowerCase();
        const severityClass = severity ? (SEVERITY_COLORS[severity] ?? "bg-gray-100 text-gray-800") : "";

        const summaryLine = [row.original?.externalalarmid, row.original?.btcustomer, row.original?.btsite]
          .filter(Boolean)
          .join(" | ");

        return (
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm">
                View all
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-3xl">
              <DialogHeader className="gap-2">
                <div className="flex flex-wrap items-center gap-3">
                  <DialogTitle className="text-xl">Alarm details</DialogTitle>
                  {severity ? (
                    <span className={`rounded-full px-3 py-1 text-xs font-semibold capitalize ${severityClass}`}>
                      {severity}
                    </span>
                  ) : null}
                </div>
                {summaryLine ? <p className="text-sm text-neutral-500">{summaryLine}</p> : null}
              </DialogHeader>
              <div className="max-h-[60vh] overflow-y-auto">
                {entries.length === 0 ? (
                  <p className="text-sm text-neutral-500">No additional data available.</p>
                ) : (
                  <table className="w-full table-fixed overflow-hidden rounded border border-neutral-200 bg-neutral-50 text-sm dark:border-neutral-800 dark:bg-neutral-900">
                    <tbody>
                      {entries.map(([key, value], index) => {
                        const formattedValue = formatDetailValue(value);
                        const isObjectValue = typeof value === "object" && value !== null;
                        return (
                          <tr
                            key={key}
                            className={`border-neutral-100 dark:border-neutral-800 ${index === 0 ? "border-t" : ""} border-b`}
                          >
                            <th className="w-40 bg-neutral-100 px-4 py-3 text-left align-top text-xs font-semibold tracking-wide text-neutral-600 dark:bg-neutral-900/70 dark:text-neutral-300">
                              {formatDetailLabel(key)}
                            </th>
                            <td className="bg-neutral-50 px-4 py-3 text-neutral-900 dark:bg-neutral-900/40 dark:text-neutral-50">
                              {isObjectValue ? (
                                <pre className="rounded bg-neutral-50 p-3 text-xs whitespace-pre-wrap text-neutral-800 dark:bg-neutral-900 dark:text-neutral-100">
                                  {formattedValue}
                                </pre>
                              ) : (
                                formattedValue
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                )}
              </div>
            </DialogContent>
          </Dialog>
        );
      }
    }
  ];
};

export const changeColumns = ({
  setSorting
}: {
  setSorting: Dispatch<SetStateAction<SortingState>>;
}): ColumnDef<Change>[] => {
  return [
    {
      accessorKey: "change_number",
      header: ({ column }) => {
        return (
          <Button
            variant="ghost"
            onClick={() => setSorting([{ id: "change_number", desc: column.getIsSorted() === "asc" }])}
          >
            Number
            <ArrowUpDown />
          </Button>
        );
      },
      cell: ({ row }) => <div className="capitalize">{row.getValue("change_number")}</div>
    },
    {
      accessorKey: "assignment_group",
      header: ({ column }) => {
        return (
          <Button
            variant="ghost"
            onClick={() => setSorting([{ id: "assignment_group", desc: column.getIsSorted() === "asc" }])}
          >
            Assignment group
            <ArrowUpDown />
          </Button>
        );
      },
      cell: ({ row }) => <div className="capitalize">{row.getValue("assignment_group")}</div>
    },
    {
      accessorKey: "category",
      header: ({ column }) => {
        return (
          <Button
            variant="ghost"
            onClick={() => setSorting([{ id: "category", desc: column.getIsSorted() === "asc" }])}
          >
            Category
            <ArrowUpDown />
          </Button>
        );
      },
      cell: ({ row }) => <div className="capitalize">{row.getValue("category")}</div>
    },
    {
      accessorKey: "short_description",
      header: ({ column }) => {
        return (
          <Button
            variant="ghost"
            onClick={() => setSorting([{ id: "short_description", desc: column.getIsSorted() === "asc" }])}
          >
            Short description
            <ArrowUpDown />
          </Button>
        );
      },
      cell: ({ row }) => <div className="capitalize">{row.getValue("short_description")}</div>
    },
    {
      accessorKey: "planned_start_date",
      header: ({ column }) => {
        return (
          <Button
            variant="ghost"
            onClick={() => setSorting([{ id: "planned_start_date", desc: column.getIsSorted() === "asc" }])}
          >
            Planned start date
            <ArrowUpDown />
          </Button>
        );
      },
      cell: ({ row }) => <div className="lowercase">{formatDate(row.getValue("planned_start_date"))}</div>
    },
    {
      accessorKey: "planned_end_date",
      header: ({ column }) => {
        return (
          <Button
            variant="ghost"
            onClick={() => setSorting([{ id: "planned_end_date", desc: column.getIsSorted() === "asc" }])}
          >
            Planned end date
            <ArrowUpDown />
          </Button>
        );
      },
      cell: ({ row }) => {
        return <div className="text-right font-medium">{formatDate(row.getValue("planned_end_date"))}</div>;
      }
    },
    {
      accessorKey: "state",
      header: ({ column }) => {
        return (
          <Button variant="ghost" onClick={() => setSorting([{ id: "state", desc: column.getIsSorted() === "asc" }])}>
            State
            <ArrowUpDown />
          </Button>
        );
      },
      cell: ({ row }) => {
        return <div className="text-right font-medium">{row.getValue("state")}</div>;
      }
    },
    {
      accessorKey: "close_code",
      header: ({ column }) => {
        return (
          <Button
            variant="ghost"
            onClick={() => setSorting([{ id: "close_code", desc: column.getIsSorted() === "asc" }])}
          >
            Close code
            <ArrowUpDown />
          </Button>
        );
      },
      cell: ({ row }) => {
        return <div className="text-right font-medium">{row.getValue("close_code")}</div>;
      }
    }
  ];
};

export const dashboardColumns = ({
  setSorting
}: {
  setSorting: Dispatch<SetStateAction<SortingState>>;
}): ColumnDef<DeviceData>[] => {
  return [
    {
      accessorKey: "bfg_hostname",
      header: ({ column }) => {
        return (
          <Button
            variant="ghost"
            onClick={() => setSorting([{ id: "bfg_hostname", desc: column.getIsSorted() === "asc" }])}
          >
            Device name
            <ArrowUpDown />
          </Button>
        );
      },
      cell: ({ row }) => {
        const deviceName = row.getValue("bfg_hostname") as string;
        const url = `/device/device/${deviceName}`;

        return (
          <Link to={url} className="flex items-center gap-1 capitalize">
            <LinkIcon className="h-2 w-2" />
            {deviceName}
          </Link>
        );
      }
    },

    {
      accessorKey: "site_name",
      header: ({ column }) => {
        return (
          <Button
            variant="ghost"
            onClick={() => setSorting([{ id: "site_name", desc: column.getIsSorted() === "asc" }])}
          >
            Site name
            <ArrowUpDown />
          </Button>
        );
      },
      cell: ({ row }) => <div className="capitalize">{row.getValue("site_name")}</div>
    },
    {
      accessorKey: "country",
      header: ({ column }) => {
        return (
          <Button variant="ghost" onClick={() => setSorting([{ id: "country", desc: column.getIsSorted() === "asc" }])}>
            Country
            <ArrowUpDown />
          </Button>
        );
      },
      cell: ({ row }) => <div className="capitalize">{row.getValue("country")}</div>
    },
    {
      accessorKey: "severity",
      header: ({ column }) => {
        return (
          <Button
            variant="ghost"
            onClick={() => setSorting([{ id: "severity", desc: column.getIsSorted() === "asc" }])}
          >
            Severity
            <ArrowUpDown className="ml-2 h-4 w-4" />
          </Button>
        );
      },
      cell: ({ row }) => {
        const severity = row.getValue("severity") as keyof typeof SEVERITY;
        return (
          <span className={`rounded-full px-2 py-1 text-xs font-medium ${SEVERITY_COLORS[severity]} `}>
            {SEVERITY[severity]}
          </span>
        );
      }
    },

    {
      accessorKey: "number_of_alerts",
      header: ({ column }) => {
        return (
          <Button
            variant="ghost"
            onClick={() => setSorting([{ id: "number_of_alerts", desc: column.getIsSorted() === "asc" }])}
          >
            Numbers of Alerts
            <ArrowUpDown />
          </Button>
        );
      },
      cell: ({ row }) => <div className="lowercase">{row.getValue("number_of_alerts")}</div>
    },
    // {
    //   accessorKey: "assigned_to",
    //   header: ({ column }) => {
    //     return (
    //       <Button
    //         variant="ghost"
    //         onClick={() => setSorting([{ id: "assigned_to", desc: column.getIsSorted() === "asc" }])}
    //       >
    //         Assigned to
    //         <ArrowUpDown />
    //       </Button>
    //     );
    // //   },
    //   cell: ({ row }) => {
    //     return (
    //       <div className="max-w-[150px] truncate font-medium">
    //         <Tooltip>
    //           <TooltipTrigger asChild>
    //             <div className="max-w-[150px] truncate font-medium">{row.getValue("assigned_to")}</div>
    //           </TooltipTrigger>
    //           <TooltipContent>{row.getValue("assigned_to")}</TooltipContent>
    //         </Tooltip>
    //       </div>
    //     );
    //   }
    // },

    {
      id: "actions",
      enableHiding: false,
      cell: () => {
        return (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="h-8 w-8 p-0">
                <span className="sr-only">Open menu</span>
                <MoreHorizontal />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem asChild>
                <Link to="/changes" className="block w-full">
                  View changes
                </Link>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        );
      }
    }
  ];
};
