import type { LogEntry } from "./types";

export const MOCK_LOGS: LogEntry[] = [
  {
    time: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
    tag: "device.monitor",
    message: "Interface Gi1/0/24 transitioned to up state"
  },
  {
    time: new Date(Date.now() - 12 * 60 * 1000).toISOString(),
    tag: "device.monitor",
    message: "Detected high CPU utilization (92%)"
  },
  {
    time: new Date(Date.now() - 9 * 60 * 1000).toISOString(),
    tag: "device.firewall",
    message: "Inbound connection blocked for policy VPN-DENY"
  },
  {
    time: new Date(Date.now() - 6 * 60 * 1000).toISOString(),
    tag: "device.monitor",
    message: "BGP neighbor 10.0.12.4 went down (Hold timer expired)"
  },
  {
    time: new Date(Date.now() - 3 * 60 * 1000).toISOString(),
    tag: "device.monitor",
    message: "Cleared high CPU utilization alarm"
  },
  {
    time: new Date(Date.now() - 2 * 60 * 1000).toISOString(),
    tag: "device.audit",
    message: JSON.stringify({
      action: "login",
      user: "svc-backup",
      status: "success",
      sourceIp: "10.2.14.8"
    })
  },
  {
    time: new Date(Date.now() - 90 * 1000).toISOString(),
    tag: "device.sensor",
    message: JSON.stringify({
      sensorId: "temp-01",
      metric: "temperature",
      value: 79.4,
      unit: "F",
      location: "core-router-01/slot2"
    })
  },
  {
    time: new Date(Date.now() - 60 * 1000).toISOString(),
    tag: "device.monitor",
    message: JSON.stringify({
      event: "interface-error",
      interface: "Gi1/0/12",
      counters: { crc: 12, drops: 4 },
      window: "30s"
    })
  },
  {
    time: new Date(Date.now() - 30 * 1000).toISOString(),
    tag: "device.firewall",
    message: JSON.stringify({
      event: "connection",
      src: { ip: "203.0.113.24", port: 49432 },
      dst: { ip: "192.0.2.10", port: 22 },
      action: "blocked",
      rule: "ssh_external_deny"
    })
  }
];
