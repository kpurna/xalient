/// <reference types="vite/client" />
// interface ViteTypeOptions {
// 	// By adding this line, you can make the type of ImportMetaEnv strict
// 	// to disallow unknown keys.
// 	// strictImportMetaEnv: unknown
// }

interface ImportMetaEnv {
  readonly VITE_API_URL: string; // API base URL
  readonly VITE_APP_NAME: string; // Application name
  readonly VITE_SENTRY_DSN: string; // Sentry DSN for error tracking
  readonly SENTRY_AUTH_TOKEN: string; // Sentry authentication token
  // more env variables...
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
