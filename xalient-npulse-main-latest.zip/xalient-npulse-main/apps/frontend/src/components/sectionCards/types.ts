import type { DeviceAlert } from "@/components/table/types";

export interface SectionCardTypes {
  alerts: DeviceAlert[];
}
