import { Badge } from "@/components/ui/badge";
import { Card, CardAction, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { useMemo } from "react";
import type { SectionCardTypes } from "./types";

const isActiveAlarm = (alarmclearedtime: unknown): boolean => {
  if (alarmclearedtime == null) return true;
  if (typeof alarmclearedtime === "string") {
    return alarmclearedtime.toLowerCase().includes("1970");
  }

  return false;
};

export function SectionCards({ alerts }: SectionCardTypes) {
  const stats = useMemo(() => {
    const alertList = alerts ?? [];

    const customersAll = new Set<string>();
    const sitesAll = new Set<string>();
    const activeCustomers = new Set<string>();
    const activeSites = new Set<string>();
    const severityTotals: Record<string, number> = {};

    let activeAlarms = 0;

    for (const alert of alertList) {
      const customerKey = (alert.btcustomer ?? "").trim().toLowerCase();
      if (customerKey) customersAll.add(customerKey);

      const siteKey = (alert.btsite ?? "").trim().toLowerCase();
      if (siteKey) sitesAll.add(siteKey);

      if (isActiveAlarm(alert.alarmclearedtime)) {
        activeAlarms += 1;
        if (customerKey) activeCustomers.add(customerKey);
        if (siteKey) activeSites.add(siteKey);

        const severityKey = (alert.perceivedseverity ?? "unknown").toLowerCase();
        severityTotals[severityKey] = (severityTotals[severityKey] ?? 0) + 1;
      }
    }

    return {
      customersWithAlarms: customersAll.size,
      sitesWithAlarms: sitesAll.size,
      totalAlarms: alertList.length,
      activeAlarms,
      activeCustomers: activeCustomers.size,
      activeSites: activeSites.size,
      severityCounts: severityTotals
    };
  }, [alerts]);

  const criticalCount = stats.severityCounts.critical ?? 0;
  const majorCount = stats.severityCounts.major ?? 0;
  const minorCount = stats.severityCounts.minor ?? 0;
  const otherCount = Math.max(stats.activeAlarms - (criticalCount + majorCount + minorCount), 0);

  return (
    <div className="grid grid-cols-1 gap-4 px-4 lg:px-6 @xl/main:grid-cols-2 @5xl/main:grid-cols-4">
      <Card className="from-primary/5 to-card dark:from-card-dark/50 dark:to-card-dark/80 @container/card overflow-hidden rounded-2xl bg-gradient-to-t shadow-xs">
        <CardHeader>
          <CardDescription>Customers with active alarms</CardDescription>
          <CardTitle className="text-2xl font-semibold tabular-nums @[250px]/card:text-3xl">
            {stats.activeCustomers}
          </CardTitle>
        </CardHeader>
        <CardFooter className="flex-col items-start gap-1.5 text-sm">
          <div className="line-clamp-1 flex gap-2 font-medium">
            {stats.activeCustomers} customers currently impacted
          </div>
          <div className="text-muted-foreground">-</div>
        </CardFooter>
      </Card>

      <Card className="from-primary/5 to-card dark:from-card-dark/50 dark:to-card-dark/80 @container/card overflow-hidden rounded-2xl bg-gradient-to-t shadow-xs">
        <CardHeader>
          <CardDescription>Sites with active alarms</CardDescription>
          <CardTitle className="text-2xl font-semibold tabular-nums @[250px]/card:text-3xl">
            {stats.activeSites}
          </CardTitle>
          <CardAction>
            <Badge variant="outline">{stats.activeSites} active</Badge>
          </CardAction>
        </CardHeader>
        <CardFooter className="flex-col items-start gap-1.5 text-sm">
          <div className="line-clamp-1 flex gap-2 font-medium">{stats.activeSites} sites currently impacted</div>
          <div className="text-muted-foreground">-</div>
        </CardFooter>
      </Card>

      <Card className="from-primary/5 to-card dark:from-card-dark/50 dark:to-card-dark/80 @container/card overflow-hidden rounded-2xl bg-gradient-to-t shadow-xs">
        <CardHeader>
          <CardDescription>Active alarms</CardDescription>
          <CardTitle className="text-2xl font-semibold tabular-nums @[250px]/card:text-3xl">
            {stats.activeAlarms}
          </CardTitle>
          <CardAction>
            <Badge variant="outline">{stats.totalAlarms} total</Badge>
          </CardAction>
        </CardHeader>
        <CardFooter className="flex-col items-start gap-1.5 text-sm">
          <div className="line-clamp-1 flex gap-2 font-medium">
            {criticalCount} critical · {majorCount} major · {minorCount} minor
          </div>
          <div className="text-muted-foreground">{otherCount} additional alarms with other severities.</div>
        </CardFooter>
      </Card>

      <Card className="from-primary/5 to-card dark:from-card-dark/50 dark:to-card-dark/80 @container/card overflow-hidden rounded-2xl bg-gradient-to-t shadow-xs">
        <CardHeader>
          <CardDescription>Critical coverage</CardDescription>
          <CardTitle className="text-2xl font-semibold tabular-nums @[250px]/card:text-3xl">
            {stats.activeAlarms ? Math.round((criticalCount / stats.activeAlarms) * 100) : 0}%
          </CardTitle>
          <CardAction>
            <Badge variant="outline">{criticalCount} critical</Badge>
          </CardAction>
        </CardHeader>
        <CardFooter className="flex-col items-start gap-1.5 text-sm">
          <div className="line-clamp-1 flex gap-2 font-medium">
            {criticalCount} of {stats.activeAlarms} active alarms are critical
          </div>
          <div className="text-muted-foreground">
            Remaining active alarms: {majorCount + minorCount + otherCount} (major/minor/other).
          </div>
        </CardFooter>
      </Card>
    </div>
  );
}
