import { useBreadcrumbs } from "@/hooks/use-breadcrumbs";
import { createFileRoute } from "@tanstack/react-router";
import { redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  loader: () => {
    throw redirect({ to: "/dashboard" });
  },
  component: Index
});

function Index() {
  useBreadcrumbs({
    type: "set",
    breadcrumbs: [
      {
        title: "dashboard"
      }
    ]
  });
  return <div />;
}
