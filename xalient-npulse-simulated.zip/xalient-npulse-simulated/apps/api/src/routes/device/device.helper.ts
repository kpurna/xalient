import { asc, desc } from "drizzle-orm";

export const sortType = (sortDirection: "asc" | "desc") => {
  return sortDirection === "asc" ? asc : desc;
};
