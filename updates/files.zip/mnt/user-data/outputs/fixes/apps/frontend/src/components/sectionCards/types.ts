import type { Alarm } from "@/components/table/types";

export interface SectionCardTypes {
  alerts: Alarm[];
}
