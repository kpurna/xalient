import reactHooks from "eslint-plugin-react-hooks";
import reactRefresh from "eslint-plugin-react-refresh";
import { config as baseConfig } from "./base.js";
import pluginRouter from "@tanstack/eslint-plugin-router";
import pluginQuery from "@tanstack/eslint-plugin-query";

/**
 * A shared ESLint configuration for the repository.
 *
 * @type {import("eslint").FlatConfig[]}
 * */
export const viteConfig = [
  ...baseConfig,
  reactHooks.configs["recommended-latest"],
  reactRefresh.configs.vite,
  ...pluginRouter.configs["flat/recommended"],
  ...pluginQuery.configs["flat/recommended"]
];
