import { pinoLogger as logger } from "hono-pino";
import env from "../env.js";

export const pinoLogger = () => {
  return logger({
    pino: {
      level: env.LOG_LEVEL,
      transport:
        env.NODE_ENV === "development"
          ? {
              target: "pino-pretty",
              options: { colorize: true }
            }
          : undefined
    }
  });
};
