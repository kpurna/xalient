import type { Edge } from "@xyflow/react";
import { type Node } from "@xyflow/react";
import { severityToEdgeColor } from "../../helpers";
import type { DeviceFlowNode, DeviceTopologyProps, InterfaceFlowNode } from "../../types";

export const buildNodesAndEdges = (interfaces: DeviceTopologyProps["interfaces"]) => {
  if (!interfaces || interfaces.length === 0) {
    return {
      nodes: [
        {
          id: "device",
          position: { x: 400, y: 200 },
          data: { label: "No interfaces", hasLeft: false, hasRight: false },
          type: "deviceNode"
        } satisfies DeviceFlowNode
      ] as DeviceFlowNode[],
      edges: [] as Edge[]
    };
  }

  const centerX = 400;
  const centerY = 200;
  const radius = 220;
  const total = interfaces.length;
  const deviceRightCount = interfaces.filter(
    (_, index) => Math.cos((index / total) * Math.PI * 2 - Math.PI / 2) >= 0
  ).length;
  const deviceLeftCount = total - deviceRightCount;

  const nodes: Array<DeviceFlowNode | InterfaceFlowNode> = [
    {
      id: "device",
      position: { x: centerX, y: centerY },
      data: { label: "Device", hasLeft: deviceLeftCount > 0, hasRight: deviceRightCount > 0 },
      type: "deviceNode",
      draggable: false,
      selectable: false,
      connectable: false
    }
  ];

  const edges: Edge[] = [];

  interfaces.forEach((iface, index) => {
    const targetId = `interface-${iface.id}`;
    const angle = (index / total) * Math.PI * 2 - Math.PI / 2; // start at top
    const x = centerX + radius * Math.cos(angle);
    const y = centerY + radius * Math.sin(angle);
    const onRightHalf = Math.cos(angle) >= 0;
    const targetHandleId = onRightHalf ? "left" : "right";
    const deviceHandleId = onRightHalf ? "right" : "left";
    nodes.push({
      id: targetId,
      position: { x, y },
      data: {
        label: `${iface.name ?? "Interface"}`,
        description: iface.description ?? "",
        inbound: iface.inbound_util,
        outbound: iface.outbound_util,
        status: iface.status,
        severityColor: severityToEdgeColor(iface.status)
      },
      type: "interfaceNode",
      draggable: false,
      connectable: false,
      selectable: true
    } satisfies InterfaceFlowNode);

    const normalizedStatus = (iface.status ?? "Unknown").toUpperCase();
    const strokeColor = severityToEdgeColor(normalizedStatus);
    const isCeased = normalizedStatus.includes("CEASE");

    edges.push({
      id: `edge-${iface.id}`,
      source: "device",
      target: targetId,
      sourceHandle: deviceHandleId,
      targetHandle: targetHandleId,
      style: {
        stroke: isCeased ? "#94a3b8" : strokeColor,
        strokeWidth: isCeased ? 3 : 2,
        strokeDasharray: isCeased ? "6 6" : undefined,
        pointerEvents: "none"
      },
      label: `${iface.status ?? "Unknown"}`,
      type: "smoothstep",
      className: `${isCeased ? "font-semibold text-slate-500 " : ""}pointer-events-none`
    });
  });

  return { nodes: nodes as Node[], edges };
};
