SELECT * FROM alarms

