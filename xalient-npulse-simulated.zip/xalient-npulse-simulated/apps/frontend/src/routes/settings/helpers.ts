import type { SettingRow } from "./types";

export const getRowKey = (row: SettingRow) => row.tempId ?? row.id;
