# 1) Build stage
FROM node:20-alpine AS build
WORKDIR /repo

RUN corepack enable && corepack prepare pnpm@9.0.0 --activate

COPY pnpm-workspace.yaml pnpm-lock.yaml package.json turbo.json ./
COPY packages ./packages
COPY apps/api ./apps/api

RUN pnpm install --frozen-lockfile

# Build API - emit JS to dist/
RUN printf '{\n  "extends": "./tsconfig.json",\n  "compilerOptions": {\n    "noEmit": false,\n    "allowImportingTsExtensions": false,\n    "outDir": "./dist"\n  }\n}\n' > apps/api/tsconfig.build.json \
  && pnpm -C apps/api exec tsc -p tsconfig.build.json


# 2) Production bundle (prod deps only, no devDeps)
FROM node:20-alpine AS prod-bundle
WORKDIR /repo

RUN corepack enable && corepack prepare pnpm@9.0.0 --activate

COPY pnpm-workspace.yaml pnpm-lock.yaml package.json ./
COPY packages ./packages
COPY apps/api ./apps/api

RUN pnpm deploy /out --filter api --prod --ignore-scripts

# Copy compiled JS from build stage into the bundle
COPY --from=build /repo/apps/api/dist /out/dist


# 3) Runtime image
FROM node:20-alpine AS runner
ENV NODE_ENV=production
ENV LOG_LEVEL=info
WORKDIR /app

RUN corepack enable && corepack prepare pnpm@9.0.0 --activate

# Copy self-contained prod bundle (node_modules + dist)
COPY --from=prod-bundle /out/ ./

# Ensure migrations folder is present for drizzle migrator
COPY --from=build /repo/apps/api/src/db/migrations ./dist/src/db/migrations

# Copy start script
COPY apps/api/scripts/start.sh ./scripts/start.sh
RUN chmod +x ./scripts/start.sh

EXPOSE 3000
CMD ["./scripts/start.sh"]
