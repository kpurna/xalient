import Chart from "@/components/chart";
import { DataTable } from "@/components/table";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useBreadcrumbs } from "@/hooks/use-breadcrumbs";
import { createFileRoute } from "@tanstack/react-router";
import type { PaginationState, SortingState } from "@tanstack/react-table";
import type { AgCartesianAxisOptions, AgCartesianSeriesOptions } from "ag-charts-enterprise";
import React from "react";

const HOURS_TO_DISPLAY = 12;
const HOUR_IN_MS = 60 * 60 * 1000;
const UTILISATION_SERIES: AgCartesianSeriesOptions[] = [
  {
    type: "line",
    xKey: "timestamp",
    yKey: "inbound",
    yName: "Inbound utilisation",
    stroke: "#6366f1",
    marker: { enabled: true, size: 6 }
  },
  {
    type: "line",
    xKey: "timestamp",
    yKey: "outbound",
    yName: "Outbound utilisation",
    stroke: "#0ea5e9",
    marker: { enabled: true, size: 6 }
  }
];

const UTILISATION_AXES: AgCartesianAxisOptions[] = [
  {
    type: "time",
    position: "bottom",
    title: { text: "Time" }
  },
  {
    type: "number",
    position: "left",
    title: { text: "Utilisation (%)" },
    min: 0,
    max: 100,
    label: {
      formatter: ({ value }) => `${value}%`
    }
  }
];

const toPercentage = (value: number) => Math.round(Math.min(100, Math.max(0, value)) * 10) / 10;

const buildUtilisationSeries = (baseInbound: number, baseOutbound: number) => {
  const now = Date.now();
  return Array.from({ length: HOURS_TO_DISPLAY }, (_, index) => {
    const offset = HOURS_TO_DISPLAY - 1 - index;
    const timestamp = now - offset * HOUR_IN_MS;
    const inbound = toPercentage(baseInbound + Math.sin(index / 1.5) * 12 + (index % 3) * 1.5);
    const outbound = toPercentage(baseOutbound + Math.cos(index / 1.8) * 10 + ((index + 1) % 4) * 1.2);

    return {
      timestamp,
      inbound,
      outbound
    };
  });
};

export const Route = createFileRoute("/device/components/Interface/interface/$interfaceId")({
  component: RouteComponent
});

function RouteComponent() {
  const { interfaceId } = Route.useParams();
  const { deviceId } = Route.useSearch() as { deviceId?: string };
  const decodedInterface = decodeURIComponent(interfaceId);
  useBreadcrumbs({
    type: "set",
    breadcrumbs: [
      {
        title: "Dashboard",
        href: "/dashboard"
      },
      {
        title: deviceId as string,
        href: `/device/device/${deviceId}`
      },
      {
        title: decodedInterface
      }
    ]
  });

  const chartData = buildUtilisationSeries(50, 80);

  const utilisationSeries = UTILISATION_SERIES;

  const [sorting, setSorting] = React.useState<SortingState>([{ id: "id", desc: true }]);
  const [paginationFilters, setPaginationFilters] = React.useState<PaginationState>({ pageIndex: 0, pageSize: 10 });
  const [searchBy, setSearchBy] = React.useState<string>("");

  return (
    <div className="px-4 lg:px-6">
      <Card>
        <CardHeader>
          <CardTitle>Utilisation</CardTitle>
          <CardDescription>
            ** BTCM CID:ASCT-06079, SR:1784616, PE:PE15-SPL-AM, GE3/0/2 ** -- (200 Mbps)
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <Chart data={chartData} series={utilisationSeries} axes={UTILISATION_AXES} />
        </CardContent>
      </Card>
      <h3 className="pt-4 text-lg font-semibold">Alerts</h3>
      <div className="rounded-2xl border bg-white p-4 dark:border-neutral-800 dark:bg-neutral-900">
        <DataTable
          data={[]}
          sorting={sorting}
          paginationFilters={paginationFilters}
          setSorting={setSorting}
          setPaginationFilters={setPaginationFilters}
          setSearchBy={setSearchBy}
          searchBy={searchBy}
          total={0}
          tableName="deviceAlerts"
        />
      </div>
    </div>
  );
}
