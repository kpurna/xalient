import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem
} from "@/components/ui/sidebar";
import { globalConfig } from "@/global.config";
import { Link } from "@tanstack/react-router";
import logo from "../assets/logo.png";
import UserMenu from "./user-menu";

interface AppSidebarProps {
  routes: { title: string; path: string; icon: React.ReactNode }[];
}

const userSettings = globalConfig.sidebarUserSettings;
export const AppSidebar = ({ routes }: AppSidebarProps) => {
  return (
    <Sidebar>
      <SidebarHeader />
      <div className="flex justify-center">
        <img src={logo} alt="Logo" className="h-[150px] w-[150px]" />
      </div>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Pages</SidebarGroupLabel>
          <SidebarMenu>
            {routes.map((route) => (
              <SidebarMenuItem key={route.title}>
                <SidebarMenuButton asChild>
                  <Link to={route.path} activeProps={{ className: "text-blue-500" }}>
                    {route.icon}
                    <span data-testid={`link-${route.title}`}>{route.title}</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
            ))}
          </SidebarMenu>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter>
        <UserMenu name="John Doe" role="Admin" routes={userSettings.menu} imageUrl="https://i.pravatar.cc/150" />
      </SidebarFooter>
    </Sidebar>
  );
};
