import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { render } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { Changes } from ".";

function renderWithClient(ui: React.ReactElement) {
  const queryClient = new QueryClient({
    defaultOptions: {
      queries: {
        retry: false // don’t retry failed queries in tests
      }
    }
  });

  return render(<QueryClientProvider client={queryClient}>{ui}</QueryClientProvider>);
}

describe("Changes component", () => {
  it("matches snapshot", () => {
    const { asFragment } = renderWithClient(<Changes />);
    expect(asFragment()).toMatchSnapshot();
  });
});
