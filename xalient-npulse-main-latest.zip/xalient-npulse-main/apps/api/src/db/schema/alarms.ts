import { boolean, jsonb, pgTable, text, timestamp, varchar } from "drizzle-orm/pg-core";
import { createSelectSchema } from "drizzle-zod";

// Real alarms written by xalient-data-collector-main via the OTLP pipeline
export const alarms = pgTable("alarms", {
  id: varchar({ length: 255 }).primaryKey().unique(),

  alarmraisedtime: timestamp({ withTimezone: true }),
  alarmclearedtime: timestamp({ withTimezone: true }),
  alarmreportingtime: timestamp({ withTimezone: true }),
  alarmchangedtime: timestamp({ withTimezone: true }),

  alarmedobjecttype: varchar({ length: 255 }),
  perceivedseverity: varchar({ length: 255 }),
  probablecause: varchar({ length: 255 }),
  btelementclass: varchar({ length: 255 }),
  state: varchar({ length: 255 }),
  externalalarmid: varchar({ length: 255 }),

  btcustomer: varchar({ length: 255 }),
  btsourcesystem: varchar({ length: 255 }),
  btinstancename: varchar({ length: 255 }),
  btcount: varchar({ length: 255 }),
  btuserdefined: varchar({ length: 255 }),
  btntnid: varchar({ length: 255 }),
  btpewmso: varchar({ length: 255 }),
  btaffectedcircuit: varchar({ length: 255 }),
  btservername: varchar({ length: 255 }),
  btsite: varchar({ length: 255 }),

  sourcesystemid: varchar({ length: 255 }),
  ackuserid: varchar({ length: 255 }),
  acksystemid: varchar({ length: 255 }),
  ackstate: varchar({ length: 255 }),

  alarmtype: varchar({ length: 255 }),
  plannedoutageindicator: varchar({ length: 255 }),
  category: varchar({ length: 255 }),
  incidentid: varchar({ length: 255 }),

  specificproblem: text(),
  alarmdetails: text(),

  isrootcause: boolean(),

  correlatedalarm: jsonb(),
  alarmedobject: jsonb(),
  affectedservice: jsonb(),
  parentalarm: jsonb()
});

export const alarmSelectSchema = createSelectSchema(alarms);
