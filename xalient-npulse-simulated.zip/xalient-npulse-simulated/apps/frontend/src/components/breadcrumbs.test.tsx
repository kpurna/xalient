import { customRender } from "@/__tests__/setup";
import { act, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { Breadcrumbs } from "./breadcrumbs";

const breadcrumbsMock = [
  { title: "Home", href: "/" },
  { title: "Dashboard", href: "/dashboard" },
  { title: "Settings", href: "/settings" }
];

describe("Breadcrumbs", () => {
  beforeEach(async () => {
    await act(async () => {
      customRender(<Breadcrumbs breadcrumbs={breadcrumbsMock} />);
    });
  });

  it("renders all breadcrumb items", () => {
    breadcrumbsMock.forEach((breadcrumb) => {
      expect(screen.getByText(breadcrumb.title)).toBeInTheDocument();
    });
  });

  it("renders links with correct hrefs", () => {
    breadcrumbsMock.forEach((breadcrumb) => {
      const link = screen.getByText(breadcrumb.title).closest("a");
      expect(link).toHaveAttribute("href", breadcrumb.href);
    });
  });
});
