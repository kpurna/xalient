import { Spinner } from "@/components/ui/spinner";
import { useNavigate } from "@tanstack/react-router";
import { type LatLngTuple } from "leaflet";
import "leaflet/dist/leaflet.css";
import type { CSSProperties } from "react";
import { useCallback, useMemo } from "react";
import { MapContainer, Marker, Popup, TileLayer } from "react-leaflet";
import { MarkerPopupContent } from "./components/MarkerPopupContent";
import { buildMarkerData, buildMarkerIcon, DEFAULT_CENTER, DeviceMapBoundsUpdater, SEVERITY_META } from "./helpers";
import type { DeviceMarkerWithIcon, DeviceSeverityMapProps, SeverityLevel } from "./types";

const MAP_CONTAINER_STYLE: CSSProperties = { width: "100%", height: 420, backgroundColor: "#ffffff" };
const TILE_LAYER_URL = "https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png";
const TILE_LAYER_ATTRIBUTION =
  '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors';

const DeviceSeverityMap = ({ devices, isLoading = false }: DeviceSeverityMapProps) => {
  const navigate = useNavigate();

  const { markers, severityTotals } = useMemo(
    () => buildMarkerData(isLoading ? undefined : devices),
    [devices, isLoading]
  );

  const markersWithIcons = useMemo<DeviceMarkerWithIcon[]>(() => {
    return markers.map((marker) => {
      const markerLabel =
        marker.alertCount > 0
          ? marker.alertCount > 99
            ? "99+"
            : String(marker.alertCount)
          : marker.severity.charAt(0).toUpperCase();

      return {
        ...marker,
        markerLabel,
        icon: buildMarkerIcon(marker.severity, markerLabel)
      };
    });
  }, [markers]);

  const mapCenter: LatLngTuple = markersWithIcons.length > 0 ? markersWithIcons[0].position : DEFAULT_CENTER;

  const handleNavigate = useCallback(
    (deviceId: string) => {
      navigate({
        to: "/device/device/$deviceId",
        params: { deviceId }
      });
    },
    [navigate]
  );

  if (isLoading) {
    return <Spinner />;
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-semibold">Device Severity</h2>
          <p className="text-sm text-neutral-500 dark:text-neutral-400">
            Highest alert severity per device shown on the global map.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-3 text-xs font-medium">
          {Object.entries(SEVERITY_META).map(([key, meta]) => (
            <span
              key={key}
              className="flex items-center gap-2 rounded-full border border-neutral-200 px-3 py-1 dark:border-neutral-700"
            >
              <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: meta.color }} />
              <span className="flex items-center gap-1">
                {key}
                <span className="rounded-full bg-neutral-100 px-2 py-0.5 text-[11px] font-semibold text-neutral-700 dark:bg-neutral-800 dark:text-neutral-200">
                  {severityTotals[key as SeverityLevel] ?? 0}
                </span>
              </span>
            </span>
          ))}
        </div>
      </div>

      <div className="relative w-full overflow-hidden rounded-2xl border border-neutral-200 dark:border-neutral-800">
        <MapContainer
          center={mapCenter}
          zoom={markersWithIcons.length > 0 ? 2 : 1}
          minZoom={1}
          style={MAP_CONTAINER_STYLE}
          scrollWheelZoom={false}
          worldCopyJump
        >
          <TileLayer url={TILE_LAYER_URL} attribution={TILE_LAYER_ATTRIBUTION} />
          <DeviceMapBoundsUpdater markers={markersWithIcons} />
          {markersWithIcons.map((marker) => (
            <Marker key={marker.id} position={marker.position} icon={marker.icon}>
              <Popup className="text-xs" offset={[0, -12]}>
                <MarkerPopupContent marker={marker} onNavigate={handleNavigate} />
              </Popup>
            </Marker>
          ))}
        </MapContainer>
      </div>
    </div>
  );
};

export default DeviceSeverityMap;
