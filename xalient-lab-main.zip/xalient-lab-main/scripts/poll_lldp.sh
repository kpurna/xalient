#!/usr/bin/env bash
set -eu

COMMUNITY="${COMMUNITY:-public}"
INTERVAL="${POLL_INTERVAL_SECONDS:-15}"
OUT="${LLDP_OUT_FILE:-/data/lldp/lldp.jsonl}"
TARGETS="${TARGETS:-r1-frr r2-frr r3-frr}"

# LLDP OIDs (numeric; no MIBs required)
# lldpLocPortDesc          1.0.8802.1.1.2.1.3.7.1.4
# lldpRemLocalPortNum      1.0.8802.1.1.2.1.4.1.1.2
# lldpRemSysName           1.0.8802.1.1.2.1.4.1.1.9
# lldpRemPortDesc          1.0.8802.1.1.2.1.4.1.1.8
OID_LOC_DESC="1.0.8802.1.1.2.1.3.7.1.4"
OID_REM_LPN="1.0.8802.1.1.2.1.4.1.1.2"
OID_REM_SYS="1.0.8802.1.1.2.1.4.1.1.9"
OID_REM_PDESC="1.0.8802.1.1.2.1.4.1.1.8"

# Value-only; quiet; numeric OIDs
SNMP="snmpwalk -v2c -c ${COMMUNITY} -Oqv -On"

# Ensure each target speaks SNMP before we start emitting rows
for t in $TARGETS; do
  echo "[poller] waiting for SNMP on $t ..."
  # sysUpTime check; -Oqv gives value only, -r 0 avoids long retries
  until snmpwalk -v2c -c "$COMMUNITY" -Oqv -r 0 -t 1 "$t" 1.3.6.1.2.1.1.3.0 >/dev/null 2>&1; do
    sleep 2
  done
done
echo "[poller] all targets ready"

mkdir -p "$(dirname "$OUT")"

poll_one() {
  host="$1"
  now="$(date -u +%FT%TZ)"

  # 1) Build map: localPortNum -> local interface (ethX)
  #    Walk lldpLocPortDesc; parse index from OID (last component)
  $SNMP "$host" "$OID_LOC_DESC" 2>/dev/null \
  | awk -v HOST="$host" -v NOW="$now" '
      BEGIN{FS="\n"}
      {
        # We do not get the OID here because of -Oqv; do a second call that prints OID+value
      }' >/dev/null

  # We need OID index to map; do one pass with OID+value:
  snmpwalk -v2c -c "${COMMUNITY}" -On "$host" "$OID_LOC_DESC" 2>/dev/null \
  | awk -v h="$host" '
      {
        # Example line:
        # 1.0.8802...1.4. <value>
        # Split OID from value:
        i = index($0," ")
        oid = substr($0,1,i-1)
        val = substr($0,i+1)
        n = split(oid,a,".")
        lp = a[n]                      # last OID component = localPortNum
        gsub(/^"|"$/,"",val)          # trim quotes if snmp prints them
        print lp "|" val
      }' > /tmp/loc."$host"

  # 2) Remote sysname keyed by localPortNum
  snmpwalk -v2c -c "${COMMUNITY}" -On "$host" "$OID_REM_SYS" 2>/dev/null \
  | awk '
      {
        i = index($0," ")
        oid = substr($0,1,i-1)
        val = substr($0,i+1)
        # find local port num from the OID tail (..., <lpn>, <remIndex>)
        n = split(oid,a,".")
        lpn = a[n-1]
        gsub(/^"|"$/,"",val)
        print lpn "|" val
      }' > /tmp/rem_sys."$host"

  # 3) Remote port description keyed by localPortNum
  snmpwalk -v2c -c "${COMMUNITY}" -On "$host" "$OID_REM_PDESC" 2>/dev/null \
  | awk '
      {
        i = index($0," ")
        oid = substr($0,1,i-1)
        val = substr($0,i+1)
        n = split(oid,a,".")
        lpn = a[n-1]
        gsub(/^"|"$/,"",val)
        print lpn "|" val
      }' > /tmp/rem_pdesc."$host"

  # 4) Join on localPortNum and emit JSONL
  awk -F"|" -v NOW="$now" -v R="$host" '
    NR==FNR            {loc[$1]=$2; next}
    FILENAME ~ /rem_sys/   {rs[$1]=$2; next}
    FILENAME ~ /rem_pdesc/ {rp[$1]=$2; next}
    END {
      for (lp in rs) {
        l_if = (lp in loc ? loc[lp] : ("port " lp))
        r_sys = rs[lp]
        r_pd  = (lp in rp ? rp[lp] : "")
        # Basic sanitization
        gsub(/"/,"\\\"", l_if)
        gsub(/"/,"\\\"", r_sys)
        gsub(/"/,"\\\"", r_pd)
        printf("{\"ts\":\"%s\",\"router\":\"%s\",\"local_if\":\"%s\",\"remote_sys\":\"%s\",\"remote_port_desc\":\"%s\"}\n",
               NOW, R, l_if, r_sys, r_pd)
      }
    }' /tmp/loc."$host" /tmp/rem_sys."$host" /tmp/rem_pdesc."$host" >> "$OUT"

  rm -f /tmp/loc."$host" /tmp/rem_sys."$host" /tmp/rem_pdesc."$host"
}

echo "[lldp-poller] writing to $OUT (interval ${INTERVAL}s); targets: $TARGETS" >&2
touch "$OUT"

while :; do
  for t in $TARGETS; do
    poll_one "$t" || echo "[lldp-poller] warn: polling $t failed" >&2
  done
  sleep "$INTERVAL"
done