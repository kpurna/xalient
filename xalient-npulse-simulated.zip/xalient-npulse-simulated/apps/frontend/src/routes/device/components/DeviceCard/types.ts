import type { api } from "@/lib/api";
import type { InferResponseType } from "hono/client";
import type { ComponentType } from "react";

type Response = InferResponseType<typeof api.deviceDetails.$get>;

export type Details = Response["data"][number];

export interface DeviceCardTypes {
  device: Details;
  interfaces?: {
    id: number;
    name: string | null;
    description: string | null;
    inbound_util: string | null;
    outbound_util: string | null;
    status: string | null;
  }[];
  deviceId?: string;
  TopologyComponent?: ComponentType<{ interfaces?: DeviceCardTypes["interfaces"]; deviceId?: string }>;
}

export interface StatusBadgeProps {
  status: string;
}
