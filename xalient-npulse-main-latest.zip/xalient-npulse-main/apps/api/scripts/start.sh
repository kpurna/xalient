#!/bin/sh
set -e

cd /app

# ── 1. Wait for Postgres ─────────────────────────────────────────────────────
echo "Waiting for database to be ready..."
until node -e "
const { Pool } = require('pg');
const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: false });
pool.query('SELECT 1')
  .then(() => { pool.end(); process.exit(0); })
  .catch(() => { pool.end(); process.exit(1); });
" 2>/dev/null; do
  echo "  Postgres not ready yet — retrying in 3s..."
  sleep 3
done
echo "Database is ready."

# ── 2. Drop all tables ───────────────────────────────────────────────────────
echo "Dropping existing tables..."
node dist/src/db/drop-all-tables.js

# ── 3. Run migrations ────────────────────────────────────────────────────────
echo "Running database migrations..."
node dist/src/db/migrate.js

# ── 4. Seed data ─────────────────────────────────────────────────────────────
echo "Seeding database..."
node dist/src/db/seed.js \
  --alerts=200 \
  --alarms=200 \
  --changes=100 \
  --interfaces=200 \
  --inventory=30 \
  --smarts_discovery_status_rgt=10 \
  --settings=3

echo "Database ready. Starting API server..."

# ── 5. Start API ─────────────────────────────────────────────────────────────
exec node dist/src/index.js
