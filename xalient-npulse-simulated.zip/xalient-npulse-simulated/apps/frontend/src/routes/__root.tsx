import { AppSidebar } from "@/components/app-sidebar";
import { Header } from "@/components/header";
import { globalConfig } from "@/global.config";
import { Outlet, createRootRoute } from "@tanstack/react-router";

export const Route = createRootRoute({
  component: RootComponent
});
const sidebarRoutes = globalConfig.sidebarRoutes;

function RootComponent() {
  return (
    <>
      <AppSidebar routes={sidebarRoutes} />
      <div className="min-h-screen w-full dark:bg-black dark:text-gray-100">
        <Header />
        <Outlet />
      </div>
    </>
  );
}
