SELECT
  "time",
  tag,
  data->>'log' AS message
FROM public.otel_logs
WHERE "time" > now() - interval '5 minutes'
  AND data->'__internal__'->'log_metadata'->'otlp'->'attributes'->>'log_type' = 'syslog'
ORDER BY "time" DESC
LIMIT 100;