// Device.test.tsx
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { render } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import { Device, Route } from "./device.$deviceId";

function renderWithClient(ui: React.ReactElement) {
  const queryClient = new QueryClient({
    defaultOptions: {
      queries: {
        retry: false
      }
    }
  });

  return render(<QueryClientProvider client={queryClient}>{ui}</QueryClientProvider>);
}

describe("Device component", () => {
  it("renders with a deviceId and matches snapshot", () => {
    vi.spyOn(Route, "useParams").mockReturnValue({ deviceId: "123" });
    const { asFragment } = renderWithClient(<Device />);
    expect(asFragment()).toMatchSnapshot();
  });
});
