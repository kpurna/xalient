import { sentry } from "@hono/sentry";
import configureOpenAPI from "./lib/configure-open-api.js";
import createApp from "./lib/create-app.js";
import { pinoLogger } from "./middlewares/pino-logger.js";
import deviceRoute from "./routes/device/device.index.js";
import logsRouter from "./routes/logs/logs.index.js";
import settingRouter from "./routes/settings/settings.index.js";

const app = createApp();

configureOpenAPI(app);

sentry({
  dsn: `${process.env.SENTRY_DSN}`
});

app.use("*", pinoLogger());

// eslint-disable-next-line @typescript-eslint/no-unused-vars
const routes = app.route("/", deviceRoute).route("/", settingRouter).route("/", logsRouter);

export default app;

export type ApiRoutes = typeof routes;
