import { StatusCodes } from "http-status-codes";
import type { AppRouteHandler } from "../../lib/types.js";

import { and, eq, inArray, or, sql, type AnyColumn, type SQLWrapper } from "drizzle-orm";
import db from "../../db/index.js";
import { alerts } from "../../db/schema/alerts.js";
import { changes } from "../../db/schema/changes.js";
import { interfaces } from "../../db/schema/interfaces.js";
import { inventory } from "../../db/schema/inventory.js";
import { smarts_discovery_status_rgt } from "../../db/schema/smarts_discovery_status_rgt.js";
import { sortType } from "./device.helper.js";
import type {
  AlertRoute,
  DeviceAlert,
  DeviceChange,
  DeviceDetails,
  DeviceInterface,
  ListRoute,
  StatRoute
} from "./device.routes.js";

export const deviceData: AppRouteHandler<ListRoute> = async (c) => {
  const { sortDirection, sortField, searchBy } = c.req.valid("query");

  const sort = sortType(sortDirection);

  const columnMap: Record<string, AnyColumn | SQLWrapper> = {
    id: inventory.id,
    bfg_hostname: inventory.bfg_hostname,
    site_name: inventory.site_name,
    country: inventory.adr_country
  };

  const column = columnMap[sortField] ?? inventory.id;

  const conditions: (SQLWrapper | undefined)[] = [
    searchBy
      ? or(
          sql`${inventory.bfg_hostname}::text ILIKE ${`%${searchBy}%`}`,
          sql`${inventory.site_name}::text ILIKE ${`%${searchBy}%`}`,
          sql`${inventory.adr_country}::text ILIKE ${`%${searchBy}%`}`,
          sql`${alerts.assigned_to}::text ILIKE ${`%${searchBy}%`}`,
          sql`${alerts.severity}::text ILIKE ${`%${searchBy}%`}`
        )
      : undefined
  ].filter(Boolean);

  const inventoryWithAlerts = await db
    .select({
      bfg_hostname: sql<string>`${inventory.bfg_hostname}`,
      site_name: sql<string>`${inventory.site_name}`,
      country: sql<string>`${inventory.adr_country}`,

      number_of_alerts: sql<number>`COUNT(${alerts.id})`,
      assigned_to: sql<string>`string_agg(DISTINCT ${alerts.assigned_to}, ',')`,
      severity: sql<number>`
      COALESCE(
        MAX(
          CASE ${alerts.severity}
            WHEN 'HIGH' THEN 3
            WHEN 'MEDIUM' THEN 3
            WHEN 'LOW' THEN 1
            ELSE 0
          END
        ), 0
      )
    `
    })
    .from(inventory)
    .leftJoin(alerts, eq(inventory.bfg_hostname, alerts.device_name))
    .where(and(...conditions))
    .groupBy(inventory.id, inventory.bfg_hostname, inventory.site_name, inventory.adr_country)
    .orderBy(sort(column));
  // .limit(pageSize);

  return c.json(
    {
      message: "success",
      data: inventoryWithAlerts
    },
    StatusCodes.OK
  );
};

export const stats: AppRouteHandler<StatRoute> = async (c) => {
  const inventoryData = await db.select().from(inventory);

  const successfullyDiscoveredDevices = await db
    .select({
      count: sql<number>`COUNT(DISTINCT ${smarts_discovery_status_rgt.man_hostname})`
    })
    .from(smarts_discovery_status_rgt)
    .where(sql`current_discovery_error_message = 'Successfully Discovered'`);

  const deviceNames = [...new Set(inventoryData.map((item) => item.bfg_hostname as string))];
  const siteNames = [...new Set(inventoryData.map((item) => item.site_name as string))];

  const countDevicesWithAlerts = await db
    .select({
      count: sql<number>`COUNT(DISTINCT ${alerts.device_name})`
    })
    .from(alerts)
    .where(inArray(alerts.device_name, deviceNames));

  return c.json(
    {
      message: "success",
      totalDevices: deviceNames.length,
      deviceWithAlerts: countDevicesWithAlerts[0].count,
      totalSites: siteNames.length,
      totalSuccessfullyDiscoveredDevices: Number(successfullyDiscoveredDevices[0].count)
    },
    StatusCodes.OK
  );
};

export const allAlerts: AppRouteHandler<AlertRoute> = async (c) => {
  const { startTime, endTime } = c.req.valid("query");

  const data = await db
    .select()
    .from(alerts)
    .where(sql`first between ${startTime} and ${endTime}`);

  return c.json(
    {
      message: "Success",
      data: data
    },
    StatusCodes.OK
  );
};

export const deviceChanges: AppRouteHandler<DeviceChange> = async (c) => {
  const { sortDirection, sortField, searchBy } = c.req.valid("query");

  const sort = sortType(sortDirection);

  const columnMap: Record<string, AnyColumn | SQLWrapper> = {
    id: changes.id,
    change_number: changes.change_number,
    assignment_group: changes.assignment_group,
    category: changes.category,
    assigned_to: changes.assigned_to,
    planned_start_date: changes.planned_start_date,
    planned_end_date: changes.planned_end_date,
    state: changes.state,
    short_description: changes.short_description,
    close_code: changes.close_code
  };

  const column = columnMap[sortField] ?? changes.id;

  const conditions: (SQLWrapper | undefined)[] = [
    searchBy
      ? or(
          sql`${changes.change_number}::text ILIKE ${`%${searchBy}%`}`,
          sql`${changes.assigned_to}::text ILIKE ${`%${searchBy}%`}`,
          sql`${changes.assignment_group}::text ILIKE ${`%${searchBy}%`}`,
          sql`${changes.category}::text ILIKE ${`%${searchBy}%`}`,
          sql`${changes.close_code}::text ILIKE ${`%${searchBy}%`}`,
          sql`${changes.short_description}::text ILIKE ${`%${searchBy}%`}`,
          sql`${changes.state}::text ILIKE ${`%${searchBy}%`}`
        )
      : undefined
  ].filter(Boolean);

  const rows = await db
    .select()
    .from(changes)
    .where(and(...conditions))
    .orderBy(sort(column));

  return c.json(
    {
      message: "Success",
      data: rows
    },
    StatusCodes.OK
  );
};

export const deviceAlerts: AppRouteHandler<DeviceAlert> = async (c) => {
  const { sortDirection, sortField, searchBy, deviceId } = c.req.valid("query");

  const sort = sortType(sortDirection);

  const columnMap: Record<string, AnyColumn | SQLWrapper> = {
    id: alerts.id,
    severity: alerts.severity,
    assigned_to: alerts.assigned_to
  };

  const column = columnMap[sortField] ?? alerts.id;

  const conditions: (SQLWrapper | undefined)[] = [
    sql`device_name = ${deviceId}`,
    searchBy
      ? or(
          sql`${alerts.assigned_to}::text ILIKE ${`%${searchBy}%`}`,
          sql`${alerts.id}::text ILIKE ${`%${searchBy}%`}`,
          sql`${alerts.severity}::text ILIKE ${`%${searchBy}%`}`
        )
      : undefined
  ].filter(Boolean);

  const data = await db
    .select()
    .from(alerts)
    .where(and(...conditions))
    .orderBy(sort(column));

  return c.json(
    {
      message: "Success",
      data: data
    },
    StatusCodes.OK
  );
};

export const deviceInterfaces: AppRouteHandler<DeviceInterface> = async (c) => {
  const { deviceId } = c.req.valid("query");

  const data = await db
    .select()
    .from(interfaces)
    .where(sql`device_name = ${deviceId}`);

  return c.json(
    {
      message: "Success",
      data: data
    },
    StatusCodes.OK
  );
};

export const deviceDetails: AppRouteHandler<DeviceDetails> = async (c) => {
  const { deviceId } = c.req.valid("query");

  const data = await db
    .select()
    .from(inventory)
    .where(sql`bfg_hostname = ${deviceId}`);

  return c.json(
    {
      message: "Success",
      data: data
    },
    StatusCodes.OK
  );
};
