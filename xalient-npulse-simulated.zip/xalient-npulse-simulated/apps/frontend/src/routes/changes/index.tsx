import { DataTable } from "@/components/table";
import { api } from "@/lib/api";
import { useQuery } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import type { PaginationState, SortingState } from "@tanstack/react-table";
import React, { useEffect } from "react";

export const Route = createFileRoute("/changes/")({
  component: Changes
});

export function Changes() {
  const [sorting, setSorting] = React.useState<SortingState>([{ id: "change_number", desc: true }]);
  const [paginationFilters, setPaginationFilters] = React.useState<PaginationState>({ pageIndex: 0, pageSize: 10 });
  const [searchBy, setSearchBy] = React.useState<string>("");

  const { data, refetch, isFetching, isPending } = useQuery({
    // eslint-disable-next-line @tanstack/query/exhaustive-deps
    queryKey: ["device-changes"],
    queryFn: async () =>
      (
        await api.deviceChanges.$get({
          query: {
            sortField: sorting[0].id,
            sortDirection: sorting[0].desc ? "desc" : "asc",
            searchBy
          }
        })
      ).json()
  });

  useEffect(() => {
    refetch();
  }, [sorting, searchBy, refetch]);

  const isChangesLoading = isPending || (isFetching && !data);

  return (
    <div className="p-4">
      <div className="px-4 lg:px-6">
        <div className="rounded-2xl border bg-white p-4 dark:border-neutral-800 dark:bg-neutral-900">
          <DataTable
            data={data?.data ?? []}
            sorting={sorting}
            paginationFilters={paginationFilters}
            setSorting={setSorting}
            setPaginationFilters={setPaginationFilters}
            setSearchBy={setSearchBy}
            searchBy={searchBy}
            total={data?.data.length ?? 0}
            tableName={"changes"}
            isLoading={isChangesLoading}
          />
        </div>
      </div>
    </div>
  );
}
