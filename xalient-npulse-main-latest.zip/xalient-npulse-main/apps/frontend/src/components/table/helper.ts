export const SEVERITY_COLORS: Record<string, string> = {
  normal: "bg-green-100 text-green-800",
  minor: "bg-yellow-100 text-yellow-800",
  major: "bg-orange-100 text-orange-800",
  critical: "bg-red-100 text-red-800",
  0: "bg-green-100 text-green-800",
  1: "bg-yellow-100 text-yellow-800",
  2: "bg-orange-100 text-orange-800",
  3: "bg-red-100 text-red-800"
};
export const SEVERITY = {
  0: "Healthy",
  1: "Low",
  2: "Medium",
  3: "High"
};

export function formatDateOrDash(value?: string) {
  if (!value) return "-";

  if (value.includes("1970")) {
    return "-";
  }
  return value;
}
