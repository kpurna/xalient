// DeviceCard.test.tsx
import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import DeviceCard from "./index";

describe("DeviceCard component", () => {
  const data = {
    id: 1,
    bfg_hostname: "hostname 2",
    site_cus_type: "type 1",
    site_name: "site 1",
    site_cus_region: "USA",
    adr_country: "USA",
    msa: "m",
    lsa: "lsa",
    bfg_ip_address: "192.19.1.1",
    vendor: "BG",
    model: "model-1",
    serial_number: "HW101-11",
    final_hw_eovss: "hw",
    hw_eovss_year: "hw2",
    final_hw_eol: "hw1",
    hw_eol_year: "hw1",
    current_ios_version: "10.1",
    sw_eol_date: "",
    sw_eol_year: "",
    ssv_label: "a",
    site_type: "type a",
    tower: "tower 1",
    bfg_ntn_type: "type 1",
    sw_status: "Live",
    hw_customer_dependency: false,
    sw_customer_dep_dependency: false,
    riverbed: false,
    hw_exceptions: "",
    major_minor_sw_version_upgrade: false,
    recommended_ios: true,
    refesh_status: "Pending",
    rfq: "",
    risk_reference: "",
    action: "",
    updated_at: "1759747394000",
    created_at: "1759747394000",
    deleted_at: "1759747394000"
  };
  it("matches snapshot", () => {
    const { asFragment } = render(<DeviceCard device={data} interfaces={[]} TopologyComponent={() => <div />} />);
    expect(asFragment()).toMatchSnapshot();
  });

  it("renders data correctly", () => {
    render(<DeviceCard device={data} interfaces={[]} TopologyComponent={() => <div />} />);
    expect(screen.getByText(/Device name: hostname 2/)).toBeInTheDocument();
    expect(screen.getByText(/Site: site 1/)).toBeInTheDocument();
  });
});
